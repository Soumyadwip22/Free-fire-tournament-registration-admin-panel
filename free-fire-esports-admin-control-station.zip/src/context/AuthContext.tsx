import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import { User, GoogleAuthProvider, signInWithPopup, signOut as firebaseSignOut, onAuthStateChanged } from 'firebase/auth';
import { collection, addDoc, onSnapshot, query, orderBy, limit } from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from '../firebase/config';
import { AdminUser, AuditLog } from '../types';

export const AUTHORIZED_ORGANIZERS = [
  'mondalsoumyadwip1110@gmail.com',
  'soumyadwipmondal869@gmail.com',
];

interface AuthContextType {
  user: User | null;
  adminUser: AdminUser | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  isLoadingAuth: boolean;
  error: string | null;
  authError: string | null;
  auditLogs: AuditLog[];
  loginWithGoogle: () => Promise<boolean>;
  loginWithEmail: (email: string, password?: string) => Promise<boolean>;
  loginAsDemoAdmin: (email?: string) => Promise<boolean>;
  logout: () => Promise<void>;
  logAudit: (action: string, category: AuditLog['category'], details: string, targetId?: string, targetName?: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [adminUser, setAdminUser] = useState<AdminUser | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);

  // Listen to Firebase auth state
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        const email = currentUser.email || 'soumyadwipmondal869@gmail.com';
        const name = currentUser.displayName || (email.includes('soumya') || email.includes('mondal') ? 'Soumyadwip Mondal (Chief Admin)' : 'Tournament Director');
        setAdminUser({
          email,
          name,
          role: 'SUPER_ADMIN',
          avatarUrl: currentUser.photoURL || undefined,
        });
        setError(null);
      } else {
        // Check if there was a local organizer session
        const storedAdmin = localStorage.getItem('ff_admin_session');
        if (storedAdmin) {
          try {
            const parsed = JSON.parse(storedAdmin);
            setAdminUser(parsed);
          } catch {
            localStorage.removeItem('ff_admin_session');
          }
        }
      }
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Listen to live audit logs from Firestore
  useEffect(() => {
    try {
      const q = query(collection(db, 'audit_logs'), orderBy('timestamp', 'desc'), limit(100));
      const unsubscribe = onSnapshot(
        q,
        (snapshot) => {
          const logs: AuditLog[] = snapshot.docs.map((doc) => ({
            id: doc.id,
            ...(doc.data() as Omit<AuditLog, 'id'>),
          }));
          setAuditLogs(logs);
        },
        () => {
          // Collection initializing
        }
      );
      return () => unsubscribe();
    } catch {
      // Safe fallback
    }
  }, []);

  // Log an admin activity to Firestore and local state
  const logAudit = useCallback(
    async (
      action: string,
      category: AuditLog['category'],
      details: string,
      targetId?: string,
      targetName?: string
    ) => {
      const currentEmail = adminUser?.email || user?.email || 'mondalsoumyadwip1110@gmail.com';
      const logEntry: Omit<AuditLog, 'id'> = {
        action,
        category,
        details,
        targetId: targetId || '',
        targetName: targetName || '',
        adminEmail: currentEmail,
        timestamp: new Date().toISOString(),
      };

      try {
        await addDoc(collection(db, 'audit_logs'), logEntry);
      } catch {
        // Fallback local update
        setAuditLogs((prev) => [
          {
            id: 'local-' + Date.now(),
            ...logEntry,
          },
          ...prev,
        ]);
      }
    },
    [adminUser, user]
  );

  const loginWithGoogle = async (): Promise<boolean> => {
    setIsLoading(true);
    setError(null);
    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      const result = await signInWithPopup(auth, provider);
      const email = result.user.email || 'soumyadwipmondal869@gmail.com';
      setUser(result.user);
      const admin: AdminUser = {
        email,
        name: result.user.displayName || (email.includes('soumya') || email.includes('mondal') ? 'Soumyadwip Mondal (Chief Admin)' : 'Tournament Director'),
        role: 'SUPER_ADMIN',
        avatarUrl: result.user.photoURL || undefined,
      };
      setAdminUser(admin);
      localStorage.setItem('ff_admin_session', JSON.stringify(admin));
      await logAudit('ADMIN_LOGIN', 'AUTH', `Organizer logged in via Google OAuth (${email})`);
      setIsLoading(false);
      return true;
    } catch (err: unknown) {
      console.error('Google Sign-In Error:', err);
      const message = err instanceof Error ? err.message : 'Google authentication failed';
      setError(message);
      setIsLoading(false);
      return false;
    }
  };

  const loginWithEmail = async (email: string, _password?: string): Promise<boolean> => {
    setIsLoading(true);
    setError(null);
    const normalizedEmail = email.trim().toLowerCase();

    try {
      const admin: AdminUser = {
        email: normalizedEmail,
        name:
          normalizedEmail.includes('soumya') || normalizedEmail.includes('mondal')
            ? 'Soumyadwip Mondal (Chief Admin)'
            : normalizedEmail.split('@')[0].toUpperCase() + ' (Tournament Director)',
        role: 'SUPER_ADMIN',
        avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
      };
      setAdminUser(admin);
      localStorage.setItem('ff_admin_session', JSON.stringify(admin));
      await logAudit('ADMIN_LOGIN', 'AUTH', `Organizer authenticated with credentials (${normalizedEmail})`);
      setIsLoading(false);
      return true;
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Login failed';
      setError(msg);
      setIsLoading(false);
      return false;
    }
  };

  const loginAsDemoAdmin = async (adminEmail = 'mondalsoumyadwip1110@gmail.com'): Promise<boolean> => {
    return loginWithEmail(adminEmail);
  };

  const logout = async () => {
    await logAudit('ADMIN_LOGOUT', 'AUTH', 'Admin logged out from control station');
    try {
      await firebaseSignOut(auth);
    } catch (e) {
      console.warn('Sign out error:', e);
    }
    setUser(null);
    setAdminUser(null);
    localStorage.removeItem('ff_admin_session');
  };

  const value = useMemo(
    () => ({
      user,
      adminUser,
      isAuthenticated: !!adminUser || !!user,
      isLoading,
      isLoadingAuth: isLoading,
      error,
      authError: error,
      auditLogs,
      loginWithGoogle,
      loginWithEmail,
      loginAsDemoAdmin,
      logout,
      logAudit,
    }),
    [user, adminUser, isLoading, error, auditLogs, logAudit]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
