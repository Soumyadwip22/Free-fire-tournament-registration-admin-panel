import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from 'react';
import {
  collection,
  doc,
  setDoc,
  updateDoc,
  deleteDoc,
  onSnapshot,
  getDocs,
  writeBatch,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType, testFirestoreConnection } from '../firebase/config';
import { useAuth } from './AuthContext';
import {
  Tournament,
  Team,
  MatchFixture,
  MatchResultDoc,
  PaymentRecord,
  Announcement,
  OrganizerSettings,
  OverallTeamStanding,
  TeamStatus,
  GroupType,
  MatchStatus,
  PaymentStatus,
} from '../types';
import {
  DEFAULT_SETTINGS,
  INITIAL_TOURNAMENT,
  INITIAL_TEAMS,
  INITIAL_MATCHES,
  INITIAL_MATCH_RESULTS,
  INITIAL_PAYMENTS,
  INITIAL_ANNOUNCEMENTS,
} from '../data/seedData';

interface TournamentContextType {
  tournaments: Tournament[];
  selectedTournament: Tournament | null;
  teams: Team[];
  matches: MatchFixture[];
  matchResults: MatchResultDoc[];
  payments: PaymentRecord[];
  announcements: Announcement[];
  settings: OrganizerSettings;
  overallStandings: OverallTeamStanding[];
  isLiveSyncActive: boolean;
  isLoadingData: boolean;
  lastSyncTime: Date | null;
  error: string | null;
  
  // Actions
  selectTournament: (tournamentId: string) => void;
  saveTournament: (tournament: Tournament) => Promise<void>;
  deleteTournament: (tournamentId: string) => Promise<void>;
  
  // Teams actions
  updateTeamStatus: (teamId: string, status: TeamStatus, reason?: string) => Promise<void>;
  updateTeamSlot: (teamId: string, group: GroupType, slotNumber: number | null) => Promise<void>;
  addTeam: (team: Omit<Team, 'id'>) => Promise<string>;
  updateTeam: (team: Team) => Promise<void>;
  deleteTeam: (teamId: string) => Promise<void>;
  exportTeamsCSV: (filterGroup?: string) => void;

  // Match & Room actions
  saveMatch: (match: MatchFixture) => Promise<void>;
  deleteMatch: (matchId: string) => Promise<void>;
  updateMatchStatus: (matchId: string, status: MatchStatus) => Promise<void>;
  publishRoomCredentials: (matchId: string, roomId: string, roomPassword: string, isPublished: boolean) => Promise<void>;

  // Point Table actions
  saveMatchResult: (result: MatchResultDoc) => Promise<void>;
  deleteMatchResult: (resultId: string) => Promise<void>;
  publishStandings: (force?: boolean) => Promise<void>;
  exportStandingsCSV: (groupFilter?: string) => void;

  // Payment actions
  verifyPayment: (paymentId: string, teamId?: string, decision?: 'VERIFIED' | 'REJECTED', reason?: string) => Promise<void>;
  rejectPayment: (paymentId: string, reason?: string) => Promise<void>;

  // Announcements actions
  saveAnnouncement: (announcement: Announcement) => Promise<void>;
  postAnnouncement: (announcement: Partial<Announcement>) => Promise<void>;
  deleteAnnouncement: (id: string) => Promise<void>;

  // Settings actions
  saveSettings: (settings: OrganizerSettings) => Promise<void>;

  // Database Seed tool
  seedDemoData: (force?: boolean) => Promise<void>;
}

const TournamentContext = createContext<TournamentContextType | null>(null);

export const TournamentProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { logAudit } = useAuth();

  const [tournaments, setTournaments] = useState<Tournament[]>([]);
  const [selectedTournamentId, setSelectedTournamentId] = useState<string>('');
  const [teams, setTeams] = useState<Team[]>([]);
  const [matches, setMatches] = useState<MatchFixture[]>([]);
  const [matchResults, setMatchResults] = useState<MatchResultDoc[]>([]);
  const [payments, setPayments] = useState<PaymentRecord[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [settings, setSettings] = useState<OrganizerSettings>(DEFAULT_SETTINGS);

  const [isLiveSyncActive, setIsLiveSyncActive] = useState<boolean>(false);
  const [isLoadingData, setIsLoadingData] = useState<boolean>(true);
  const [lastSyncTime, setLastSyncTime] = useState<Date | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Test connection on mount
  useEffect(() => {
    testFirestoreConnection().then((connected) => {
      setIsLiveSyncActive(connected);
    });
  }, []);

  // 1. Listen to Settings
  useEffect(() => {
    try {
      const unsub = onSnapshot(
        doc(db, 'settings', 'organizer_config'),
        (snapshot) => {
          if (snapshot.exists()) {
            setSettings(snapshot.data() as OrganizerSettings);
          } else {
            setSettings(DEFAULT_SETTINGS);
          }
          setIsLiveSyncActive(true);
          setLastSyncTime(new Date());
        },
        () => {
          setSettings(DEFAULT_SETTINGS);
        }
      );
      return () => unsub();
    } catch {
      // Ignored: safe local fallback
    }
  }, []);

  // 2. Listen to Tournaments
  useEffect(() => {
    try {
      const unsub = onSnapshot(
        collection(db, 'tournaments'),
        (snapshot) => {
          const list: Tournament[] = snapshot.docs.map((d) => ({
            id: d.id,
            ...(d.data() as Omit<Tournament, 'id'>),
          }));

          if (list.length > 0) {
            setTournaments(list);
            setSelectedTournamentId((prev) => (prev && list.some((t) => t.id === prev) ? prev : list[0].id));
          } else {
            // Seed local default if database is freshly created
            setTournaments([INITIAL_TOURNAMENT]);
            setSelectedTournamentId(INITIAL_TOURNAMENT.id);
          }
          setIsLoadingData(false);
          setIsLiveSyncActive(true);
          setLastSyncTime(new Date());
        },
        () => {
          setTournaments([INITIAL_TOURNAMENT]);
          setSelectedTournamentId(INITIAL_TOURNAMENT.id);
          setIsLoadingData(false);
        }
      );
      return () => unsub();
    } catch {
      setIsLoadingData(false);
    }
  }, []);

  // 3. Listen to Teams in real-time
  useEffect(() => {
    try {
      const unsub = onSnapshot(
        collection(db, 'teams'),
        (snapshot) => {
          if (!snapshot.empty) {
            const list: Team[] = snapshot.docs.map((d) => ({
              id: d.id,
              ...(d.data() as Omit<Team, 'id'>),
            }));
            setTeams(list);
          } else {
            // Fallback seed in memory
            setTeams(INITIAL_TEAMS);
          }
          setIsLiveSyncActive(true);
          setLastSyncTime(new Date());
        },
        () => {
          setTeams(INITIAL_TEAMS);
        }
      );
      return () => unsub();
    } catch {
      // safe fallback
    }
  }, []);

  // 4. Listen to Matches in real-time
  useEffect(() => {
    try {
      const unsub = onSnapshot(
        collection(db, 'matches'),
        (snapshot) => {
          if (!snapshot.empty) {
            const list: MatchFixture[] = snapshot.docs.map((d) => ({
              id: d.id,
              ...(d.data() as Omit<MatchFixture, 'id'>),
            }));
            // Sort by scheduledTime ascending
            list.sort((a, b) => new Date(a.scheduledTime).getTime() - new Date(b.scheduledTime).getTime());
            setMatches(list);
          } else {
            setMatches(INITIAL_MATCHES);
          }
          setIsLiveSyncActive(true);
          setLastSyncTime(new Date());
        },
        () => {
          setMatches(INITIAL_MATCHES);
        }
      );
      return () => unsub();
    } catch {
      // safe fallback
    }
  }, []);

  // 5. Listen to Match Results in real-time
  useEffect(() => {
    try {
      const unsub = onSnapshot(
        collection(db, 'match_results'),
        (snapshot) => {
          if (!snapshot.empty) {
            const list: MatchResultDoc[] = snapshot.docs.map((d) => ({
              id: d.id,
              ...(d.data() as Omit<MatchResultDoc, 'id'>),
            }));
            setMatchResults(list);
          } else {
            setMatchResults(INITIAL_MATCH_RESULTS);
          }
          setIsLiveSyncActive(true);
          setLastSyncTime(new Date());
        },
        () => {
          setMatchResults(INITIAL_MATCH_RESULTS);
        }
      );
      return () => unsub();
    } catch {
      // safe fallback
    }
  }, []);

  // 6. Listen to Payments in real-time
  useEffect(() => {
    try {
      const unsub = onSnapshot(
        collection(db, 'payments'),
        (snapshot) => {
          if (!snapshot.empty) {
            const list: PaymentRecord[] = snapshot.docs.map((d) => ({
              id: d.id,
              ...(d.data() as Omit<PaymentRecord, 'id'>),
            }));
            // Sort latest submitted first
            list.sort((a, b) => new Date(b.submittedAt).getTime() - new Date(a.submittedAt).getTime());
            setPayments(list);
          } else {
            setPayments(INITIAL_PAYMENTS);
          }
          setIsLiveSyncActive(true);
          setLastSyncTime(new Date());
        },
        () => {
          setPayments(INITIAL_PAYMENTS);
        }
      );
      return () => unsub();
    } catch {
      // safe fallback
    }
  }, []);

  // 7. Listen to Announcements
  useEffect(() => {
    try {
      const unsub = onSnapshot(
        collection(db, 'announcements'),
        (snapshot) => {
          if (!snapshot.empty) {
            const list: Announcement[] = snapshot.docs.map((d) => ({
              id: d.id,
              ...(d.data() as Omit<Announcement, 'id'>),
            }));
            list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
            setAnnouncements(list);
          } else {
            setAnnouncements(INITIAL_ANNOUNCEMENTS);
          }
          setIsLiveSyncActive(true);
          setLastSyncTime(new Date());
        },
        () => {
          setAnnouncements(INITIAL_ANNOUNCEMENTS);
        }
      );
      return () => unsub();
    } catch {
      // safe fallback
    }
  }, []);

  // Selected tournament memo
  const selectedTournament = useMemo(() => {
    return tournaments.find((t) => t.id === selectedTournamentId) || tournaments[0] || INITIAL_TOURNAMENT;
  }, [tournaments, selectedTournamentId]);

  // Overall Standings Calculation Engine based on standard Free Fire Esports points
  const overallStandings: OverallTeamStanding[] = useMemo(() => {
    const map = new Map<string, OverallTeamStanding>();

    // Initialize map from qualified/registered teams
    teams.forEach((team) => {
      map.set(team.id, {
        teamId: team.id,
        teamName: team.teamName,
        teamTag: team.teamTag,
        group: team.group,
        matchesPlayed: 0,
        booyahs: 0,
        placementPoints: 0,
        killPoints: 0,
        totalPoints: 0,
        rank: 1,
      });
    });

    // Aggregate from published match results
    matchResults.forEach((resultDoc) => {
      if (!resultDoc.isPublished && resultDoc.isPublished !== undefined) return;
      resultDoc.scores.forEach((row) => {
        let standing = map.get(row.teamId);
        if (!standing) {
          standing = {
            teamId: row.teamId,
            teamName: row.teamName,
            teamTag: row.teamTag,
            group: resultDoc.group,
            matchesPlayed: 0,
            booyahs: 0,
            placementPoints: 0,
            killPoints: 0,
            totalPoints: 0,
            rank: 1,
          };
          map.set(row.teamId, standing);
        }

        standing.matchesPlayed += 1;
        if (row.isBooyah || row.placement === 1) {
          standing.booyahs += 1;
        }
        standing.placementPoints += row.placementPoints || 0;
        standing.killPoints += row.killPoints || row.kills || 0;
        standing.totalPoints += row.totalPoints || (row.placementPoints + row.killPoints);
      });
    });

    // Sort by Official Esports Tiebreaker:
    // 1. Total Points
    // 2. Total Booyahs (1st placements)
    // 3. Total Placement Points
    // 4. Total Kill Points
    const standingsList = Array.from(map.values()).sort((a, b) => {
      if (b.totalPoints !== a.totalPoints) return b.totalPoints - a.totalPoints;
      if (b.booyahs !== a.booyahs) return b.booyahs - a.booyahs;
      if (b.placementPoints !== a.placementPoints) return b.placementPoints - a.placementPoints;
      return b.killPoints - a.killPoints;
    });

    // Assign rank 1..N
    return standingsList.map((st, idx) => ({
      ...st,
      rank: idx + 1,
    }));
  }, [teams, matchResults]);

  // Actions Implementation

  const selectTournament = useCallback((id: string) => {
    setSelectedTournamentId(id);
  }, []);

  const saveTournament = async (tourn: Tournament) => {
    try {
      await setDoc(doc(db, 'tournaments', tourn.id), tourn, { merge: true });
      await logAudit('SAVE_TOURNAMENT', 'TOURNAMENT', `Saved tournament details for "${tourn.title}"`, tourn.id, tourn.title);
    } catch (err) {
      console.warn('Remote write failed, saving locally:', err);
      setTournaments((prev) => {
        const idx = prev.findIndex((t) => t.id === tourn.id);
        if (idx >= 0) {
          const next = [...prev];
          next[idx] = tourn;
          return next;
        }
        return [tourn, ...prev];
      });
    }
  };

  const deleteTournament = async (tournId: string) => {
    try {
      await deleteDoc(doc(db, 'tournaments', tournId));
      await logAudit('DELETE_TOURNAMENT', 'TOURNAMENT', `Deleted tournament ${tournId}`, tournId);
    } catch (err) {
      console.warn('Remote delete failed, deleting locally:', err);
      setTournaments((prev) => prev.filter((t) => t.id !== tournId));
    }
  };

  const updateTeamStatus = async (teamId: string, status: TeamStatus, reason?: string) => {
    const team = teams.find((t) => t.id === teamId);
    const updates: Partial<Team> = {
      status,
      notes: reason || team?.notes || '',
    };
    try {
      await updateDoc(doc(db, 'teams', teamId), updates);
      await logAudit('UPDATE_TEAM_STATUS', 'TEAM', `Changed status to ${status}${reason ? ` (${reason})` : ''}`, teamId, team?.teamName);
    } catch (err) {
      console.warn('Remote update error, applying locally:', err);
      setTeams((prev) => prev.map((t) => (t.id === teamId ? { ...t, ...updates } : t)));
    }
  };

  const updateTeamSlot = async (teamId: string, group: GroupType, slotNumber: number | null) => {
    const team = teams.find((t) => t.id === teamId);
    const updates: Partial<Team> = {
      group,
      slotNumber,
      status: group !== 'Unassigned' && slotNumber ? 'QUALIFIED' : (team?.status || 'QUALIFIED'),
    };
    try {
      await updateDoc(doc(db, 'teams', teamId), updates);
      await logAudit('ALLOCATE_SLOT', 'TEAM', `Assigned to ${group} - Slot #${slotNumber || 'Unset'}`, teamId, team?.teamName);
    } catch (err) {
      console.warn('Remote slot update error, applying locally:', err);
      setTeams((prev) => prev.map((t) => (t.id === teamId ? { ...t, ...updates } : t)));
    }
  };

  const addTeam = async (teamData: Omit<Team, 'id'>): Promise<string> => {
    const newId = 'team-' + Date.now().toString(36) + Math.random().toString(36).substring(2, 6);
    const newTeam: Team = {
      ...teamData,
      id: newId,
    };
    try {
      await setDoc(doc(db, 'teams', newId), newTeam);
      await logAudit('ADD_TEAM', 'TEAM', `Registered team "${newTeam.teamName}"`, newId, newTeam.teamName);
    } catch (err) {
      console.warn('Remote add team error, applying locally:', err);
      setTeams((prev) => [newTeam, ...prev]);
    }
    return newId;
  };

  const updateTeam = async (team: Team) => {
    try {
      await setDoc(doc(db, 'teams', team.id), team, { merge: true });
      await logAudit('UPDATE_TEAM', 'TEAM', `Updated squad roster and details for ${team.teamName}`, team.id, team.teamName);
    } catch (err) {
      console.warn('Remote update team error, applying locally:', err);
      setTeams((prev) => prev.map((t) => (t.id === team.id ? team : t)));
    }
  };

  const deleteTeam = async (teamId: string) => {
    const team = teams.find((t) => t.id === teamId);
    try {
      await deleteDoc(doc(db, 'teams', teamId));
      await logAudit('DELETE_TEAM', 'TEAM', `Removed team "${team?.teamName || teamId}" from tournament roster`, teamId, team?.teamName);
    } catch (err) {
      console.warn('Remote delete team error, applying locally:', err);
      setTeams((prev) => prev.filter((t) => t.id !== teamId));
    }
  };

  const exportTeamsCSV = (filterGroup?: string) => {
    const targetTeams = filterGroup && filterGroup !== 'ALL' ? teams.filter((t) => t.group === filterGroup) : teams;

    const rows = [
      ['Team ID', 'Team Name', 'Tag', 'Group', 'Slot', 'Status', 'Payment Status', 'Captain Name', 'Captain Phone', 'Captain UID', 'Players (Name | IGN | UID | Role)', 'Registered At'],
      ...targetTeams.map((t) => [
        t.id,
        `"${t.teamName.replace(/"/g, '""')}"`,
        t.teamTag,
        t.group,
        t.slotNumber ?? 'N/A',
        t.status,
        t.paymentStatus,
        `"${t.captainName.replace(/"/g, '""')}"`,
        t.captainPhone,
        t.captainUid,
        `"${t.players.map((p) => `${p.name} (${p.ign} - ${p.uid} - ${p.role || 'Player'})`).join('; ')}"`,
        t.registeredAt,
      ]),
    ];

    const csvContent = 'data:text/csv;charset=utf-8,' + rows.map((e) => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `FF_Esports_Roster_${filterGroup || 'All'}_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const saveMatch = async (match: MatchFixture) => {
    try {
      await setDoc(doc(db, 'matches', match.id), match, { merge: true });
      await logAudit('SAVE_MATCH', 'MATCH', `Saved fixture "${match.title}" on map ${match.map}`, match.id, match.title);
    } catch (err) {
      console.warn('Remote save match error, saving locally:', err);
      setMatches((prev) => {
        const idx = prev.findIndex((m) => m.id === match.id);
        if (idx >= 0) {
          const next = [...prev];
          next[idx] = match;
          return next;
        }
        return [match, ...prev];
      });
    }
  };

  const deleteMatch = async (matchId: string) => {
    const match = matches.find((m) => m.id === matchId);
    try {
      await deleteDoc(doc(db, 'matches', matchId));
      await logAudit('DELETE_MATCH', 'MATCH', `Deleted match fixture "${match?.title || matchId}"`, matchId, match?.title);
    } catch (err) {
      console.warn('Remote delete match error, applying locally:', err);
      setMatches((prev) => prev.filter((m) => m.id !== matchId));
    }
  };

  const updateMatchStatus = async (matchId: string, status: MatchStatus) => {
    const match = matches.find((m) => m.id === matchId);
    const updates: Partial<MatchFixture> = { status, updatedAt: new Date().toISOString() };
    try {
      await updateDoc(doc(db, 'matches', matchId), updates);
      await logAudit('UPDATE_MATCH_STATUS', 'MATCH', `Changed match status to ${status}`, matchId, match?.title);
    } catch (err) {
      console.warn('Remote match status error, applying locally:', err);
      setMatches((prev) => prev.map((m) => (m.id === matchId ? { ...m, ...updates } : m)));
    }
  };

  const publishRoomCredentials = async (matchId: string, roomId: string, roomPassword: string, isPublished: boolean) => {
    const match = matches.find((m) => m.id === matchId);
    const updates: Partial<MatchFixture> = {
      roomId,
      roomPassword,
      isCredentialsPublished: isPublished,
      credentialsReleaseTime: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    try {
      await updateDoc(doc(db, 'matches', matchId), updates);
      await logAudit(
        isPublished ? 'PUBLISH_ROOM_CREDENTIALS' : 'UNPUBLISH_ROOM_CREDENTIALS',
        'MATCH',
        `${isPublished ? 'Published' : 'Hidden'} Room ID (${roomId}) for "${match?.title}"`,
        matchId,
        match?.title
      );
    } catch (err) {
      console.warn('Remote room creds error, applying locally:', err);
      setMatches((prev) => prev.map((m) => (m.id === matchId ? { ...m, ...updates } : m)));
    }
  };

  const saveMatchResult = async (result: MatchResultDoc) => {
    try {
      await setDoc(doc(db, 'match_results', result.id), result, { merge: true });
      // Also update match fixture status to COMPLETED
      if (result.matchId) {
        await updateDoc(doc(db, 'matches', result.matchId), {
          status: 'COMPLETED',
          updatedAt: new Date().toISOString(),
        }).catch(() => null);
      }
      await logAudit('SAVE_MATCH_RESULT', 'STANDINGS', `Recorded points table for match "${result.matchTitle}" with ${result.scores.length} teams`, result.id, result.matchTitle);
    } catch (err) {
      console.warn('Remote save result error, applying locally:', err);
      setMatchResults((prev) => {
        const idx = prev.findIndex((r) => r.id === result.id);
        if (idx >= 0) {
          const next = [...prev];
          next[idx] = result;
          return next;
        }
        return [result, ...prev];
      });
    }
  };

  const deleteMatchResult = async (resultId: string) => {
    try {
      await deleteDoc(doc(db, 'match_results', resultId));
      await logAudit('DELETE_MATCH_RESULT', 'STANDINGS', `Deleted result ${resultId}`, resultId);
    } catch (err) {
      setMatchResults((prev) => prev.filter((r) => r.id !== resultId));
    }
  };

  const publishStandings = async () => {
    try {
      const standingDoc = {
        tournamentId: selectedTournament.id,
        tournamentTitle: selectedTournament.title,
        publishedAt: new Date().toISOString(),
        standings: overallStandings,
      };
      await setDoc(doc(db, 'standings', selectedTournament.id), standingDoc, { merge: true });
      await logAudit('PUBLISH_STANDINGS', 'STANDINGS', `Published official tournament point table & leaderboard to public player app`, selectedTournament.id, selectedTournament.title);
    } catch (err) {
      console.warn('Standings publish fallback:', err);
    }
  };

  const exportStandingsCSV = (groupFilter: string = 'OVERALL') => {
    const list = groupFilter === 'OVERALL' ? overallStandings : overallStandings.filter((s) => s.group === groupFilter);
    const headers = ['Rank', 'Team Name', 'Tag', 'Group', 'Matches Played', 'Booyahs', 'Placement Points', 'Kill Points', 'Total Points'];
    const rows = list.map((s, idx) => [
      idx + 1,
      `"${s.teamName}"`,
      s.teamTag || '',
      s.group,
      s.matchesPlayed,
      s.booyahs,
      s.placementPoints,
      s.killPoints,
      s.totalPoints,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `FF_Standings_${groupFilter.replace(/\s+/g, '_')}_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const verifyPayment = async (
    paymentId: string,
    targetTeamId?: string,
    decision: 'VERIFIED' | 'REJECTED' = 'VERIFIED',
    reason?: string
  ) => {
    const payment = payments.find((p) => p.id === paymentId);
    const teamId = targetTeamId || payment?.teamId;
    const team = teams.find((t) => t.id === teamId);

    const paymentUpdates: Partial<PaymentRecord> = {
      status: decision,
      rejectionReason: reason || '',
      verifiedAt: new Date().toISOString(),
      verifiedBy: 'mondalsoumyadwip1110@gmail.com',
    };

    const teamUpdates: Partial<Team> = {
      paymentStatus: decision,
      status: decision === 'VERIFIED' ? 'QUALIFIED' : (team?.status || 'PENDING_VERIFICATION'),
      verifiedAt: new Date().toISOString(),
      verifiedBy: 'mondalsoumyadwip1110@gmail.com',
      notes: reason || team?.notes,
    };

    try {
      await updateDoc(doc(db, 'payments', paymentId), paymentUpdates);
      if (teamId) {
        await updateDoc(doc(db, 'teams', teamId), teamUpdates);
      }
      await logAudit(
        decision === 'VERIFIED' ? 'PAYMENT_APPROVED' : 'PAYMENT_REJECTED',
        'PAYMENT',
        `${decision === 'VERIFIED' ? 'Verified & Approved' : 'Rejected'} payment of ₹${payment?.amount || 150} (UTR: ${payment?.utrNumber})${reason ? ` - ${reason}` : ''}`,
        paymentId,
        payment?.teamName
      );
    } catch (err) {
      console.warn('Remote payment verify error, updating locally:', err);
      setPayments((prev) => prev.map((p) => (p.id === paymentId ? { ...p, ...paymentUpdates } : p)));
      if (teamId) {
        setTeams((prev) => prev.map((t) => (t.id === teamId ? { ...t, ...teamUpdates } : t)));
      }
    }
  };

  const rejectPayment = async (paymentId: string, reason?: string) => {
    await verifyPayment(paymentId, undefined, 'REJECTED', reason);
  };

  const postAnnouncement = async (announcementData: Partial<Announcement>) => {
    const newId = 'ann-' + Date.now().toString(36);
    const fullAnnouncement: Announcement = {
      id: newId,
      tournamentId: selectedTournament?.id || 'tourn-1',
      title: announcementData.title || 'Official Notice',
      message: announcementData.message || '',
      category: announcementData.category || 'GENERAL',
      priority: announcementData.priority || 'normal',
      pinned: announcementData.pinned ?? false,
      targetGroup: announcementData.targetGroup || 'ALL',
      createdAt: new Date().toISOString(),
      createdBy: 'mondalsoumyadwip1110@gmail.com',
    };
    await saveAnnouncement(fullAnnouncement);
  };

  const saveAnnouncement = async (announcement: Announcement) => {
    try {
      await setDoc(doc(db, 'announcements', announcement.id), announcement, { merge: true });
      await logAudit('POST_ANNOUNCEMENT', 'ANNOUNCEMENT', `Posted broadcast notice "${announcement.title}" [${announcement.category}]`, announcement.id, announcement.title);
    } catch (err) {
      console.warn('Remote announcement save error, saving locally:', err);
      setAnnouncements((prev) => {
        const idx = prev.findIndex((a) => a.id === announcement.id);
        if (idx >= 0) {
          const next = [...prev];
          next[idx] = announcement;
          return next;
        }
        return [announcement, ...prev];
      });
    }
  };

  const deleteAnnouncement = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'announcements', id));
      await logAudit('DELETE_ANNOUNCEMENT', 'ANNOUNCEMENT', `Deleted announcement ${id}`, id);
    } catch (err) {
      setAnnouncements((prev) => prev.filter((a) => a.id !== id));
    }
  };

  const saveSettings = async (newSettings: OrganizerSettings) => {
    try {
      await setDoc(doc(db, 'settings', 'organizer_config'), newSettings, { merge: true });
      setSettings(newSettings);
      await logAudit('UPDATE_SETTINGS', 'SETTINGS', `Updated Organizer UPI Config (${newSettings.upiId}) and contact channels`);
    } catch (err) {
      console.warn('Remote settings save error, saving locally:', err);
      setSettings(newSettings);
    }
  };

  // Seed Rich Sample Esports Data into Firestore
  const seedDemoData = async (force = false) => {
    setIsLoadingData(true);
    try {
      const batch = writeBatch(db);

      // Seed tournament
      batch.set(doc(db, 'tournaments', INITIAL_TOURNAMENT.id), INITIAL_TOURNAMENT, { merge: true });

      // Seed settings
      batch.set(doc(db, 'settings', 'organizer_config'), DEFAULT_SETTINGS, { merge: true });

      // Seed teams
      INITIAL_TEAMS.forEach((team) => {
        batch.set(doc(db, 'teams', team.id), team, { merge: true });
      });

      // Seed matches
      INITIAL_MATCHES.forEach((match) => {
        batch.set(doc(db, 'matches', match.id), match, { merge: true });
      });

      // Seed match results
      INITIAL_MATCH_RESULTS.forEach((res) => {
        batch.set(doc(db, 'match_results', res.id), res, { merge: true });
      });

      // Seed payments
      INITIAL_PAYMENTS.forEach((pay) => {
        batch.set(doc(db, 'payments', pay.id), pay, { merge: true });
      });

      // Seed announcements
      INITIAL_ANNOUNCEMENTS.forEach((ann) => {
        batch.set(doc(db, 'announcements', ann.id), ann, { merge: true });
      });

      await batch.commit();

      setTournaments([INITIAL_TOURNAMENT]);
      setSelectedTournamentId(INITIAL_TOURNAMENT.id);
      setTeams(INITIAL_TEAMS);
      setMatches(INITIAL_MATCHES);
      setMatchResults(INITIAL_MATCH_RESULTS);
      setPayments(INITIAL_PAYMENTS);
      setAnnouncements(INITIAL_ANNOUNCEMENTS);
      setSettings(DEFAULT_SETTINGS);

      await logAudit('DATABASE_SEED', 'SETTINGS', 'Initialized complete Free Fire Esports mock tournament dataset with 24 teams, fixtures, and payments');
    } catch (err) {
      console.warn('Batch seed failed, populating in-memory states:', err);
      setTournaments([INITIAL_TOURNAMENT]);
      setSelectedTournamentId(INITIAL_TOURNAMENT.id);
      setTeams(INITIAL_TEAMS);
      setMatches(INITIAL_MATCHES);
      setMatchResults(INITIAL_MATCH_RESULTS);
      setPayments(INITIAL_PAYMENTS);
      setAnnouncements(INITIAL_ANNOUNCEMENTS);
      setSettings(DEFAULT_SETTINGS);
    } finally {
      setIsLoadingData(false);
    }
  };

  const value = useMemo(
    () => ({
      tournaments,
      selectedTournament,
      teams,
      matches,
      matchResults,
      payments,
      announcements,
      settings,
      overallStandings,
      isLiveSyncActive,
      isLoadingData,
      lastSyncTime,
      error,
      selectTournament,
      saveTournament,
      deleteTournament,
      updateTeamStatus,
      updateTeamSlot,
      addTeam,
      updateTeam,
      deleteTeam,
      exportTeamsCSV,
      saveMatch,
      deleteMatch,
      updateMatchStatus,
      publishRoomCredentials,
      saveMatchResult,
      deleteMatchResult,
      publishStandings,
      exportStandingsCSV,
      verifyPayment,
      rejectPayment,
      saveAnnouncement,
      postAnnouncement,
      deleteAnnouncement,
      saveSettings,
      seedDemoData,
    }),
    [
      tournaments,
      selectedTournament,
      teams,
      matches,
      matchResults,
      payments,
      announcements,
      settings,
      overallStandings,
      isLiveSyncActive,
      isLoadingData,
      lastSyncTime,
      error,
      selectTournament,
      saveTournament,
      deleteTournament,
      updateTeamStatus,
      updateTeamSlot,
      addTeam,
      updateTeam,
      deleteTeam,
      exportTeamsCSV,
      saveMatch,
      deleteMatch,
      updateMatchStatus,
      publishRoomCredentials,
      saveMatchResult,
      deleteMatchResult,
      publishStandings,
      exportStandingsCSV,
      verifyPayment,
      rejectPayment,
      saveAnnouncement,
      postAnnouncement,
      deleteAnnouncement,
      saveSettings,
      seedDemoData,
    ]
  );

  return <TournamentContext.Provider value={value}>{children}</TournamentContext.Provider>;
};

export const useTournament = () => {
  const context = useContext(TournamentContext);
  if (!context) {
    throw new Error('useTournament must be used within a TournamentProvider');
  }
  return context;
};
