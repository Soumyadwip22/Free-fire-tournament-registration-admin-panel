import React, { useState } from 'react';
import { HashRouter, Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { TournamentProvider, useTournament } from './context/TournamentContext';
import { Header } from './components/Header';
import { Sidebar, ActiveTab } from './components/Sidebar';
import { DashboardView } from './components/views/DashboardView';
import { TournamentManagerView } from './components/views/TournamentManagerView';
import { TeamManagementView } from './components/views/TeamManagementView';
import { MatchSchedulerView } from './components/views/MatchSchedulerView';
import { PointTableCalculatorView } from './components/views/PointTableCalculatorView';
import { PaymentVerificationView } from './components/views/PaymentVerificationView';
import { AnnouncementsView } from './components/views/AnnouncementsView';
import { SettingsView } from './components/views/SettingsView';
import { AuditLogsView } from './components/views/AuditLogsView';
import { PublicPlayerPreviewModal } from './components/modals/PublicPlayerPreviewModal';
import { AuthScreen } from './components/AuthScreen';
import { Flame, Loader2 } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const { isAuthenticated, isLoadingAuth } = useAuth();
  const { isLoadingData, announcements, isLiveSyncActive } = useTournament();
  const navigate = useNavigate();
  const location = useLocation();

  const [isPlayerPreviewOpen, setIsPlayerPreviewOpen] = useState(false);

  // Derive active tab from current route path
  const currentPath = location.pathname.replace(/^\//, '') || 'dashboard';
  const activeTab: ActiveTab = (
    ['dashboard', 'tournament', 'teams', 'matches', 'standings', 'payments', 'announcements', 'settings', 'audit'].includes(currentPath)
      ? currentPath
      : 'dashboard'
  ) as ActiveTab;

  const handleTabChange = (tab: ActiveTab) => {
    navigate(tab === 'dashboard' ? '/' : `/${tab}`);
  };

  if (isLoadingAuth) {
    return (
      <div className="min-h-screen bg-[#0A0A0C] flex flex-col items-center justify-center space-y-4">
        <div className="w-12 h-12 bg-[#FF4D00] rounded-sm flex items-center justify-center font-bold text-xl italic font-serif text-black animate-pulse shadow-xl shadow-orange-950/50">
          FF
        </div>
        <div className="text-xs font-mono text-white/40 flex items-center gap-2 uppercase tracking-wider">
          <Loader2 className="w-4 h-4 animate-spin text-[#FF4D00]" />
          <span>CONNECTING TO FIRESTORE ESPORTS REPOSITORY...</span>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <AuthScreen />;
  }

  const latestNotice = announcements[0]?.message || 'Room rotation & 15m unlock engine synchronized with Firestore database.';

  return (
    <div className="min-h-screen bg-[#0A0A0C] text-zinc-100 flex flex-col antialiased selection:bg-[#FF4D00] selection:text-white">
      {/* Station Header */}
      <Header onOpenPlayerPreview={() => setIsPlayerPreviewOpen(true)} />

      {/* Body: Sidebar + Active View */}
      <div className="flex flex-1 overflow-hidden">
        <div className="hidden md:block">
          <Sidebar activeTab={activeTab} setActiveTab={handleTabChange} />
        </div>

        <main className="flex-1 overflow-y-auto min-h-[calc(100vh-5rem)] pb-10">
          {/* Mobile Tab Scroller */}
          <div className="md:hidden p-2 bg-[#0D0D0F] border-b border-white/5 overflow-x-auto flex items-center gap-1.5 sticky top-0 z-30">
            {(
              [
                { id: 'dashboard', label: 'Operations' },
                { id: 'tournament', label: 'Tournament' },
                { id: 'teams', label: 'Teams' },
                { id: 'matches', label: '15m Room' },
                { id: 'standings', label: 'Points' },
                { id: 'payments', label: 'Payments' },
                { id: 'announcements', label: 'Notices' },
                { id: 'settings', label: 'Settings' },
                { id: 'audit', label: 'Audit' },
              ] as const
            ).map((t) => (
              <button
                key={t.id}
                onClick={() => handleTabChange(t.id as ActiveTab)}
                className={`px-3 py-1.5 rounded-sm text-[11px] font-mono uppercase tracking-wider whitespace-nowrap transition-colors cursor-pointer ${
                  activeTab === t.id
                    ? 'bg-[#FF4D00] text-black font-black'
                    : 'bg-white/5 text-white/40'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <Routes>
            <Route
              path="/"
              element={
                <DashboardView
                  setActiveTab={handleTabChange}
                  onOpenPlayerPreview={() => setIsPlayerPreviewOpen(true)}
                />
              }
            />
            <Route
              path="/dashboard"
              element={
                <DashboardView
                  setActiveTab={handleTabChange}
                  onOpenPlayerPreview={() => setIsPlayerPreviewOpen(true)}
                />
              }
            />
            <Route path="/tournament" element={<TournamentManagerView />} />
            <Route path="/teams" element={<TeamManagementView />} />
            <Route path="/matches" element={<MatchSchedulerView />} />
            <Route path="/standings" element={<PointTableCalculatorView />} />
            <Route path="/payments" element={<PaymentVerificationView />} />
            <Route path="/announcements" element={<AnnouncementsView />} />
            <Route path="/settings" element={<SettingsView />} />
            <Route path="/audit" element={<AuditLogsView />} />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </main>
      </div>

      {/* Editorial Broadcast Ticker Footer */}
      <footer className="h-8 bg-[#FF4D00] flex items-center px-4 justify-between font-mono text-[10px] font-black text-black uppercase shrink-0 sticky bottom-0 z-30 select-none shadow-lg">
        <div className="flex items-center space-x-4 overflow-hidden whitespace-nowrap">
          <span className="tracking-wide">
            Notice: {latestNotice}
          </span>
          <span className="opacity-50">|</span>
          <span className="tracking-wide">
            Mode: Free Fire Battle Royale 4v4v4v4
          </span>
          <span className="opacity-50">|</span>
          <span className="tracking-wide">
            Official Organizer: Soumyadwip Mondal
          </span>
        </div>
        <div className="hidden sm:flex items-center gap-2 pl-4 shrink-0 font-bold">
          <span>SESSION: ACTIVE-ROOT</span>
          <span>•</span>
          <span>{isLiveSyncActive ? 'FIRESTORE LIVE' : 'OFFLINE'}</span>
        </div>
      </footer>

      {/* Public Player Live Hub Preview Modal */}
      {isPlayerPreviewOpen && (
        <PublicPlayerPreviewModal onClose={() => setIsPlayerPreviewOpen(false)} />
      )}
    </div>
  );
};

export default function App() {
  return (
    <HashRouter>
      <AuthProvider>
        <TournamentProvider>
          <MainAppContent />
        </TournamentProvider>
      </AuthProvider>
    </HashRouter>
  );
}
