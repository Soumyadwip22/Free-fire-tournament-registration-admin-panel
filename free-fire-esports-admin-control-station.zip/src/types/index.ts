export type TournamentStatus = 'upcoming' | 'ongoing' | 'registration_closed' | 'completed';
export type TournamentStage = 'Registration' | 'Qualifiers' | 'Group Stage' | 'Semi Finals' | 'Grand Finals';
export type GameMode = 'Squad' | 'Duo' | 'Solo';
export type TeamStatus = 'PENDING_VERIFICATION' | 'QUALIFIED' | 'WAITLIST' | 'REJECTED' | 'DISQUALIFIED';
export type PaymentStatus = 'UNPAID' | 'SUBMITTED' | 'VERIFIED' | 'REJECTED';
export type GroupType = 'Unassigned' | 'Group A' | 'Group B' | 'Group C' | 'Grand Finals';
export type MatchStatus = 'SCHEDULED' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';
export type MapType = 'Bermuda' | 'Purgatory' | 'Kalahari' | 'Alpine' | 'NexTerra';
export type AnnouncementCategory = 'URGENT' | 'SCHEDULE_CHANGE' | 'RULE_UPDATE' | 'ROOM_ALERT' | 'GENERAL';

export interface Player {
  name: string;
  ign: string; // In-Game Name
  uid: string; // Free Fire Player UID
  role?: 'Captain' | 'Fragger' | 'Sniper' | 'Support' | 'IGL' | 'Substitute';
}

export interface Team {
  id: string;
  tournamentId: string;
  teamName: string;
  teamTag: string;
  logoUrl?: string;
  captainName: string;
  captainPhone: string;
  captainEmail?: string;
  captainUid: string;
  players: Player[];
  status: TeamStatus;
  group: GroupType;
  slotNumber: number | null; // 1 to 12
  paymentStatus: PaymentStatus;
  utrNumber?: string;
  paymentScreenshotUrl?: string;
  amountPaid?: number;
  registeredAt: string;
  notes?: string;
  verifiedAt?: string;
  verifiedBy?: string;
}

export interface PrizeBreakdown {
  first: number;
  second: number;
  third: number;
  mvp: number;
  other?: string;
}

export interface Tournament {
  id: string;
  title: string;
  gameMode: GameMode;
  prizePool: number;
  prizeBreakdown: PrizeBreakdown;
  entryFee: number;
  maxSlots: number;
  registeredTeamsCount?: number;
  registrationDeadline: string;
  startDate: string;
  endDate?: string;
  bannerUrl?: string;
  rules: string;
  status: TournamentStatus;
  currentStage: TournamentStage;
  organizerContact: string;
  createdAt: string;
  updatedAt?: string;
}

export interface MatchFixture {
  id: string;
  tournamentId: string;
  matchNumber: number;
  title: string; // e.g., "Group A - Match 1"
  stage: GroupType;
  map: MapType;
  scheduledTime: string; // ISO String
  roomId?: string;
  roomPassword?: string;
  credentialsReleaseTime?: string; // 15 mins before scheduledTime
  isCredentialsPublished: boolean;
  autoRelease15Min: boolean;
  status: MatchStatus;
  liveStreamUrl?: string;
  assignedTeams?: {
    slotNumber: number;
    teamId: string;
    teamName: string;
    teamTag?: string;
  }[];
  createdAt: string;
  updatedAt?: string;
}

export interface MatchScoreRow {
  teamId: string;
  teamName: string;
  teamTag?: string;
  slotNumber?: number;
  placement: number; // 1-12
  placementPoints: number; // e.g. 1st: 12, 2nd: 9, 3rd: 8...
  kills: number; // 1pt per kill
  killPoints?: number;
  totalPoints: number;
  isBooyah: boolean;
}

export interface MatchResultDoc {
  id: string;
  matchId: string;
  tournamentId: string;
  matchTitle?: string;
  map?: MapType;
  group?: GroupType;
  recordedAt: string;
  recordedBy: string;
  scores: MatchScoreRow[];
  isPublished?: boolean;
  isFinalized?: boolean;
  mvpPlayer?: {
    name: string;
    ign: string;
    teamName: string;
    kills: number;
    damage: number;
  };
}

export type MatchResult = MatchResultDoc;
export type TeamScore = MatchScoreRow;

export interface OverallTeamStanding {
  teamId: string;
  teamName: string;
  teamTag?: string;
  group: GroupType;
  matchesPlayed: number;
  booyahs: number;
  placementPoints: number;
  killPoints: number;
  totalPoints: number;
  rank: number;
}

export interface PaymentRecord {
  id: string;
  tournamentId: string;
  teamId: string;
  teamName: string;
  captainName: string;
  captainPhone: string;
  amount: number;
  utrNumber: string;
  screenshotUrl: string;
  paymentMethod: 'UPI' | 'GPay' | 'PhonePe' | 'Paytm' | 'QR';
  status: 'PENDING' | 'VERIFIED' | 'REJECTED';
  rejectionReason?: string;
  submittedAt: string;
  verifiedAt?: string;
  verifiedBy?: string;
}

export interface Announcement {
  id: string;
  tournamentId?: string;
  title: string;
  message: string;
  category: AnnouncementCategory;
  priority: 'high' | 'normal';
  pinned: boolean;
  targetGroup: 'ALL' | GroupType;
  createdAt: string;
  createdBy: string;
}

export interface OrganizerSettings {
  organizerName: string;
  upiId: string;
  payeeName: string;
  qrCodeUrl: string;
  whatsappGroupUrl: string;
  discordInviteUrl: string;
  helplineNumber: string;
  supportEmail: string;
  officialRulebookUrl: string;
  streamChannelUrl: string;
  pointSystem: {
    firstPlace: number;
    secondPlace: number;
    thirdPlace: number;
    fourthPlace: number;
    fifthPlace: number;
    sixthPlace: number;
    seventhPlace: number;
    eighthPlace: number;
    ninthPlace: number;
    tenthPlace: number;
    eleventhPlace: number;
    twelfthPlace: number;
    killPoint: number;
  };
}

export interface AuditLog {
  id: string;
  action: string;
  category: 'TEAM' | 'MATCH' | 'PAYMENT' | 'TOURNAMENT' | 'STANDINGS' | 'ANNOUNCEMENT' | 'SETTINGS' | 'AUTH';
  targetId?: string;
  targetName?: string;
  adminEmail: string;
  details: string;
  timestamp: string;
}

export interface AdminUser {
  email: string;
  name: string;
  role: 'SUPER_ADMIN' | 'ORGANIZER' | 'HEAD_REFEREE';
  avatarUrl?: string;
}
