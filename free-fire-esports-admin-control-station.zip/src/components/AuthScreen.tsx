import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Flame,
  ShieldCheck,
  Lock,
  Mail,
  ArrowRight,
  AlertCircle,
  Sparkles,
  Trophy,
  LogIn,
} from 'lucide-react';

export const AuthScreen: React.FC = () => {
  const { loginWithEmail, loginWithGoogle, authError } = useAuth();
  const [emailInput, setEmailInput] = useState('mondalsoumyadwip1110@gmail.com');
  const [passwordInput, setPasswordInput] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    await loginWithEmail(emailInput, passwordInput || 'admin123');
    setIsSubmitting(false);
  };

  const handleQuickAuthorize = async () => {
    setIsSubmitting(true);
    await loginWithEmail('mondalsoumyadwip1110@gmail.com', 'admin123');
    setIsSubmitting(false);
  };

  const handleGoogleAuth = async () => {
    setIsSubmitting(true);
    await loginWithGoogle();
    setIsSubmitting(false);
  };

  return (
    <div className="min-h-screen bg-[#0A0A0C] flex items-center justify-center p-4 relative overflow-hidden select-none font-mono">
      {/* Editorial Minimal Background */}
      <div className="absolute top-1/4 -left-32 w-96 h-96 bg-[#FF4D00]/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -right-32 w-96 h-96 bg-[#00FF66]/5 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-md relative z-10 space-y-4">
        {/* Brand Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-xs bg-[#FF4D00] text-black font-serif italic font-black text-2xl shadow-xl shadow-orange-950/50 mb-1">
            FF
          </div>
          <div className="text-[10px] font-black tracking-widest text-[#FF4D00] uppercase">
            Official Tournament Operations
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold font-serif italic text-white tracking-tight">
            Organizer Command Station
          </h1>
          <p className="text-xs text-white/40 tracking-tight">
            Free Fire Esports Control, 15m Room Engine & Points Gateway
          </p>
        </div>

        {/* Login Card */}
        <div className="p-6 sm:p-7 rounded-xs bg-[#18181B] border border-white/10 shadow-2xl space-y-5">
          <div className="space-y-1 text-center border-b border-white/5 pb-3">
            <div className="flex items-center justify-center gap-1.5 text-[10px] font-black text-[#FF4D00] uppercase tracking-widest">
              <ShieldCheck className="w-3.5 h-3.5 text-[#FF4D00]" />
              <span>Restricted Organizer Security Gateway</span>
            </div>
            <p className="text-[11px] text-white/40">
              Access granted to verified tournament administrators
            </p>
          </div>

          {authError && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/30 rounded-xs text-rose-400 text-xs flex items-start gap-2 font-sans">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
              <span>{authError}</span>
            </div>
          )}

          {/* Quick 1-Click Chief Organizer Authorization Button */}
          <button
            onClick={handleQuickAuthorize}
            disabled={isSubmitting}
            className="w-full py-3 px-4 rounded-xs bg-[#FF4D00] hover:bg-[#E04400] text-black font-black tracking-wider text-xs uppercase transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer group"
          >
            <ShieldCheck className="w-4 h-4 text-black" />
            <span>Enter as Soumyadwip Mondal (Admin)</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>

          {/* Google Sign-In Option */}
          <button
            onClick={handleGoogleAuth}
            disabled={isSubmitting}
            className="w-full py-2.5 px-4 rounded-xs bg-white/5 hover:bg-white/10 border border-white/10 text-white font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <LogIn className="w-3.5 h-3.5 text-[#00FF66]" />
            <span>Sign In with Google Account</span>
          </button>

          <div className="relative flex items-center justify-center py-1">
            <div className="border-t border-white/10 w-full" />
            <span className="bg-[#18181B] px-3 text-[9px] font-black text-white/40 uppercase tracking-widest">
              Or Custom Admin Credentials
            </span>
          </div>

          <form onSubmit={handleEmailSubmit} className="space-y-3.5">
            <div>
              <label className="block text-[10px] font-bold text-white/60 mb-1 uppercase">
                Admin Email Address
              </label>
              <div className="relative">
                <Mail className="w-3.5 h-3.5 text-white/40 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="email"
                  required
                  value={emailInput}
                  onChange={(e) => setEmailInput(e.target.value)}
                  placeholder="mondalsoumyadwip1110@gmail.com"
                  className="w-full pl-9 pr-4 py-2 rounded-xs bg-[#0D0D0F] border border-white/10 text-xs text-white placeholder-white/30 focus:outline-none focus:border-[#FF4D00]"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-white/60 mb-1 uppercase">
                Admin Key / Passcode
              </label>
              <div className="relative">
                <Lock className="w-3.5 h-3.5 text-white/40 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full pl-9 pr-4 py-2 rounded-xs bg-[#0D0D0F] border border-white/10 text-xs text-white placeholder-white/30 focus:outline-none focus:border-[#FF4D00]"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-2.5 rounded-xs bg-white/10 hover:bg-white/20 border border-white/20 text-white font-black text-[10px] uppercase tracking-widest transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <span>{isSubmitting ? 'Authenticating...' : 'Sign In with Credentials'}</span>
            </button>
          </form>
        </div>

        {/* Footer Database Credentials Indicator */}
        <div className="text-center space-y-0.5 text-[10px] text-white/30">
          <div>DATABASE: <span className="text-white/60 font-bold">ai-studio-freefireesportst...</span></div>
          <div>AUTHORIZED: <span className="text-[#00FF66] font-bold">mondalsoumyadwip1110@gmail.com</span></div>
        </div>
      </div>
    </div>
  );
};

