import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useTournament } from '../context/TournamentContext';
import { useAuth } from '../context/AuthContext';
import {
  LayoutDashboard,
  Trophy,
  Users,
  Swords,
  Calculator,
  Receipt,
  Megaphone,
  Settings,
  History,
  Radio,
  Flame,
} from 'lucide-react';

export type ActiveTab =
  | 'dashboard'
  | 'tournament'
  | 'teams'
  | 'matches'
  | 'standings'
  | 'payments'
  | 'announcements'
  | 'settings'
  | 'audit';

interface SidebarProps {
  activeTab?: ActiveTab;
  setActiveTab?: (tab: ActiveTab) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ activeTab: propActiveTab, setActiveTab: propSetActiveTab }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { teams, matches, payments, announcements } = useTournament();
  const { auditLogs } = useAuth();

  const currentPath = location.pathname.replace(/^\//, '') || 'dashboard';
  const activeTab: ActiveTab = (propActiveTab || (currentPath as ActiveTab)) || 'dashboard';

  const handleNavClick = (tabId: ActiveTab) => {
    if (propSetActiveTab) {
      propSetActiveTab(tabId);
    }
    navigate(tabId === 'dashboard' ? '/' : `/${tabId}`);
  };

  const pendingPaymentsCount = payments.filter((p) => p.status === 'PENDING').length;
  const pendingTeamsCount = teams.filter((t) => t.status === 'PENDING_VERIFICATION').length;
  const activeMatchesCount = matches.filter((m) => m.status === 'SCHEDULED' || m.status === 'IN_PROGRESS').length;

  const navItems = [
    {
      id: 'dashboard' as ActiveTab,
      label: 'Live Operations',
      icon: LayoutDashboard,
      badge: activeMatchesCount > 0 ? `${activeMatchesCount} Live` : undefined,
      badgeColor: 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30',
    },
    {
      id: 'tournament' as ActiveTab,
      label: 'Tournament Setup',
      icon: Trophy,
    },
    {
      id: 'teams' as ActiveTab,
      label: 'Teams & Rosters',
      icon: Users,
      badge: pendingTeamsCount > 0 ? `${pendingTeamsCount} Req` : `${teams.length}`,
      badgeColor: pendingTeamsCount > 0 ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' : 'bg-zinc-800 text-zinc-400',
    },
    {
      id: 'matches' as ActiveTab,
      label: '15m Room & Fixtures',
      icon: Swords,
      badge: matches.length > 0 ? `${matches.length}` : undefined,
      badgeColor: 'bg-zinc-800 text-zinc-400',
    },
    {
      id: 'standings' as ActiveTab,
      label: 'Points Calculator',
      icon: Calculator,
      badge: 'Auto',
      badgeColor: 'bg-[#FF4D00]/20 text-[#FF6B2B] border border-[#FF4D00]/30',
    },
    {
      id: 'payments' as ActiveTab,
      label: 'UTR & Payments',
      icon: Receipt,
      badge: pendingPaymentsCount > 0 ? `${pendingPaymentsCount} Review` : undefined,
      badgeColor: 'bg-rose-500/20 text-rose-300 border border-rose-500/30 animate-pulse',
    },
    {
      id: 'announcements' as ActiveTab,
      label: 'Notice Board',
      icon: Megaphone,
      badge: announcements.length > 0 ? `${announcements.length}` : undefined,
      badgeColor: 'bg-zinc-800 text-zinc-400',
    },
    {
      id: 'settings' as ActiveTab,
      label: 'UPI & Config',
      icon: Settings,
    },
    {
      id: 'audit' as ActiveTab,
      label: 'Audit Activity',
      icon: History,
      badge: auditLogs.length > 0 ? `${auditLogs.length}` : undefined,
      badgeColor: 'bg-zinc-800 text-zinc-400',
    },
  ];

  return (
    <aside className="w-64 bg-[#121214] border-r border-white/5 flex flex-col justify-between shrink-0 h-[calc(100vh-5rem)] sticky top-20 select-none">
      <div className="p-3 space-y-1">
        <div className="px-3 py-2 text-[10px] font-mono font-black tracking-widest text-white/40 uppercase">
          Command Matrix
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id || (item.id === 'dashboard' && (currentPath === '' || currentPath === 'dashboard'));

          return (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-sm text-xs font-medium transition-all group cursor-pointer ${
                isActive
                  ? 'bg-[#18181B] text-white border-l-2 border-[#FF4D00] font-bold'
                  : 'text-white/40 hover:text-white hover:bg-white/5'
              }`}
            >
              <div className="flex items-center gap-2.5 truncate">
                <Icon
                  className={`w-4 h-4 transition-colors ${
                    isActive ? 'text-[#FF4D00]' : 'text-white/40 group-hover:text-white'
                  }`}
                />
                <span className="truncate font-mono tracking-tight">{item.label}</span>
              </div>

              {item.badge && (
                <span
                  className={`px-1.5 py-0.5 rounded-xs text-[9px] font-mono font-black tracking-wider uppercase whitespace-nowrap ${
                    item.badgeColor || 'bg-white/5 text-white/40'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Esports Room Fast Broadcast Status Banner */}
      <div className="p-4 m-3 bg-[#18181B] rounded-sm border border-white/5 space-y-2">
        <div className="flex items-center justify-between text-xs">
          <span className="font-bold text-white flex items-center gap-1.5 font-mono text-[11px] uppercase tracking-wider">
            <Radio className="w-3.5 h-3.5 text-[#00FF66] animate-pulse" />
            15M Room Radar
          </span>
          <span className="text-[10px] font-mono text-[#00FF66] font-bold">READY</span>
        </div>
        <p className="text-[10px] text-white/40 font-mono leading-relaxed uppercase">
          Room credentials unlock 15m prior to scheduled start.
        </p>
      </div>
    </aside>
  );
};
