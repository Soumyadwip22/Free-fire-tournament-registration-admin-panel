import React, { useState } from 'react';
import { useTournament } from '../../context/TournamentContext';
import { Tournament, GameMode, TournamentStatus, TournamentStage } from '../../types';
import {
  Trophy,
  Plus,
  Save,
  Trash2,
  Calendar,
  Users,
  DollarSign,
  FileText,
  Layers,
  Image,
  CheckCircle2,
} from 'lucide-react';

export const TournamentManagerView: React.FC = () => {
  const {
    tournaments,
    selectedTournament,
    selectTournament,
    saveTournament,
    deleteTournament,
  } = useTournament();

  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [formData, setFormData] = useState<Tournament>(
    selectedTournament || {
      id: 'tourn-' + Date.now(),
      title: 'New Free Fire Championship',
      gameMode: 'Squad',
      prizePool: 25000,
      prizeBreakdown: { first: 15000, second: 7000, third: 3000, mvp: 1000 },
      entryFee: 100,
      maxSlots: 48,
      registrationDeadline: new Date(Date.now() + 86400000 * 3).toISOString().slice(0, 16),
      startDate: new Date(Date.now() + 86400000 * 4).toISOString().slice(0, 16),
      bannerUrl: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=1200&auto=format&fit=crop&q=80',
      rules: '1. Standard Esports Rules apply.\n2. Mobile devices only.\n3. Room ID & Password released 15 mins before match.',
      status: 'upcoming',
      currentStage: 'Registration',
      organizerContact: '+91 98765 43210',
      createdAt: new Date().toISOString(),
    }
  );

  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSelect = (t: Tournament) => {
    selectTournament(t.id);
    setFormData(t);
    setIsEditing(false);
  };

  const handleNew = () => {
    const newTourn: Tournament = {
      id: 'tourn-' + Date.now().toString(36),
      title: 'Free Fire Premier Cup 2026',
      gameMode: 'Squad',
      prizePool: 30000,
      prizeBreakdown: { first: 18000, second: 8000, third: 4000, mvp: 2000 },
      entryFee: 120,
      maxSlots: 48,
      registrationDeadline: new Date(Date.now() + 86400000 * 5).toISOString().slice(0, 16),
      startDate: new Date(Date.now() + 86400000 * 6).toISOString().slice(0, 16),
      bannerUrl: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?w=1200&auto=format&fit=crop&q=80',
      rules: '1. No emulators or hacks.\n2. 15-minute room unlock system active.\n3. Proof of UTR required.',
      status: 'upcoming',
      currentStage: 'Registration',
      organizerContact: '+91 98765 43210 (Soumyadwip Mondal)',
      createdAt: new Date().toISOString(),
    };
    setFormData(newTourn);
    setIsEditing(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await saveTournament(formData);
    setIsEditing(false);
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="p-4 lg:p-8 space-y-6 max-w-7xl mx-auto">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-[#FF4D00]" />
            <h1 className="text-xl font-bold font-display tracking-wide text-white uppercase">
              Tournament Manager & Prize Pool Engine
            </h1>
          </div>
          <p className="text-xs text-zinc-400 mt-1">
            Configure tournament titles, prize distribution, entry fees, squad slots, deadlines, and esports rulebooks.
          </p>
        </div>

        <button
          onClick={handleNew}
          className="px-4 py-2 rounded-lg bg-[#FF4D00] hover:bg-[#E04400] text-white text-xs font-semibold font-display tracking-wider uppercase transition-all shadow-md flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>New Tournament</span>
        </button>
      </div>

      {savedSuccess && (
        <div className="p-3 bg-emerald-500/20 border border-emerald-500/40 rounded-xl text-emerald-400 text-xs font-medium flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4" />
          <span>Tournament configuration successfully saved and synchronized with Firestore.</span>
        </div>
      )}

      {/* Main Grid: Tournaments List (Left) & Form Editor (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Existing Tournaments List */}
        <div className="space-y-3">
          <div className="text-xs font-mono font-bold text-zinc-400 uppercase tracking-wider">
            All Tournaments ({tournaments.length})
          </div>
          <div className="space-y-2.5">
            {tournaments.map((t) => (
              <div
                key={t.id}
                onClick={() => handleSelect(t)}
                className={`p-4 rounded-xl border transition-all cursor-pointer ${
                  t.id === selectedTournament?.id
                    ? 'bg-[#1F1C18] border-[#FF4D00] shadow-lg shadow-orange-950/20'
                    : 'bg-[#18181B] border-zinc-800 hover:border-zinc-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 uppercase font-bold">
                    {t.gameMode}
                  </span>
                  <span
                    className={`text-[10px] font-mono px-2 py-0.5 rounded uppercase font-bold ${
                      t.status === 'ongoing'
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : t.status === 'upcoming'
                        ? 'bg-blue-500/20 text-blue-400'
                        : 'bg-zinc-800 text-zinc-400'
                    }`}
                  >
                    {t.status}
                  </span>
                </div>
                <h3 className="text-sm font-semibold text-white line-clamp-1">{t.title}</h3>
                <div className="mt-2 flex items-center justify-between text-xs text-zinc-400 font-mono">
                  <span>Pool: ₹{t.prizePool?.toLocaleString('en-IN')}</span>
                  <span>Entry: ₹{t.entryFee}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right Column: Form Editor */}
        <div className="lg:col-span-2">
          <form onSubmit={handleSubmit} className="p-6 rounded-2xl bg-[#18181B] border border-zinc-800 space-y-5">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
              <h2 className="text-base font-bold font-display text-white">
                {isEditing ? 'Create / Configure Tournament' : 'Edit Tournament Details'}
              </h2>
              <div className="flex items-center gap-2">
                {tournaments.length > 1 && (
                  <button
                    type="button"
                    onClick={() => {
                      if (window.confirm(`Delete tournament "${formData.title}"?`)) {
                        deleteTournament(formData.id);
                      }
                    }}
                    className="p-2 text-zinc-400 hover:text-rose-400 hover:bg-zinc-800 rounded-lg transition-colors cursor-pointer"
                    title="Delete tournament"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-[#FF4D00] hover:bg-[#E04400] text-white text-xs font-semibold font-display tracking-wider uppercase transition-all shadow-md flex items-center gap-1.5 cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Changes</span>
                </button>
              </div>
            </div>

            {/* Basic Info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                  Tournament Title
                </label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-3 py-2.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white focus:outline-none focus:border-[#FF4D00]"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-zinc-300 mb-1.5">Game Mode</label>
                <select
                  value={formData.gameMode}
                  onChange={(e) => setFormData({ ...formData, gameMode: e.target.value as GameMode })}
                  className="w-full px-3 py-2.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white focus:outline-none focus:border-[#FF4D00]"
                >
                  <option value="Squad">Squad (4 Players + 1 Sub)</option>
                  <option value="Duo">Duo (2 Players)</option>
                  <option value="Solo">Solo (1 Player)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-zinc-300 mb-1.5">Current Stage</label>
                <select
                  value={formData.currentStage}
                  onChange={(e) => setFormData({ ...formData, currentStage: e.target.value as TournamentStage })}
                  className="w-full px-3 py-2.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white focus:outline-none focus:border-[#FF4D00]"
                >
                  <option value="Registration">Registration Open</option>
                  <option value="Qualifiers">Qualifiers Round</option>
                  <option value="Group Stage">Group Stage (A, B, C)</option>
                  <option value="Semi Finals">Semi Finals</option>
                  <option value="Grand Finals">Grand Finals</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-zinc-300 mb-1.5">Status</label>
                <select
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value as TournamentStatus })}
                  className="w-full px-3 py-2.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white focus:outline-none focus:border-[#FF4D00]"
                >
                  <option value="upcoming">Upcoming</option>
                  <option value="ongoing">Ongoing (Live)</option>
                  <option value="registration_closed">Registration Closed</option>
                  <option value="completed">Completed</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-zinc-300 mb-1.5">Total Squad Slots</label>
                <input
                  type="number"
                  min={12}
                  max={96}
                  value={formData.maxSlots}
                  onChange={(e) => setFormData({ ...formData, maxSlots: parseInt(e.target.value) || 48 })}
                  className="w-full px-3 py-2.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white focus:outline-none focus:border-[#FF4D00]"
                />
              </div>
            </div>

            {/* Financial & Prize Pool Breakdown */}
            <div className="p-4 bg-zinc-900/80 rounded-xl border border-zinc-800 space-y-4">
              <div className="text-xs font-mono font-bold text-amber-400 uppercase tracking-wider flex items-center gap-2">
                <DollarSign className="w-4 h-4" />
                Prize Pool & Entry Fee Configuration
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
                <div>
                  <label className="block text-[11px] text-zinc-400 mb-1">Total Pool (₹)</label>
                  <input
                    type="number"
                    value={formData.prizePool}
                    onChange={(e) => setFormData({ ...formData, prizePool: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-xs text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-zinc-400 mb-1">Entry Fee (₹)</label>
                  <input
                    type="number"
                    value={formData.entryFee}
                    onChange={(e) => setFormData({ ...formData, entryFee: parseInt(e.target.value) || 0 })}
                    className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-xs text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-zinc-400 mb-1">1st Place (₹)</label>
                  <input
                    type="number"
                    value={formData.prizeBreakdown?.first || 0}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        prizeBreakdown: { ...formData.prizeBreakdown, first: parseInt(e.target.value) || 0 },
                      })
                    }
                    className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-xs text-amber-400 font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-zinc-400 mb-1">2nd Place (₹)</label>
                  <input
                    type="number"
                    value={formData.prizeBreakdown?.second || 0}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        prizeBreakdown: { ...formData.prizeBreakdown, second: parseInt(e.target.value) || 0 },
                      })
                    }
                    className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-xs text-zinc-200 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-zinc-400 mb-1">MVP Prize (₹)</label>
                  <input
                    type="number"
                    value={formData.prizeBreakdown?.mvp || 0}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        prizeBreakdown: { ...formData.prizeBreakdown, mvp: parseInt(e.target.value) || 0 },
                      })
                    }
                    className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-xs text-[#FF4D00] font-mono"
                  />
                </div>
              </div>
            </div>

            {/* Dates & Rulebook */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                  Registration Deadline
                </label>
                <input
                  type="datetime-local"
                  value={formData.registrationDeadline}
                  onChange={(e) => setFormData({ ...formData, registrationDeadline: e.target.value })}
                  className="w-full px-3 py-2.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white focus:outline-none focus:border-[#FF4D00]"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                  Tournament Start Date
                </label>
                <input
                  type="datetime-local"
                  value={formData.startDate}
                  onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                  className="w-full px-3 py-2.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white focus:outline-none focus:border-[#FF4D00]"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-zinc-300 mb-1.5">Banner Image URL</label>
                <input
                  type="url"
                  value={formData.bannerUrl}
                  onChange={(e) => setFormData({ ...formData, bannerUrl: e.target.value })}
                  placeholder="https://..."
                  className="w-full px-3 py-2.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white focus:outline-none focus:border-[#FF4D00]"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-zinc-300 mb-1.5">
                  Official Rules & Instructions
                </label>
                <textarea
                  rows={4}
                  value={formData.rules}
                  onChange={(e) => setFormData({ ...formData, rules: e.target.value })}
                  className="w-full px-3 py-2.5 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white focus:outline-none focus:border-[#FF4D00] font-mono leading-relaxed"
                />
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
