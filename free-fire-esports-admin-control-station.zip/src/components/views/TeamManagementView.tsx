import React, { useState, useMemo } from 'react';
import { useTournament } from '../../context/TournamentContext';
import { Team, TeamStatus, GroupType } from '../../types';
import { TeamDetailModal } from '../modals/TeamDetailModal';
import { SlotAllocatorModal } from '../modals/SlotAllocatorModal';
import {
  Users,
  Search,
  Filter,
  Download,
  Plus,
  Layers,
  CheckCircle2,
  XCircle,
  Clock,
  Ban,
  Shield,
  Phone,
  MoreVertical,
  UserCheck,
  Check,
  Trash2,
} from 'lucide-react';

export const TeamManagementView: React.FC = () => {
  const {
    teams,
    updateTeamStatus,
    updateTeamSlot,
    updateTeam,
    addTeam,
    deleteTeam,
    exportTeamsCSV,
    selectedTournament,
  } = useTournament();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedGroupFilter, setSelectedGroupFilter] = useState<string>('ALL');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('ALL');
  const [activeModalTeam, setActiveModalTeam] = useState<Team | null>(null);
  const [isSlotModalOpen, setIsSlotModalOpen] = useState(false);
  const [slotTargetTeam, setSlotTargetTeam] = useState<Team | null>(null);
  const [isAddTeamModalOpen, setIsAddTeamModalOpen] = useState(false);

  // New team form state
  const [newTeamName, setNewTeamName] = useState('');
  const [newTeamTag, setNewTeamTag] = useState('');
  const [newCaptainName, setNewCaptainName] = useState('');
  const [newCaptainPhone, setNewCaptainPhone] = useState('');
  const [newCaptainUid, setNewCaptainUid] = useState('');

  // Search logic across Team ID, Team Name, Captain Phone, and Player UIDs
  const filteredTeams = useMemo(() => {
    return teams.filter((team) => {
      // Group filter
      if (selectedGroupFilter !== 'ALL' && team.group !== selectedGroupFilter) {
        return false;
      }
      // Status filter
      if (selectedStatusFilter !== 'ALL' && team.status !== selectedStatusFilter) {
        return false;
      }
      // Search query
      if (!searchQuery.trim()) return true;

      const q = searchQuery.toLowerCase().trim();
      const matchesTeamName = team.teamName?.toLowerCase().includes(q);
      const matchesTag = team.teamTag?.toLowerCase().includes(q);
      const matchesId = team.id?.toLowerCase().includes(q);
      const matchesCaptainName = team.captainName?.toLowerCase().includes(q);
      const matchesCaptainPhone = team.captainPhone?.toLowerCase().includes(q);
      const matchesCaptainUid = team.captainUid?.toLowerCase().includes(q);
      const matchesPlayerUid = team.players?.some(
        (p) => p.uid?.toLowerCase().includes(q) || p.ign?.toLowerCase().includes(q) || p.name?.toLowerCase().includes(q)
      );

      return (
        matchesTeamName ||
        matchesTag ||
        matchesId ||
        matchesCaptainName ||
        matchesCaptainPhone ||
        matchesCaptainUid ||
        matchesPlayerUid
      );
    });
  }, [teams, searchQuery, selectedGroupFilter, selectedStatusFilter]);

  const handleOpenSlotAllocator = (team?: Team) => {
    setSlotTargetTeam(team || null);
    setIsSlotModalOpen(true);
  };

  const handleCreateNewTeam = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTeamName.trim() || !newCaptainName.trim() || !newCaptainUid.trim()) return;

    await addTeam({
      tournamentId: selectedTournament?.id || 'tourn-1',
      teamName: newTeamName.trim(),
      teamTag: newTeamTag.trim().toUpperCase() || newTeamName.slice(0, 3).toUpperCase(),
      captainName: newCaptainName.trim(),
      captainPhone: newCaptainPhone.trim() || '+91 99999 00000',
      captainUid: newCaptainUid.trim(),
      players: [
        { name: newCaptainName.trim(), ign: newTeamName.slice(0, 4) + '-Cap', uid: newCaptainUid.trim(), role: 'Captain' },
        { name: 'Squad Player 2', ign: newTeamName.slice(0, 4) + '-Fragger', uid: Math.floor(1000000000 + Math.random() * 9000000000).toString(), role: 'Fragger' },
        { name: 'Squad Player 3', ign: newTeamName.slice(0, 4) + '-Sniper', uid: Math.floor(1000000000 + Math.random() * 9000000000).toString(), role: 'Sniper' },
        { name: 'Squad Player 4', ign: newTeamName.slice(0, 4) + '-Support', uid: Math.floor(1000000000 + Math.random() * 9000000000).toString(), role: 'Support' },
      ],
      status: 'QUALIFIED',
      group: 'Unassigned',
      slotNumber: null,
      paymentStatus: 'VERIFIED',
      registeredAt: new Date().toISOString(),
    });

    setNewTeamName('');
    setNewTeamTag('');
    setNewCaptainName('');
    setNewCaptainPhone('');
    setNewCaptainUid('');
    setIsAddTeamModalOpen(false);
  };

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold font-serif italic text-white">
              Team & Squad Management
            </h1>
            <span className="text-xs font-mono font-bold text-[#FF4D00]">({teams.length} SQUADS)</span>
          </div>
          <p className="text-xs text-white/40 font-mono mt-0.5">
            Real-time roster registry synced with Firestore. Search by Team ID, Captain phone or Player UID.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto font-mono text-xs">
          <button
            onClick={() => exportTeamsCSV(selectedGroupFilter)}
            className="px-3 py-1.5 rounded-xs bg-white/5 hover:bg-white/10 border border-white/10 text-[10px] font-bold uppercase tracking-wider text-white/80 hover:text-white flex items-center gap-1.5 cursor-pointer shadow-sm transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-[#00FF66]" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={() => handleOpenSlotAllocator()}
            className="px-3 py-1.5 rounded-xs bg-white/5 hover:bg-white/10 border border-white/10 text-[10px] font-bold uppercase tracking-wider text-white/80 hover:text-white flex items-center gap-1.5 cursor-pointer shadow-sm transition-colors"
          >
            <Layers className="w-3.5 h-3.5 text-[#FF4D00]" />
            <span>Slot Allocator</span>
          </button>

          <button
            onClick={() => setIsAddTeamModalOpen(true)}
            className="px-3.5 py-1.5 rounded-xs bg-[#FF4D00] hover:bg-[#E04400] text-black text-[10px] font-black tracking-widest uppercase flex items-center gap-1.5 cursor-pointer shadow-md transition-colors"
          >
            <Plus className="w-3.5 h-3.5 text-black" />
            <span>Add Squad</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-xs bg-[#18181B] border border-white/5 space-y-3 font-mono">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-white/40 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search by Team Name, ID, Captain Phone, or Player UID..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 rounded-xs bg-[#0D0D0F] border border-white/10 text-xs text-white placeholder-white/40 focus:outline-none focus:border-[#FF4D00]"
            />
          </div>

          {/* Status Quick Filter */}
          <div className="flex items-center gap-1 overflow-x-auto pb-1 md:pb-0">
            {['ALL', 'QUALIFIED', 'PENDING_VERIFICATION', 'WAITLIST', 'REJECTED', 'DISQUALIFIED'].map((status) => (
              <button
                key={status}
                onClick={() => setSelectedStatusFilter(status)}
                className={`px-2.5 py-1.5 rounded-xs text-[10px] uppercase tracking-wider whitespace-nowrap transition-colors cursor-pointer ${
                  selectedStatusFilter === status
                    ? 'bg-[#FF4D00] text-black font-black'
                    : 'bg-[#0D0D0F] text-white/40 hover:text-white border border-white/5'
                }`}
              >
                {status === 'ALL' ? 'All' : status.replace('_', ' ')}
              </button>
            ))}
          </div>
        </div>

        {/* Group Tabs */}
        <div className="flex items-center gap-2 pt-2 border-t border-white/5">
          <span className="text-[10px] text-white/40 uppercase font-bold">STAGE:</span>
          {['ALL', 'Group A', 'Group B', 'Group C', 'Grand Finals', 'Unassigned'].map((grp) => (
            <button
              key={grp}
              onClick={() => setSelectedGroupFilter(grp)}
              className={`px-2.5 py-1 rounded-xs text-[10px] uppercase font-bold cursor-pointer transition-colors ${
                selectedGroupFilter === grp
                  ? 'bg-white/10 text-white border border-white/20'
                  : 'text-white/40 hover:text-white'
              }`}
            >
              {grp}
            </button>
          ))}
        </div>
      </div>

      {/* Dense Esports Roster Table */}
      <div className="rounded-xs bg-[#18181B] border border-white/5 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead>
              <tr className="bg-white/5 border-b border-white/5 text-white/40 text-[10px] uppercase">
                <th className="py-2.5 px-4 font-medium">Team & Tag</th>
                <th className="py-2.5 px-3 font-medium">Group & Slot</th>
                <th className="py-2.5 px-3 font-medium">Captain & UID</th>
                <th className="py-2.5 px-3 font-medium">Squad Roster</th>
                <th className="py-2.5 px-3 font-medium text-center">Status</th>
                <th className="py-2.5 px-3 font-medium text-center">Payment</th>
                <th className="py-2.5 px-4 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredTeams.map((team, idx) => (
                <tr
                  key={team.id}
                  className={`hover:bg-white/[0.04] transition-colors group cursor-pointer ${idx % 2 === 0 ? 'bg-white/[0.01]' : ''}`}
                  onClick={() => setActiveModalTeam(team)}
                >
                  {/* Team & Tag */}
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-xs bg-[#0D0D0F] border border-white/10 flex items-center justify-center font-black text-xs text-[#FF4D00]">
                        {team.teamTag || team.teamName.slice(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <div className="font-sans font-bold text-white text-xs hover:text-[#FF4D00] transition-colors">
                          {team.teamName}
                        </div>
                        <div className="text-[10px] text-white/40">ID: {team.id}</div>
                      </div>
                    </div>
                  </td>

                  {/* Group & Slot */}
                  <td className="py-3 px-3">
                    {team.group !== 'Unassigned' && team.slotNumber ? (
                      <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-xs bg-[#0D0D0F] border border-white/10 text-[11px] font-bold text-white">
                        <span className="text-[#FF4D00]">{team.group}</span>
                        <span className="text-white/20">•</span>
                        <span>Slot #{team.slotNumber.toString().padStart(2, '0')}</span>
                      </span>
                    ) : (
                      <span className="text-white/40 text-[11px]">Unassigned</span>
                    )}
                  </td>

                  {/* Captain & Phone */}
                  <td className="py-3 px-3">
                    <div className="font-sans font-bold text-white/90">{team.captainName}</div>
                    <div className="text-[10px] text-white/40 flex items-center gap-1">
                      <span>{team.captainPhone}</span>
                      <span className="text-white/20">|</span>
                      <span className="text-[#00FF66]">UID: {team.captainUid}</span>
                    </div>
                  </td>

                  {/* Squad Roster preview */}
                  <td className="py-3 px-3">
                    <div className="flex items-center gap-1 flex-wrap max-w-xs">
                      {team.players?.slice(0, 4).map((p, pIdx) => (
                        <span
                          key={pIdx}
                          title={`${p.name} (UID: ${p.uid})`}
                          className="text-[10px] px-1.5 py-0.5 rounded-xs bg-[#0D0D0F] border border-white/10 text-white/70"
                        >
                          {p.ign}
                        </span>
                      ))}
                      {(team.players?.length || 0) > 4 && (
                        <span className="text-[10px] text-white/40">
                          +{(team.players?.length || 0) - 4}
                        </span>
                      )}
                    </div>
                  </td>

                  {/* Status Badge */}
                  <td className="py-3 px-3 text-center">
                    <span
                      className={`px-2 py-0.5 rounded-xs text-[10px] font-black uppercase ${
                        team.status === 'QUALIFIED'
                          ? 'bg-[#00FF66]/10 text-[#00FF66]'
                          : team.status === 'PENDING_VERIFICATION'
                          ? 'bg-yellow-400/10 text-yellow-400'
                          : team.status === 'WAITLIST'
                          ? 'bg-blue-400/10 text-blue-400'
                          : 'bg-rose-500/10 text-rose-400'
                      }`}
                    >
                      {team.status === 'QUALIFIED' ? 'VERIFIED' : team.status.replace('_', ' ')}
                    </span>
                  </td>

                  {/* Payment Status */}
                  <td className="py-3 px-3 text-center">
                    <span
                      className={`text-[10px] font-black ${
                        team.paymentStatus === 'VERIFIED'
                          ? 'text-[#00FF66]'
                          : team.paymentStatus === 'SUBMITTED'
                          ? 'text-yellow-400'
                          : 'text-white/40'
                      }`}
                    >
                      {team.paymentStatus}
                    </span>
                  </td>

                  {/* Quick Action Buttons */}
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => handleOpenSlotAllocator(team)}
                        className="p-1.5 text-white/40 hover:text-white bg-white/5 hover:bg-white/10 rounded-xs transition-colors cursor-pointer"
                        title="Allocate Slot (1-12)"
                      >
                        <Layers className="w-3.5 h-3.5 text-[#FF4D00]" />
                      </button>

                      {team.status !== 'QUALIFIED' && (
                        <button
                          onClick={() => updateTeamStatus(team.id, 'QUALIFIED')}
                          className="p-1.5 text-[#00FF66] hover:bg-white/10 rounded-xs transition-colors cursor-pointer"
                          title="Qualify for Group Stage"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                        </button>
                      )}

                      {team.status !== 'REJECTED' && (
                        <button
                          onClick={() => updateTeamStatus(team.id, 'REJECTED', 'Manual organizer rejection')}
                          className="p-1.5 text-rose-400 hover:bg-white/10 rounded-xs transition-colors cursor-pointer"
                          title="Reject Team"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                        </button>
                      )}

                      <button
                        onClick={() => {
                          if (window.confirm(`Delete ${team.teamName}?`)) {
                            deleteTeam(team.id);
                          }
                        }}
                        className="p-1.5 text-white/40 hover:text-rose-400 hover:bg-white/10 rounded-xs transition-colors cursor-pointer"
                        title="Delete from roster"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}

              {filteredTeams.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-white/40 font-sans">
                    No teams found matching the search criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Team Detail Roster Modal */}
      {activeModalTeam && (
        <TeamDetailModal
          team={activeModalTeam}
          onClose={() => setActiveModalTeam(null)}
          onSave={updateTeam}
          onUpdateStatus={updateTeamStatus}
          onAllocateSlot={(team) => {
            setActiveModalTeam(null);
            handleOpenSlotAllocator(team);
          }}
        />
      )}

      {/* 12-Slot Custom Room Allocator Modal */}
      {isSlotModalOpen && (
        <SlotAllocatorModal
          targetTeam={slotTargetTeam}
          teams={teams}
          onClose={() => setIsSlotModalOpen(false)}
          onAllocateSlot={updateTeamSlot}
        />
      )}

      {/* Add Team Modal */}
      {isAddTeamModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-[#141417] border border-zinc-800 rounded-2xl p-6 shadow-2xl space-y-4">
            <h2 className="text-base font-bold font-display text-white uppercase">Register New Esports Squad</h2>
            <form onSubmit={handleCreateNewTeam} className="space-y-4">
              <div>
                <label className="block text-xs text-zinc-400 mb-1">Squad / Team Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Hyderabad Hydras"
                  value={newTeamName}
                  onChange={(e) => setNewTeamName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-xs text-zinc-400 mb-1">Team Tag (3-4 Chars)</label>
                <input
                  type="text"
                  placeholder="e.g. HYD"
                  maxLength={5}
                  value={newTeamTag}
                  onChange={(e) => setNewTeamTag(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-zinc-400 mb-1">Captain Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Rohit Kumar"
                    value={newCaptainName}
                    onChange={(e) => setNewCaptainName(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-xs text-zinc-400 mb-1">Captain WhatsApp</label>
                  <input
                    type="text"
                    placeholder="+91 98765 43210"
                    value={newCaptainPhone}
                    onChange={(e) => setNewCaptainPhone(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs text-zinc-400 mb-1">Captain Free Fire UID</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 1098273641"
                  value={newCaptainUid}
                  onChange={(e) => setNewCaptainUid(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white font-mono"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddTeamModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-zinc-800 text-zinc-400 hover:text-white text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-[#FF4D00] hover:bg-[#E04400] text-white text-xs font-semibold uppercase font-display"
                >
                  Register Squad
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
