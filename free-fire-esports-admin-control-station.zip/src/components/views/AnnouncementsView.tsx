import React, { useState } from 'react';
import { useTournament } from '../../context/TournamentContext';
import { Announcement, AnnouncementCategory, GroupType } from '../../types';
import {
  Megaphone,
  Plus,
  Pin,
  Trash2,
  Send,
  AlertTriangle,
  Clock,
  Sparkles,
} from 'lucide-react';

export const AnnouncementsView: React.FC = () => {
  const { announcements, postAnnouncement, deleteAnnouncement, selectedTournament } = useTournament();

  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [category, setCategory] = useState<AnnouncementCategory>('GENERAL');
  const [targetGroup, setTargetGroup] = useState<string>('ALL');
  const [isPinned, setIsPinned] = useState(false);
  const [isPosting, setIsPosting] = useState(false);

  const handlePost = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !message.trim()) return;

    setIsPosting(true);
    await postAnnouncement({
      tournamentId: selectedTournament?.id || 'tourn-1',
      title: title.trim(),
      message: message.trim(),
      category,
      targetGroup: targetGroup as any,
      isPinned,
    });

    setTitle('');
    setMessage('');
    setIsPinned(false);
    setIsPosting(false);
  };

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold font-serif italic text-white">
              Esports Notice Board & Captain Broadcasts
            </h1>
            <span className="text-xs font-mono font-bold text-[#FF4D00]">({announcements.length} NOTICES)</span>
          </div>
          <p className="text-xs text-white/40 font-mono mt-0.5">
            Publish official tournament notices, schedule changes, slot allocations, and urgent updates directly to players.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Left Column: Post Form */}
        <div className="lg:col-span-1">
          <form
            onSubmit={handlePost}
            className="p-5 rounded-xs bg-[#18181B] border border-white/5 space-y-4 shadow-xl sticky top-20 font-mono"
          >
            <div className="text-[10px] font-black text-white uppercase tracking-widest flex items-center gap-2 border-b border-white/5 pb-3">
              <Send className="w-3.5 h-3.5 text-[#FF4D00]" />
              Create Official Notice
            </div>

            <div>
              <label className="block text-[10px] text-white/40 mb-1 font-bold uppercase">Notice Title</label>
              <input
                type="text"
                required
                placeholder="e.g. Group A Match 2 Delay Notice"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-3 py-2 rounded-xs bg-[#0D0D0F] border border-white/10 text-xs text-white placeholder-white/30 focus:border-[#FF4D00] focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[10px] text-white/40 mb-1 font-bold uppercase">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as AnnouncementCategory)}
                  className="w-full px-2.5 py-2 rounded-xs bg-[#0D0D0F] border border-white/10 text-xs text-white focus:border-[#FF4D00] focus:outline-none"
                >
                  <option value="GENERAL">General Notice</option>
                  <option value="SCHEDULE">Schedule</option>
                  <option value="ROOM_ALERT">Room Alert</option>
                  <option value="RULES">Rulebook</option>
                  <option value="PAYMENT">Payment</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] text-white/40 mb-1 font-bold uppercase">Audience</label>
                <select
                  value={targetGroup}
                  onChange={(e) => setTargetGroup(e.target.value)}
                  className="w-full px-2.5 py-2 rounded-xs bg-[#0D0D0F] border border-white/10 text-xs text-white focus:border-[#FF4D00] focus:outline-none"
                >
                  <option value="ALL">All Players</option>
                  <option value="Group A">Group A</option>
                  <option value="Group B">Group B</option>
                  <option value="Group C">Group C</option>
                  <option value="Grand Finals">Grand Finals</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[10px] text-white/40 mb-1 font-bold uppercase">Broadcast Message</label>
              <textarea
                rows={4}
                required
                placeholder="Type official communication..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full px-3 py-2 rounded-xs bg-[#0D0D0F] border border-white/10 text-xs text-white leading-relaxed placeholder-white/30 focus:border-[#FF4D00] focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="pinNotice"
                checked={isPinned}
                onChange={(e) => setIsPinned(e.target.checked)}
                className="rounded-xs bg-[#0D0D0F] border-white/10 text-[#FF4D00] focus:ring-0"
              />
              <label htmlFor="pinNotice" className="text-xs text-white/70 flex items-center gap-1 cursor-pointer">
                <Pin className="w-3 h-3 text-[#FF4D00]" />
                <span>Pin notice to top of Player View</span>
              </label>
            </div>

            <button
              type="submit"
              disabled={isPosting}
              className="w-full py-2.5 rounded-xs bg-[#FF4D00] hover:bg-[#E04400] text-black text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-1.5 cursor-pointer shadow-md transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{isPosting ? 'Broadcasting...' : 'Publish Notice'}</span>
            </button>
          </form>
        </div>

        {/* Right Column: Notices Stream */}
        <div className="lg:col-span-2 space-y-3 font-mono">
          <div className="text-[10px] font-black text-white/40 uppercase tracking-widest">
            Active Broadcast Feed ({announcements.length})
          </div>

          <div className="space-y-3">
            {announcements.map((ann) => (
              <div
                key={ann.id}
                className={`p-5 rounded-xs bg-[#18181B] border transition-all space-y-3 ${
                  ann.isPinned
                    ? 'border-l-2 border-[#FF4D00] border-t-white/5 border-r-white/5 border-b-white/5 shadow-lg'
                    : 'border border-white/5'
                }`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="px-1.5 py-0.5 rounded-xs text-[9px] font-black uppercase bg-[#0D0D0F] text-[#FF4D00] border border-white/10">
                        {ann.category}
                      </span>
                      <span className="px-1.5 py-0.5 rounded-xs text-[9px] bg-white/5 text-white/60">
                        Target: {ann.targetGroup || 'ALL'}
                      </span>
                      {ann.isPinned && (
                        <span className="flex items-center gap-1 px-1.5 py-0.5 rounded-xs text-[9px] font-black bg-[#FF4D00]/10 text-[#FF4D00] border border-[#FF4D00]/30">
                          <Pin className="w-2.5 h-2.5" />
                          PINNED
                        </span>
                      )}
                    </div>
                    <h3 className="text-sm font-bold font-serif italic text-white">{ann.title}</h3>
                  </div>

                  <button
                    onClick={() => {
                      if (window.confirm('Delete this announcement?')) {
                        deleteAnnouncement(ann.id);
                      }
                    }}
                    className="p-1.5 text-white/40 hover:text-rose-400 hover:bg-white/5 rounded-xs transition-colors cursor-pointer"
                    title="Delete notice"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                <p className="text-xs text-white/80 leading-relaxed font-sans whitespace-pre-line">
                  {ann.message}
                </p>

                <div className="text-[10px] text-white/40 pt-2 border-t border-white/5 flex items-center justify-between">
                  <span>Author: {ann.author}</span>
                  <span>{new Date(ann.createdAt).toLocaleString()}</span>
                </div>
              </div>
            ))}

            {announcements.length === 0 && (
              <div className="p-12 text-center text-white/40 rounded-xs bg-[#18181B] border border-white/5 font-sans text-xs">
                No active announcements. Create one from the left panel.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
