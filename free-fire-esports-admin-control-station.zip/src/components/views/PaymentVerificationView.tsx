import React, { useState } from 'react';
import { useTournament } from '../../context/TournamentContext';
import { PaymentRecord, PaymentStatus } from '../../types';
import {
  Receipt,
  Search,
  CheckCircle2,
  XCircle,
  Clock,
  ExternalLink,
  Eye,
  ShieldCheck,
  AlertCircle,
  Copy,
  Check,
} from 'lucide-react';

export const PaymentVerificationView: React.FC = () => {
  const { payments, verifyPayment, rejectPayment, selectedTournament } = useTournament();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [activeScreenshotUrl, setActiveScreenshotUrl] = useState<string | null>(null);
  const [rejectingPaymentId, setRejectingPaymentId] = useState<string | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [copiedUtr, setCopiedUtr] = useState<string | null>(null);

  const filteredPayments = payments.filter((p) => {
    if (selectedStatus !== 'ALL' && p.status !== selectedStatus) return false;
    if (!searchQuery.trim()) return true;

    const q = searchQuery.toLowerCase().trim();
    return (
      p.utrNumber?.toLowerCase().includes(q) ||
      p.teamName?.toLowerCase().includes(q) ||
      p.captainPhone?.toLowerCase().includes(q) ||
      p.captainName?.toLowerCase().includes(q) ||
      p.id?.toLowerCase().includes(q)
    );
  });

  const handleCopyUtr = (utr: string) => {
    navigator.clipboard.writeText(utr);
    setCopiedUtr(utr);
    setTimeout(() => setCopiedUtr(null), 2000);
  };

  const handleVerify = async (paymentId: string) => {
    await verifyPayment(paymentId);
  };

  const handleConfirmReject = async (paymentId: string) => {
    await rejectPayment(paymentId, rejectReason || 'Invalid UTR reference number or payment not received');
    setRejectingPaymentId(null);
    setRejectReason('');
  };

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold font-serif italic text-white">
              UPI Payment & UTR Verification Portal
            </h1>
            <span className="text-xs font-mono font-bold text-[#FF4D00]">({payments.length} RECORDS)</span>
          </div>
          <p className="text-xs text-white/40 font-mono mt-0.5">
            Audit team registration entry fee payments, inspect UPI transaction screenshots, and verify 12-digit UTR references.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-3 py-1.5 rounded-xs bg-[#18181B] border border-white/10 text-xs text-white/80 font-mono">
            ENTRY FEE: <span className="text-[#FF4D00] font-black">₹{selectedTournament?.entryFee || 150}</span>
          </span>
        </div>
      </div>

      {/* Search & Status Filter */}
      <div className="p-4 rounded-xs bg-[#18181B] border border-white/5 flex flex-col md:flex-row md:items-center justify-between gap-3 font-mono">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-white/40 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by 12-digit UTR Number, Team Name, Captain Phone..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-xs bg-[#0D0D0F] border border-white/10 text-xs text-white placeholder-white/40 focus:outline-none focus:border-[#FF4D00]"
          />
        </div>

        <div className="flex items-center gap-1.5">
          {['ALL', 'PENDING', 'VERIFIED', 'REJECTED'].map((st) => (
            <button
              key={st}
              onClick={() => setSelectedStatus(st)}
              className={`px-2.5 py-1.5 rounded-xs text-[10px] font-black uppercase tracking-wider transition-colors cursor-pointer ${
                selectedStatus === st
                  ? 'bg-[#FF4D00] text-black'
                  : 'bg-[#0D0D0F] text-white/40 hover:text-white border border-white/5'
              }`}
            >
              {st} ({st === 'ALL' ? payments.length : payments.filter((p) => p.status === st).length})
            </button>
          ))}
        </div>
      </div>

      {/* Payment Records Table */}
      <div className="rounded-xs bg-[#18181B] border border-white/5 overflow-hidden shadow-xl font-mono">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-white/5 border-b border-white/5 text-white/40 text-[10px] uppercase">
                <th className="py-2.5 px-4 font-medium">Team & Captain</th>
                <th className="py-2.5 px-3 font-medium">12-Digit UTR Number</th>
                <th className="py-2.5 px-3 font-medium text-center">Amount</th>
                <th className="py-2.5 px-3 font-medium text-center">Proof Screenshot</th>
                <th className="py-2.5 px-3 font-medium text-center">Status</th>
                <th className="py-2.5 px-4 font-medium text-right">Verification Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredPayments.map((payment) => (
                <tr key={payment.id} className="hover:bg-white/[0.04] transition-colors">
                  {/* Team & Captain */}
                  <td className="py-3 px-4">
                    <div className="font-sans font-bold text-white text-xs">{payment.teamName}</div>
                    <div className="text-[10px] text-white/40 flex items-center gap-1.5 mt-0.5">
                      <span>Cap: {payment.captainName}</span>
                      <span className="text-white/20">|</span>
                      <span>{payment.captainPhone}</span>
                    </div>
                  </td>

                  {/* 12-Digit UTR */}
                  <td className="py-3 px-3">
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-white text-xs tracking-wider">
                        {payment.utrNumber || 'NO UTR PROVIDED'}
                      </span>
                      {payment.utrNumber && (
                        <button
                          onClick={() => handleCopyUtr(payment.utrNumber)}
                          className="p-1 text-white/40 hover:text-white"
                          title="Copy UTR"
                        >
                          {copiedUtr === payment.utrNumber ? (
                            <Check className="w-3.5 h-3.5 text-[#00FF66]" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      )}
                    </div>
                    <div className="text-[10px] text-white/40">
                      {new Date(payment.submittedAt).toLocaleString([], {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </div>
                  </td>

                  {/* Amount */}
                  <td className="py-3 px-3 text-center font-bold text-[#FF4D00]">
                    ₹{payment.amount}
                  </td>

                  {/* Screenshot Thumbnail */}
                  <td className="py-3 px-3 text-center">
                    {payment.screenshotUrl ? (
                      <button
                        onClick={() => setActiveScreenshotUrl(payment.screenshotUrl!)}
                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded-xs bg-[#0D0D0F] hover:bg-white/10 border border-white/10 text-[10px] text-white/80 transition-colors cursor-pointer font-bold uppercase"
                      >
                        <Eye className="w-3 h-3 text-[#00FF66]" />
                        <span>View Proof</span>
                      </button>
                    ) : (
                      <span className="text-white/30 text-[10px]">No Attachment</span>
                    )}
                  </td>

                  {/* Status Badge */}
                  <td className="py-3 px-3 text-center">
                    <span
                      className={`px-2 py-0.5 rounded-xs text-[10px] font-black uppercase ${
                        payment.status === 'VERIFIED'
                          ? 'bg-[#00FF66]/10 text-[#00FF66] border border-[#00FF66]/30'
                          : payment.status === 'PENDING'
                          ? 'bg-yellow-400/10 text-yellow-400 border border-yellow-400/30 animate-pulse'
                          : 'bg-rose-500/10 text-rose-400 border border-rose-500/30'
                      }`}
                    >
                      {payment.status}
                    </span>
                    {payment.rejectionReason && (
                      <div className="text-[9px] text-rose-400 mt-1 max-w-[140px] truncate">
                        {payment.rejectionReason}
                      </div>
                    )}
                  </td>

                  {/* Action Buttons */}
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      {payment.status !== 'VERIFIED' && (
                        <button
                          onClick={() => handleVerify(payment.id)}
                          className="px-2.5 py-1 rounded-xs bg-[#00FF66] hover:bg-[#00CC52] text-black font-black text-[10px] uppercase tracking-wider flex items-center gap-1 cursor-pointer transition-all shadow-md"
                        >
                          <CheckCircle2 className="w-3 h-3 text-black" />
                          <span>Approve</span>
                        </button>
                      )}

                      {payment.status !== 'REJECTED' && (
                        <button
                          onClick={() => setRejectingPaymentId(payment.id)}
                          className="px-2.5 py-1 rounded-xs bg-white/5 hover:bg-rose-950/40 text-rose-400 hover:text-rose-300 border border-rose-500/30 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1 cursor-pointer transition-all"
                        >
                          <XCircle className="w-3 h-3" />
                          <span>Reject</span>
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}

              {filteredPayments.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-12 text-center text-white/40 font-sans">
                    No payment submissions found matching your search.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* High-Resolution Screenshot Zoom Modal */}
      {activeScreenshotUrl && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="max-w-2xl w-full bg-[#18181B] border border-zinc-800 rounded-2xl p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold font-display text-white uppercase tracking-wider">
                UPI Transaction Payment Proof
              </h3>
              <button
                onClick={() => setActiveScreenshotUrl(null)}
                className="p-1.5 text-zinc-400 hover:text-white bg-zinc-800 rounded-lg cursor-pointer"
              >
                Close
              </button>
            </div>

            <div className="rounded-xl overflow-hidden bg-black max-h-[65vh] flex items-center justify-center border border-zinc-800">
              <img
                src={activeScreenshotUrl}
                alt="Payment Proof"
                className="max-h-[60vh] w-auto object-contain"
              />
            </div>
          </div>
        </div>
      )}

      {/* Reject Payment Reason Modal */}
      {rejectingPaymentId && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-[#18181B] border border-zinc-800 rounded-2xl p-5 space-y-4 shadow-2xl">
            <h3 className="text-sm font-bold font-display text-white uppercase">
              Reject Payment Submission
            </h3>
            <p className="text-xs text-zinc-400">
              Please enter the reason for rejection (e.g. Duplicate UTR, Wrong Amount, Blurred Screenshot).
            </p>

            <textarea
              rows={3}
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="Enter rejection reason..."
              className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
            />

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setRejectingPaymentId(null)}
                className="px-3.5 py-1.5 rounded-lg bg-zinc-800 text-zinc-400 hover:text-white text-xs cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => handleConfirmReject(rejectingPaymentId)}
                className="px-4 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold cursor-pointer"
              >
                Confirm Rejection
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
