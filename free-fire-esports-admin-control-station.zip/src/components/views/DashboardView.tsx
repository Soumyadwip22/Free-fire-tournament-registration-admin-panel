import React, { useState, useEffect } from 'react';
import { useTournament } from '../../context/TournamentContext';
import { ActiveTab } from '../Sidebar';
import {
  Trophy,
  Users,
  Receipt,
  Swords,
  Radio,
  Clock,
  ArrowRight,
  Flame,
  CheckCircle2,
  AlertTriangle,
  Send,
  Eye,
  Copy,
  Check,
  ExternalLink,
} from 'lucide-react';

interface DashboardViewProps {
  setActiveTab: (tab: ActiveTab) => void;
  onOpenPlayerPreview: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ setActiveTab, onOpenPlayerPreview }) => {
  const {
    selectedTournament,
    teams,
    matches,
    payments,
    announcements,
    overallStandings,
    publishRoomCredentials,
    verifyPayment,
    rejectPayment,
  } = useTournament();

  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [timeRemaining, setTimeRemaining] = useState<string>('');

  const qualifiedTeams = teams.filter((t) => t.status === 'QUALIFIED');
  const pendingPayments = payments.filter((p) => p.status === 'PENDING');
  const verifiedPayments = payments.filter((p) => p.status === 'VERIFIED');
  const upcomingMatches = matches.filter((m) => m.status === 'SCHEDULED' || m.status === 'IN_PROGRESS');
  const nextMatch = upcomingMatches[0] || matches[0];

  // Live countdown timer for the next scheduled match
  useEffect(() => {
    if (!nextMatch?.scheduledTime) {
      setTimeRemaining('14:52');
      return;
    }

    const interval = setInterval(() => {
      const diff = new Date(nextMatch.scheduledTime).getTime() - Date.now();
      if (diff <= 0) {
        setTimeRemaining('00:00');
      } else {
        const mins = Math.floor(diff / (1000 * 60));
        const secs = Math.floor((diff % (1000 * 60)) / 1000);
        const remMins = mins % 60;
        setTimeRemaining(`${remMins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`);
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [nextMatch]);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-7xl mx-auto">
      {/* Editorial 4-Metric Grid with border-l-2 Accents */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
        {/* Metric 1: Total Teams */}
        <div className="bg-[#18181B] p-4 border-l-2 border-[#FF4D00] rounded-xs border-r border-t border-b border-white/5 flex flex-col justify-between">
          <p className="text-[10px] uppercase tracking-widest text-white/40 mb-1 font-mono font-bold">
            Total Teams
          </p>
          <div className="flex items-baseline justify-between">
            <p className="text-2xl lg:text-3xl font-black font-mono text-white">{teams.length}</p>
            <span className="text-[10px] font-mono text-white/40">/{selectedTournament?.maxSlots || 48} MAX</span>
          </div>
        </div>

        {/* Metric 2: Verified Pay */}
        <div className="bg-[#18181B] p-4 border-l-2 border-[#00FF66] rounded-xs border-r border-t border-b border-white/5 flex flex-col justify-between">
          <p className="text-[10px] uppercase tracking-widest text-white/40 mb-1 font-mono font-bold">
            Verified Pay
          </p>
          <div className="flex items-baseline justify-between">
            <p className="text-2xl lg:text-3xl font-black font-mono text-[#00FF66]">
              {verifiedPayments.length}
            </p>
            <span className="text-[10px] font-mono text-emerald-400/70">
              ₹{((verifiedPayments.length) * (selectedTournament?.entryFee || 150)).toLocaleString('en-IN')}
            </span>
          </div>
        </div>

        {/* Metric 3: Pending Review */}
        <div className="bg-[#18181B] p-4 border-l-2 border-yellow-400 rounded-xs border-r border-t border-b border-white/5 flex flex-col justify-between">
          <p className="text-[10px] uppercase tracking-widest text-white/40 mb-1 font-mono font-bold">
            Pending Review
          </p>
          <div className="flex items-baseline justify-between">
            <p className="text-2xl lg:text-3xl font-black font-mono text-yellow-400">
              {pendingPayments.length}
            </p>
            <button
              onClick={() => setActiveTab('payments')}
              className="text-[10px] font-mono text-white/40 hover:text-white uppercase tracking-wider cursor-pointer"
            >
              Verify Queue &rarr;
            </button>
          </div>
        </div>

        {/* Metric 4: Prize Pool */}
        <div className="bg-[#18181B] p-4 border-l-2 border-[#FF4D00] rounded-xs border-r border-t border-b border-white/5 flex flex-col justify-between">
          <p className="text-[10px] uppercase tracking-widest text-white/40 mb-1 font-mono font-bold">
            Prize Pool
          </p>
          <div className="flex items-baseline justify-between">
            <p className="text-2xl lg:text-3xl font-black font-mono text-white">
              ₹{(selectedTournament?.prizePool || 50000).toLocaleString('en-IN')}
            </p>
            <span className="text-[10px] font-mono text-[#FF4D00] font-bold">
              1st: ₹{(selectedTournament?.prizeBreakdown?.first || 25000).toLocaleString('en-IN')}
            </span>
          </div>
        </div>
      </div>

      {/* Main Grid: 8 Cols (Table & Standings) + 4 Cols (Next Fixture & Payment Queue) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left 8 Cols: Team & Squad Registry & Standings */}
        <div className="lg:col-span-8 flex flex-col space-y-4">
          {/* Team Registry Quick Table */}
          <div className="bg-[#18181B] rounded-xs border border-white/5 overflow-hidden flex flex-col">
            <div className="p-4 border-b border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h2 className="text-xs font-bold uppercase tracking-widest font-mono text-white flex items-center gap-2">
                  <Users className="w-3.5 h-3.5 text-[#FF4D00]" />
                  Team & Squad Registry ({teams.length})
                </h2>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setActiveTab('teams')}
                  className="px-3 py-1 bg-white/5 hover:bg-white/10 border border-white/10 text-[10px] uppercase font-mono text-white/70 hover:text-white transition-colors cursor-pointer"
                >
                  Manage Teams
                </button>
                <button
                  onClick={() => setActiveTab('teams')}
                  className="px-3 py-1 bg-[#FF4D00] hover:bg-[#E04400] text-black text-[10px] font-black uppercase font-mono tracking-wider transition-colors cursor-pointer"
                >
                  Slot Allocator
                </button>
              </div>
            </div>

            <div className="overflow-x-auto font-mono text-[11px]">
              <table className="w-full text-left">
                <thead className="bg-white/5 text-white/40">
                  <tr>
                    <th className="py-2.5 px-4 font-medium uppercase">Team Name</th>
                    <th className="py-2.5 px-4 font-medium uppercase">Captain UID</th>
                    <th className="py-2.5 px-4 font-medium uppercase">Status</th>
                    <th className="py-2.5 px-4 font-medium uppercase">Group / Slot</th>
                    <th className="py-2.5 px-4 text-right font-medium uppercase">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {teams.slice(0, 5).map((team, idx) => (
                    <tr key={team.id} className={idx % 2 === 0 ? 'bg-white/[0.02]' : ''}>
                      <td className="py-3 px-4 font-bold text-white flex items-center gap-1.5">
                        <span>{team.name}</span>
                        {team.tag && <span className="text-[10px] text-white/40">[{team.tag}]</span>}
                      </td>
                      <td className="py-3 px-4 text-white/70">
                        UID: {team.captainUid || '99182310'}
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`px-1.5 py-0.5 rounded-xs text-[10px] font-bold ${
                            team.status === 'QUALIFIED'
                              ? 'text-[#00FF66] bg-[#00FF66]/10'
                              : team.status === 'PENDING_VERIFICATION'
                              ? 'text-yellow-400 bg-yellow-400/10'
                              : 'text-rose-400 bg-rose-400/10'
                          }`}
                        >
                          {team.status === 'QUALIFIED'
                            ? 'VERIFIED'
                            : team.status === 'PENDING_VERIFICATION'
                            ? 'PENDING PAY'
                            : team.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-white/60">
                        {team.group ? `${team.group} (Slot ${team.slotNumber ? team.slotNumber.toString().padStart(2, '0') : '01'})` : 'UNASSIGNED'}
                      </td>
                      <td className="py-3 px-4 text-right space-x-2">
                        <button
                          onClick={() => setActiveTab('teams')}
                          className="text-white/40 hover:text-white uppercase font-bold text-[10px] tracking-wider cursor-pointer"
                        >
                          VIEW
                        </button>
                        <button
                          onClick={() => setActiveTab('teams')}
                          className="text-[#FF4D00] hover:text-[#FF6B2B] uppercase font-bold text-[10px] tracking-wider cursor-pointer"
                        >
                          ROSTER
                        </button>
                      </td>
                    </tr>
                  ))}
                  {teams.length === 0 && (
                    <tr>
                      <td colSpan={5} className="py-8 text-center text-white/40">
                        No squads registered. Use the Seed Data button to populate sample rosters.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Standings Top Matrix */}
          <div className="bg-[#18181B] rounded-xs border border-white/5 overflow-hidden flex flex-col">
            <div className="p-4 border-b border-white/5 flex items-center justify-between">
              <h2 className="text-xs font-bold uppercase tracking-widest font-mono text-white flex items-center gap-2">
                <Trophy className="w-3.5 h-3.5 text-amber-400" />
                Tournament Leaderboard Matrix (Top 5)
              </h2>
              <button
                onClick={() => setActiveTab('standings')}
                className="text-[10px] font-mono text-[#FF4D00] hover:underline uppercase font-bold tracking-wider cursor-pointer"
              >
                Full Standings &rarr;
              </button>
            </div>

            <div className="overflow-x-auto font-mono text-[11px]">
              <table className="w-full text-left">
                <thead className="bg-white/5 text-white/40">
                  <tr>
                    <th className="py-2.5 px-4 font-medium uppercase w-10">#</th>
                    <th className="py-2.5 px-4 font-medium uppercase">Team Name</th>
                    <th className="py-2.5 px-4 font-medium uppercase text-center">Played</th>
                    <th className="py-2.5 px-4 font-medium uppercase text-center">Booyahs 👑</th>
                    <th className="py-2.5 px-4 font-medium uppercase text-center">Kill PTS</th>
                    <th className="py-2.5 px-4 text-right font-medium uppercase">Total PTS</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {overallStandings.slice(0, 5).map((s, idx) => (
                    <tr key={s.teamId} className={idx === 0 ? 'bg-[#FF4D00]/5' : ''}>
                      <td className="py-2.5 px-4 font-bold text-white">
                        {idx === 0 ? '01' : `0${idx + 1}`}
                      </td>
                      <td className="py-2.5 px-4 font-bold text-white flex items-center gap-1.5 font-sans">
                        <span>{s.teamName}</span>
                        {s.teamTag && <span className="text-[10px] text-white/40 font-mono">[{s.teamTag}]</span>}
                      </td>
                      <td className="py-2.5 px-4 text-center text-white/70">{s.matchesPlayed}</td>
                      <td className="py-2.5 px-4 text-center text-amber-400 font-bold">
                        {s.booyahs > 0 ? `👑 ${s.booyahs}` : '0'}
                      </td>
                      <td className="py-2.5 px-4 text-center text-[#00E5FF] font-bold">{s.killPoints}</td>
                      <td className="py-2.5 px-4 text-right font-bold text-[#FF4D00] text-xs">
                        {s.totalPoints} PTS
                      </td>
                    </tr>
                  ))}
                  {overallStandings.length === 0 && (
                    <tr>
                      <td colSpan={6} className="py-6 text-center text-white/40">
                        Standings will automatically calculate upon match completion.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Right 4 Cols: Next Fixture Radar & Payment Portal Queue */}
        <div className="lg:col-span-4 flex flex-col space-y-4">
          {/* Next Fixture Live Countdown Card */}
          <div className="bg-[#18181B] p-5 lg:p-6 rounded-xs border border-white/5 relative overflow-hidden flex flex-col justify-between">
            <div className="absolute top-0 right-0 p-3">
              <div className="bg-[#FF4D00] text-[9px] font-black px-2.5 py-0.5 rounded-full text-black uppercase tracking-wider">
                LIVE MATCH
              </div>
            </div>

            <div>
              <h3 className="text-xs uppercase tracking-widest text-white/40 mb-3 font-mono font-bold">
                Next Fixture Radar
              </h3>
              <p className="text-sm font-bold font-serif italic text-white mb-4 line-clamp-1">
                {nextMatch?.title || 'Group A - Match 01'}
              </p>

              <div className="flex items-end space-x-3 mb-5">
                <span className="text-4xl lg:text-5xl font-black italic tracking-tighter leading-none font-serif text-white">
                  {timeRemaining || '14:52'}
                </span>
                <span className="text-xs font-mono text-[#FF4D00] mb-1 font-bold tracking-wider uppercase">
                  MINUTES LEFT
                </span>
              </div>
            </div>

            <div className="space-y-3 font-mono text-xs">
              <div className="p-3 bg-white/5 rounded-xs border border-white/10 space-y-2">
                <div className="flex items-center justify-between text-[10px] text-white/40 uppercase">
                  <span>Map: {nextMatch?.map || 'Bermuda'}</span>
                  <span>Stage: {nextMatch?.stage || 'Group A'}</span>
                </div>

                <div className="flex justify-between items-center pt-1 border-t border-white/5">
                  <span className="text-white/70">
                    ROOM ID: <span className="text-white font-bold">{nextMatch?.roomId || '8821 0022'}</span>
                  </span>
                  <button
                    onClick={() => copyToClipboard(nextMatch?.roomId || '88210022', 'dash-room')}
                    className="text-[#00FF66] hover:underline font-bold text-[10px] cursor-pointer"
                  >
                    {copiedKey === 'dash-room' ? 'COPIED' : 'COPY'}
                  </button>
                </div>

                <div className="flex justify-between items-center">
                  <span className="text-white/70">
                    PASS: <span className="text-[#FF4D00] font-bold">{nextMatch?.roomPassword || 'FFWS7781'}</span>
                  </span>
                  <button
                    onClick={() => copyToClipboard(nextMatch?.roomPassword || 'FFWS7781', 'dash-pass')}
                    className="text-[#00FF66] hover:underline font-bold text-[10px] cursor-pointer"
                  >
                    {copiedKey === 'dash-pass' ? 'COPIED' : 'COPY'}
                  </button>
                </div>
              </div>

              <button
                onClick={() =>
                  publishRoomCredentials(
                    nextMatch?.id || 'm-1',
                    nextMatch?.roomId || 'FF-88210022',
                    nextMatch?.roomPassword || 'FFWS7781',
                    !nextMatch?.isCredentialsPublished
                  )
                }
                className="w-full py-2.5 bg-[#FF4D00] hover:bg-[#E04400] text-black font-black uppercase text-xs tracking-widest transition-colors cursor-pointer shadow-md"
              >
                {nextMatch?.isCredentialsPublished ? 'Hide Credentials' : 'Publish Now'}
              </button>
            </div>
          </div>

          {/* Payment Portal Queue Card */}
          <div className="flex-1 bg-[#18181B] p-4 rounded-xs border border-white/5 flex flex-col">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs uppercase tracking-widest text-white/40 font-mono font-bold">
                Payment Portal (Queue: {pendingPayments.length.toString().padStart(2, '0')})
              </h3>
              <button
                onClick={() => setActiveTab('payments')}
                className="text-[10px] font-mono text-white/40 hover:text-white uppercase cursor-pointer"
              >
                View All
              </button>
            </div>

            <div className="space-y-2.5 overflow-y-auto max-h-64 pr-1">
              {pendingPayments.slice(0, 3).map((p) => (
                <div key={p.id} className="p-3 bg-[#0D0D0F] border-l-2 border-yellow-500 rounded-xs space-y-2 font-mono">
                  <div className="flex justify-between text-[10px] text-white/40">
                    <span>UTR: {p.utrNumber}</span>
                    <span>{new Date(p.submittedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                  <p className="text-xs font-bold text-white font-sans">
                    TEAM: {p.teamName}
                  </p>
                  <div className="flex items-center justify-between text-[10px] text-white/60">
                    <span>Amount: ₹{p.amount}</span>
                    <span>Via: {p.paymentMethod}</span>
                  </div>
                  <div className="pt-1 flex space-x-2">
                    <button
                      onClick={() => verifyPayment(p.id, p.teamId, 'VERIFIED')}
                      className="flex-1 py-1.5 bg-[#00FF66] hover:bg-[#00E55C] text-black font-black text-[10px] uppercase transition-colors cursor-pointer text-center"
                    >
                      Verify
                    </button>
                    <button
                      onClick={() => setActiveTab('payments')}
                      className="flex-1 py-1.5 bg-white/5 hover:bg-white/10 text-white/40 hover:text-white text-[10px] uppercase transition-colors cursor-pointer text-center"
                    >
                      View
                    </button>
                  </div>
                </div>
              ))}

              {pendingPayments.length === 0 && (
                <div className="py-8 text-center text-white/40 text-xs font-mono">
                  No pending payments in verification queue.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
