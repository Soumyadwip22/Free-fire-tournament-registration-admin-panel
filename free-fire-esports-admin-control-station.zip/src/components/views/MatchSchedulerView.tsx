import React, { useState, useEffect } from 'react';
import { useTournament } from '../../context/TournamentContext';
import { MatchFixture, MapType, GroupType, MatchStatus } from '../../types';
import {
  Swords,
  Plus,
  Radio,
  Clock,
  Key,
  Copy,
  Check,
  Send,
  Trash2,
  Edit2,
  ExternalLink,
  CheckCircle2,
  AlertTriangle,
  Play,
  RotateCcw,
} from 'lucide-react';

const MAP_THEMES: Record<MapType, { bg: string; border: string; text: string }> = {
  Bermuda: { bg: 'from-emerald-950/40 to-zinc-900', border: 'border-emerald-500/40', text: 'text-emerald-400' },
  Purgatory: { bg: 'from-orange-950/40 to-zinc-900', border: 'border-orange-500/40', text: 'text-orange-400' },
  Kalahari: { bg: 'from-amber-950/40 to-zinc-900', border: 'border-amber-500/40', text: 'text-amber-400' },
  Alpine: { bg: 'from-cyan-950/40 to-zinc-900', border: 'border-cyan-500/40', text: 'text-cyan-400' },
  NexTerra: { bg: 'from-purple-950/40 to-zinc-900', border: 'border-purple-500/40', text: 'text-purple-400' },
};

export const MatchSchedulerView: React.FC = () => {
  const {
    matches,
    saveMatch,
    deleteMatch,
    updateMatchStatus,
    publishRoomCredentials,
    selectedTournament,
  } = useTournament();

  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isNewFixtureModalOpen, setIsNewFixtureModalOpen] = useState(false);
  const [editingMatch, setEditingMatch] = useState<MatchFixture | null>(null);

  // Form State for new/edit fixture
  const [formMatch, setFormMatch] = useState<Partial<MatchFixture>>({
    title: 'Group A - Match 1 (Bermuda)',
    stage: 'Group A',
    map: 'Bermuda',
    scheduledTime: new Date(Date.now() + 1000 * 60 * 30).toISOString().slice(0, 16),
    roomId: '',
    roomPassword: '',
    autoRelease15Min: true,
    isCredentialsPublished: false,
    status: 'SCHEDULED',
  });

  // Ticker for live 15-minute countdown engine
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleCopyBroadcastTemplate = (match: MatchFixture) => {
    const text = `🔥 FREE FIRE ESPORTS - OFFICIAL ROOM DETAILS 🔥\n\n🏆 Tournament: ${selectedTournament?.title}\n⚔️ Match: ${match.title}\n🗺️ Map: ${match.map}\n🕒 Match Kickoff: ${new Date(match.scheduledTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}\n\n🔑 ROOM ID: ${match.roomId || 'TBA'}\n🔒 PASSWORD: ${match.roomPassword || 'TBA'}\n\n⚠️ IMPORTANT:\n• All teams must join their allotted Slot Number (1-12) within 10 minutes.\n• Emulators/PC players are prohibited.`;
    handleCopy(text, `broadcast-${match.id}`);
  };

  const handleSubmitFixture = async (e: React.FormEvent) => {
    e.preventDefault();
    const newId = editingMatch?.id || 'match-' + Date.now().toString(36);
    const fixtureToSave: MatchFixture = {
      id: newId,
      tournamentId: selectedTournament?.id || 'tourn-1',
      matchNumber: matches.length + 1,
      title: formMatch.title || 'Group Match',
      stage: (formMatch.stage as GroupType) || 'Group A',
      map: (formMatch.map as MapType) || 'Bermuda',
      scheduledTime: new Date(formMatch.scheduledTime || Date.now()).toISOString(),
      roomId: formMatch.roomId || 'FF-' + Math.floor(100000 + Math.random() * 900000),
      roomPassword: formMatch.roomPassword || 'FFWS@' + Math.floor(1000 + Math.random() * 9000),
      isCredentialsPublished: formMatch.isCredentialsPublished || false,
      autoRelease15Min: formMatch.autoRelease15Min ?? true,
      status: (formMatch.status as MatchStatus) || 'SCHEDULED',
      liveStreamUrl: formMatch.liveStreamUrl,
      createdAt: editingMatch?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    await saveMatch(fixtureToSave);
    setIsNewFixtureModalOpen(false);
    setEditingMatch(null);
  };

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold font-serif italic text-white">
              15-Minute Room Engine & Match Scheduler
            </h1>
            <span className="text-xs font-mono font-bold text-[#FF4D00]">({matches.length} FIXTURES)</span>
          </div>
          <p className="text-xs text-white/40 font-mono mt-0.5">
            Automated lobby credential dispatch. Room ID and password reveal exactly 15m before kickoff.
          </p>
        </div>

        <button
          onClick={() => {
            setEditingMatch(null);
            setFormMatch({
              title: `Group A - Match ${matches.length + 1}`,
              stage: 'Group A',
              map: 'Bermuda',
              scheduledTime: new Date(Date.now() + 1000 * 60 * 25).toISOString().slice(0, 16),
              roomId: 'FF-' + Math.floor(100000 + Math.random() * 900000),
              roomPassword: 'FFWS@' + Math.floor(1000 + Math.random() * 9000),
              autoRelease15Min: true,
              isCredentialsPublished: false,
              status: 'SCHEDULED',
            });
            setIsNewFixtureModalOpen(true);
          }}
          className="px-3.5 py-1.5 rounded-xs bg-[#FF4D00] hover:bg-[#E04400] text-black text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5 cursor-pointer shadow-md self-start sm:self-auto transition-colors"
        >
          <Plus className="w-3.5 h-3.5 text-black" />
          <span>Schedule Fixture</span>
        </button>
      </div>

      {/* Match Fixture Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {matches.map((match) => {
          const matchTime = new Date(match.scheduledTime).getTime();
          const diffMs = matchTime - now;
          const isWithin15Min = diffMs > 0 && diffMs <= 15 * 60 * 1000;

          let countdownString = '';
          if (diffMs > 0) {
            const mins = Math.floor(diffMs / 60000);
            const secs = Math.floor((diffMs % 60000) / 1000);
            countdownString = `${mins}m ${secs.toString().padStart(2, '0')}s`;
          } else if (match.status === 'IN_PROGRESS') {
            countdownString = 'LIVE IN PROGRESS';
          } else if (match.status === 'COMPLETED') {
            countdownString = 'COMPLETED';
          } else {
            countdownString = 'MATCH OVERDUE';
          }

          return (
            <div
              key={match.id}
              className={`rounded-xs bg-[#18181B] border transition-all p-5 space-y-4 relative overflow-hidden shadow-xl ${
                isWithin15Min
                  ? 'border-l-2 border-[#00FF66] border-t-white/5 border-r-white/5 border-b-white/5 ring-1 ring-[#00FF66]/20'
                  : 'border-l-2 border-[#FF4D00] border-t-white/5 border-r-white/5 border-b-white/5 hover:border-r-white/10'
              }`}
            >
              {/* Card Header */}
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="px-1.5 py-0.5 rounded-xs text-[9px] font-mono font-black uppercase bg-[#0D0D0F] border border-white/10 text-[#FF4D00]">
                      MAP: {match.map}
                    </span>
                    <span className="px-1.5 py-0.5 rounded-xs text-[9px] font-mono font-bold uppercase bg-[#0D0D0F] text-white/60 border border-white/10">
                      {match.stage}
                    </span>
                    {isWithin15Min && (
                      <span className="px-1.5 py-0.5 rounded-xs text-[9px] font-mono font-black bg-[#00FF66] text-black animate-pulse">
                        15M UNLOCK TRIGGERED
                      </span>
                    )}
                  </div>
                  <h3 className="text-base font-bold font-serif italic text-white">{match.title}</h3>
                </div>

                {/* Status Switcher Dropdown */}
                <select
                  value={match.status}
                  onChange={(e) => updateMatchStatus(match.id, e.target.value as MatchStatus)}
                  className={`px-2 py-1 rounded-xs text-[10px] font-mono font-black uppercase cursor-pointer border ${
                    match.status === 'IN_PROGRESS'
                      ? 'bg-rose-500/20 text-rose-400 border-rose-500/40'
                      : match.status === 'COMPLETED'
                      ? 'bg-[#00FF66]/20 text-[#00FF66] border-[#00FF66]/40'
                      : match.status === 'CANCELLED'
                      ? 'bg-white/5 text-white/40 border-white/10'
                      : 'bg-[#FF4D00]/20 text-[#FF4D00] border-[#FF4D00]/40'
                  }`}
                >
                  <option value="SCHEDULED">Scheduled</option>
                  <option value="IN_PROGRESS">In Progress</option>
                  <option value="COMPLETED">Completed</option>
                  <option value="CANCELLED">Cancelled</option>
                </select>
              </div>

              {/* Time & Countdown Ticker */}
              <div className="p-3 rounded-xs bg-[#0D0D0F] border border-white/5 flex items-center justify-between font-mono">
                <div className="flex items-center gap-2 text-white/80 text-xs">
                  <Clock className="w-3.5 h-3.5 text-[#FF4D00]" />
                  <span>
                    {new Date(match.scheduledTime).toLocaleDateString([], { month: 'short', day: 'numeric' })},{' '}
                    {new Date(match.scheduledTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>

                <div className="flex items-center gap-1.5 text-xs font-bold">
                  <span className="text-white/40">T-MINUS:</span>
                  <span
                    className={
                      isWithin15Min
                        ? 'text-[#00FF66] animate-pulse text-sm'
                        : match.status === 'IN_PROGRESS'
                        ? 'text-rose-400'
                        : 'text-white'
                    }
                  >
                    {countdownString}
                  </span>
                </div>
              </div>

              {/* Room ID & Password Control Box */}
              <div className="p-4 rounded-xs bg-[#0D0D0F] border border-white/5 space-y-3 font-mono">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest flex items-center gap-1.5">
                    <Key className="w-3.5 h-3.5 text-[#FF4D00]" />
                    Room Credentials Matrix
                  </span>
                  <span
                    className={`text-[9px] px-1.5 py-0.5 rounded-xs font-black uppercase ${
                      match.isCredentialsPublished
                        ? 'bg-[#00FF66]/10 text-[#00FF66] border border-[#00FF66]/30'
                        : 'bg-white/5 text-white/40'
                    }`}
                  >
                    {match.isCredentialsPublished ? 'PUBLICLY VISIBLE' : 'LOCKED (15M AUTO)'}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div className="p-2.5 bg-[#18181B] rounded-xs border border-white/10 flex items-center justify-between">
                    <div>
                      <div className="text-[9px] text-white/40">ROOM ID</div>
                      <div className="text-xs font-bold text-white tracking-wider">
                        {match.roomId || 'Unset'}
                      </div>
                    </div>
                    {match.roomId && (
                      <button
                        onClick={() => handleCopy(match.roomId!, `room-${match.id}`)}
                        className="p-1 text-white/40 hover:text-white"
                        title="Copy Room ID"
                      >
                        {copiedId === `room-${match.id}` ? (
                          <Check className="w-3.5 h-3.5 text-[#00FF66]" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    )}
                  </div>

                  <div className="p-2.5 bg-[#18181B] rounded-xs border border-white/10 flex items-center justify-between">
                    <div>
                      <div className="text-[9px] text-white/40">PASSWORD</div>
                      <div className="text-xs font-bold text-[#FF4D00] tracking-wider">
                        {match.roomPassword || 'Unset'}
                      </div>
                    </div>
                    {match.roomPassword && (
                      <button
                        onClick={() => handleCopy(match.roomPassword!, `pass-${match.id}`)}
                        className="p-1 text-white/40 hover:text-white"
                        title="Copy Password"
                      >
                        {copiedId === `pass-${match.id}` ? (
                          <Check className="w-3.5 h-3.5 text-[#00FF66]" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    )}
                  </div>
                </div>

                {/* Broadcast & Publish Controls */}
                <div className="flex items-center gap-2 pt-1">
                  <button
                    onClick={() =>
                      publishRoomCredentials(
                        match.id,
                        match.roomId || 'FF-' + Math.floor(100000 + Math.random() * 900000),
                        match.roomPassword || 'FFWS@' + Math.floor(1000 + Math.random() * 9000),
                        !match.isCredentialsPublished
                      )
                    }
                    className={`flex-1 py-2 rounded-xs text-[10px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                      match.isCredentialsPublished
                        ? 'bg-white/5 hover:bg-white/10 text-white border border-white/10'
                        : 'bg-[#FF4D00] hover:bg-[#E04400] text-black font-black shadow-md'
                    }`}
                  >
                    <Radio className="w-3.5 h-3.5" />
                    <span>{match.isCredentialsPublished ? 'Hide Credentials' : 'Publish Credentials Now'}</span>
                  </button>

                  <button
                    onClick={() => handleCopyBroadcastTemplate(match)}
                    className="px-3 py-2 rounded-xs bg-white/5 hover:bg-white/10 border border-white/10 text-white/80 hover:text-white text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 cursor-pointer transition-colors"
                    title="Copy WhatsApp/Discord formatted broadcast template"
                  >
                    <Send className="w-3.5 h-3.5 text-[#00FF66]" />
                    <span className="hidden sm:inline">
                      {copiedId === `broadcast-${match.id}` ? 'Copied!' : 'Dispatch'}
                    </span>
                  </button>
                </div>
              </div>

              {/* Action Controls Footer */}
              <div className="flex items-center justify-between pt-1 text-xs text-white/40 font-mono">
                <div className="text-[10px]">
                  {match.autoRelease15Min ? '⚡ Auto-unlock @ 15m' : 'Manual release'}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setEditingMatch(match);
                      setFormMatch({
                        ...match,
                        scheduledTime: new Date(match.scheduledTime).toISOString().slice(0, 16),
                      });
                      setIsNewFixtureModalOpen(true);
                    }}
                    className="p-1.5 text-white/40 hover:text-white hover:bg-white/5 rounded-xs transition-colors cursor-pointer"
                    title="Edit Fixture"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => {
                      if (window.confirm(`Delete match "${match.title}"?`)) {
                        deleteMatch(match.id);
                      }
                    }}
                    className="p-1.5 text-white/40 hover:text-rose-400 hover:bg-white/5 rounded-xs transition-colors cursor-pointer"
                    title="Delete Fixture"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Schedule Fixture Modal */}
      {isNewFixtureModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-[#141417] border border-zinc-800 rounded-2xl p-6 shadow-2xl space-y-4">
            <h2 className="text-base font-bold font-display text-white uppercase">
              {editingMatch ? 'Edit Match Fixture' : 'Schedule Esports Match Fixture'}
            </h2>

            <form onSubmit={handleSubmitFixture} className="space-y-4">
              <div>
                <label className="block text-xs text-zinc-400 mb-1">Match Title</label>
                <input
                  type="text"
                  required
                  value={formMatch.title}
                  onChange={(e) => setFormMatch({ ...formMatch, title: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-zinc-400 mb-1">Esports Map</label>
                  <select
                    value={formMatch.map}
                    onChange={(e) => setFormMatch({ ...formMatch, map: e.target.value as MapType })}
                    className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white font-mono"
                  >
                    <option value="Bermuda">Bermuda (Standard)</option>
                    <option value="Purgatory">Purgatory</option>
                    <option value="Kalahari">Kalahari (Desert)</option>
                    <option value="Alpine">Alpine (Snow)</option>
                    <option value="NexTerra">NexTerra (Cyber)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs text-zinc-400 mb-1">Stage / Group</label>
                  <select
                    value={formMatch.stage}
                    onChange={(e) => setFormMatch({ ...formMatch, stage: e.target.value as GroupType })}
                    className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white font-mono"
                  >
                    <option value="Group A">Group A</option>
                    <option value="Group B">Group B</option>
                    <option value="Group C">Group C</option>
                    <option value="Grand Finals">Grand Finals</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs text-zinc-400 mb-1">Scheduled Kickoff Time</label>
                <input
                  type="datetime-local"
                  required
                  value={formMatch.scheduledTime}
                  onChange={(e) => setFormMatch({ ...formMatch, scheduledTime: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-zinc-400 mb-1">Room ID</label>
                  <input
                    type="text"
                    placeholder="e.g. FF-772910"
                    value={formMatch.roomId}
                    onChange={(e) => setFormMatch({ ...formMatch, roomId: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs text-zinc-400 mb-1">Room Password</label>
                  <input
                    type="text"
                    placeholder="e.g. FFWS@2026"
                    value={formMatch.roomPassword}
                    onChange={(e) => setFormMatch({ ...formMatch, roomPassword: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-700 text-xs text-white font-mono"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="auto15m"
                  checked={formMatch.autoRelease15Min}
                  onChange={(e) => setFormMatch({ ...formMatch, autoRelease15Min: e.target.checked })}
                  className="rounded bg-zinc-900 border-zinc-700 text-[#FF4D00] focus:ring-0"
                />
                <label htmlFor="auto15m" className="text-xs text-zinc-300 cursor-pointer">
                  Enable automatic 15-minute countdown credential unlock
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-zinc-800">
                <button
                  type="button"
                  onClick={() => setIsNewFixtureModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-zinc-800 text-zinc-400 hover:text-white text-xs cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-[#FF4D00] hover:bg-[#E04400] text-white text-xs font-semibold uppercase font-display cursor-pointer"
                >
                  {editingMatch ? 'Update Fixture' : 'Schedule Fixture'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
