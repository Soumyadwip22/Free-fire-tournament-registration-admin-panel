import React, { useState } from 'react';
import { useTournament } from '../../context/TournamentContext';
import { MatchFixture, GroupType } from '../../types';
import { MatchResultModal } from '../modals/MatchResultModal';
import confetti from 'canvas-confetti';
import {
  Calculator,
  Trophy,
  Flame,
  Download,
  Share2,
  CheckCircle2,
  Sparkles,
  Plus,
  Radio,
  Copy,
  Check,
  Award,
} from 'lucide-react';

export const PointTableCalculatorView: React.FC = () => {
  const {
    overallStandings,
    matches,
    teams,
    matchResults,
    saveMatchResult,
    publishStandings,
    exportStandingsCSV,
    selectedTournament,
  } = useTournament();

  const [selectedGroup, setSelectedGroup] = useState<string>('OVERALL');
  const [selectedMatchForResult, setSelectedMatchForResult] = useState<MatchFixture | null>(null);
  const [copiedBroadcast, setCopiedBroadcast] = useState(false);
  const [isPublishing, setIsPublishing] = useState(false);

  // Filter standings by group or show overall
  const filteredStandings = React.useMemo(() => {
    if (selectedGroup === 'OVERALL') {
      return overallStandings;
    }
    return overallStandings.filter((s) => s.group === selectedGroup);
  }, [overallStandings, selectedGroup]);

  const handlePublish = async () => {
    setIsPublishing(true);
    await publishStandings(true);
    setIsPublishing(false);

    // Fire esports victory confetti
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#FF4D00', '#00FF66', '#FFD700', '#FFFFFF'],
    });
  };

  const handleCopyStandingsBroadcast = () => {
    const lines = [
      `🔥 FREE FIRE ESPORTS - OFFICIAL POINT TABLE 🔥`,
      `🏆 Tournament: ${selectedTournament?.title}`,
      `📊 Stage: ${selectedGroup}`,
      `🕒 Updated: ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
      ``,
      `RANK | SQUAD | BOOYAH | KILLS | TOTAL PTS`,
      `------------------------------------------`,
    ];

    filteredStandings.slice(0, 12).forEach((s, idx) => {
      lines.push(
        `#${idx + 1} | ${s.teamName} [${s.teamTag || 'TAG'}] | 👑${s.booyahs} | 🎯${s.killPoints} | ⚡${s.totalPoints} PTS`
      );
    });

    lines.push(``);
    lines.push(`Official results verified by Organizer Station.`);

    navigator.clipboard.writeText(lines.join('\n'));
    setCopiedBroadcast(true);
    setTimeout(() => setCopiedBroadcast(false), 2000);
  };

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-7xl mx-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold font-serif italic text-white">
              Official Points & Standings Engine
            </h1>
            <span className="text-xs font-mono font-bold text-[#FF4D00]">({filteredStandings.length} TEAMS)</span>
          </div>
          <p className="text-xs text-white/40 font-mono mt-0.5">
            Automated FFWS point calculator matrix. Record match kills & placements, broadcast live standings.
          </p>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap font-mono text-xs">
          <button
            onClick={handleCopyStandingsBroadcast}
            className="px-3 py-1.5 rounded-xs bg-white/5 hover:bg-white/10 border border-white/10 text-[10px] font-bold uppercase tracking-wider text-white/80 hover:text-white flex items-center gap-1.5 cursor-pointer shadow-sm transition-colors"
          >
            {copiedBroadcast ? <Check className="w-3.5 h-3.5 text-[#00FF66]" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedBroadcast ? 'Copied Broadcast!' : 'Copy Broadcast'}</span>
          </button>

          <button
            onClick={() => exportStandingsCSV(selectedGroup)}
            className="px-3 py-1.5 rounded-xs bg-white/5 hover:bg-white/10 border border-white/10 text-[10px] font-bold uppercase tracking-wider text-white/80 hover:text-white flex items-center gap-1.5 cursor-pointer shadow-sm transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-[#00FF66]" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={handlePublish}
            disabled={isPublishing}
            className="px-3.5 py-1.5 rounded-xs bg-[#FF4D00] hover:bg-[#E04400] text-black text-[10px] font-black tracking-widest uppercase flex items-center gap-1.5 cursor-pointer shadow-md transition-colors"
          >
            <Sparkles className="w-3.5 h-3.5 text-black" />
            <span>{isPublishing ? 'Publishing...' : 'Publish Standings'}</span>
          </button>
        </div>
      </div>

      {/* Esports Official Matrix Info Bar */}
      <div className="p-3.5 rounded-xs bg-[#18181B] border border-white/5 space-y-2 font-mono">
        <div className="flex items-center justify-between">
          <div className="text-[10px] font-black text-[#FF4D00] uppercase tracking-widest flex items-center gap-1.5">
            <Trophy className="w-3.5 h-3.5 text-[#FF4D00]" />
            Official Free Fire Esports Scoring Matrix
          </div>
          <span className="text-[10px] text-white/40 font-bold">1 ELIMINATION = 1 PT</span>
        </div>

        <div className="grid grid-cols-4 sm:grid-cols-6 lg:grid-cols-12 gap-1 text-center text-[10px]">
          {[
            { place: '#1 (BOOYAH)', pts: '12 PTS', color: 'bg-[#FF4D00]/10 text-[#FF4D00] border-[#FF4D00]/30 font-black' },
            { place: '#2', pts: '9 PTS', color: 'bg-white/5 text-white/80 border-white/10' },
            { place: '#3', pts: '8 PTS', color: 'bg-white/5 text-white/80 border-white/10' },
            { place: '#4', pts: '7 PTS', color: 'bg-white/5 text-white/80 border-white/10' },
            { place: '#5', pts: '6 PTS', color: 'bg-white/5 text-white/80 border-white/10' },
            { place: '#6', pts: '5 PTS', color: 'bg-white/5 text-white/80 border-white/10' },
            { place: '#7', pts: '4 PTS', color: 'bg-white/5 text-white/80 border-white/10' },
            { place: '#8', pts: '3 PTS', color: 'bg-white/5 text-white/80 border-white/10' },
            { place: '#9', pts: '2 PTS', color: 'bg-white/5 text-white/80 border-white/10' },
            { place: '#10', pts: '1 PT', color: 'bg-white/5 text-white/80 border-white/10' },
            { place: '#11', pts: '0 PT', color: 'bg-[#0D0D0F] text-white/30 border-white/5' },
            { place: '#12', pts: '0 PT', color: 'bg-[#0D0D0F] text-white/30 border-white/5' },
          ].map((item, idx) => (
            <div key={idx} className={`p-1.5 rounded-xs border ${item.color}`}>
              <div className="text-[8px] text-white/40">{item.place}</div>
              <div className="font-bold">{item.pts}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Record Match Scores Quick Bar */}
      <div className="p-3.5 rounded-xs bg-[#18181B] border border-white/5 flex flex-col md:flex-row md:items-center justify-between gap-3 font-mono">
        <div className="flex items-center gap-2">
          <Flame className="w-3.5 h-3.5 text-[#FF4D00]" />
          <span className="text-[10px] font-black text-white/80 uppercase tracking-wider">
            Record Scores ({matches.length} Matches)
          </span>
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0">
          {matches.map((m) => {
            const hasResult = matchResults.some((r) => r.matchId === m.id);
            return (
              <button
                key={m.id}
                onClick={() => setSelectedMatchForResult(m)}
                className={`px-2.5 py-1 rounded-xs text-[10px] font-bold uppercase whitespace-nowrap transition-colors flex items-center gap-1.5 cursor-pointer ${
                  hasResult
                    ? 'bg-[#00FF66]/10 text-[#00FF66] border border-[#00FF66]/30'
                    : 'bg-[#0D0D0F] hover:bg-white/10 text-white/60 hover:text-white border border-white/10'
                }`}
              >
                {hasResult ? <CheckCircle2 className="w-3 h-3 text-[#00FF66]" /> : <Plus className="w-3 h-3" />}
                <span>{m.title}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Group Stage Filter Tabs */}
      <div className="flex items-center gap-2 border-b border-white/5 pb-2 font-mono">
        {['OVERALL', 'Group A', 'Group B', 'Group C', 'Grand Finals'].map((grp) => (
          <button
            key={grp}
            onClick={() => setSelectedGroup(grp)}
            className={`px-3 py-1 rounded-xs text-[10px] font-bold uppercase tracking-wider transition-all cursor-pointer ${
              selectedGroup === grp
                ? 'bg-white/10 text-white border border-white/20'
                : 'text-white/40 hover:text-white'
            }`}
          >
            {grp}
          </button>
        ))}
      </div>

      {/* Leaderboard Table */}
      <div className="rounded-xs bg-[#18181B] border border-white/5 overflow-hidden shadow-xl font-mono">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-white/5 border-b border-white/5 text-white/40 text-[10px] uppercase">
                <th className="py-2.5 px-4 font-medium w-16 text-center">Rank</th>
                <th className="py-2.5 px-4 font-medium">Squad / Team</th>
                <th className="py-2.5 px-3 font-medium">Group</th>
                <th className="py-2.5 px-3 font-medium text-center">Matches</th>
                <th className="py-2.5 px-3 font-medium text-center">Booyahs</th>
                <th className="py-2.5 px-3 font-medium text-center">Place PTS</th>
                <th className="py-2.5 px-3 font-medium text-center">Kill PTS</th>
                <th className="py-2.5 px-4 font-medium text-right font-black text-white">Total PTS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredStandings.map((standing, idx) => (
                <tr
                  key={standing.teamId}
                  className={`hover:bg-white/[0.04] transition-colors ${
                    idx === 0
                      ? 'bg-[#FF4D00]/[0.06] border-l-2 border-[#FF4D00]'
                      : idx === 1
                      ? 'bg-white/[0.02]'
                      : idx === 2
                      ? 'bg-white/[0.01]'
                      : ''
                  }`}
                >
                  {/* Rank */}
                  <td className="py-3 px-4 text-center">
                    <span
                      className={`inline-flex w-6 h-6 rounded-xs items-center justify-center font-bold text-xs ${
                        idx === 0
                          ? 'bg-[#FF4D00] text-black font-black'
                          : idx === 1
                          ? 'bg-white/20 text-white font-black'
                          : idx === 2
                          ? 'bg-white/10 text-white/80'
                          : 'text-white/40'
                      }`}
                    >
                      {idx + 1}
                    </span>
                  </td>

                  {/* Team */}
                  <td className="py-3 px-4">
                    <div className="flex items-center gap-2">
                      <div className="font-sans font-bold text-white text-xs">{standing.teamName}</div>
                      {standing.teamTag && (
                        <span className="text-[10px] px-1 py-0.5 rounded-xs bg-[#0D0D0F] text-[#FF4D00] border border-white/10">
                          {standing.teamTag}
                        </span>
                      )}
                    </div>
                  </td>

                  {/* Group */}
                  <td className="py-3 px-3 text-white/40 text-[11px]">{standing.group}</td>

                  {/* Matches Played */}
                  <td className="py-3 px-3 text-center text-white/70">{standing.matchesPlayed}</td>

                  {/* Booyahs */}
                  <td className="py-3 px-3 text-center font-bold text-[#00FF66] text-xs">
                    {standing.booyahs > 0 ? `👑 ${standing.booyahs}` : '0'}
                  </td>

                  {/* Placement PTS */}
                  <td className="py-3 px-3 text-center text-white/70">{standing.placementPoints}</td>

                  {/* Kill PTS */}
                  <td className="py-3 px-3 text-center text-white font-bold">{standing.killPoints}</td>

                  {/* Total PTS */}
                  <td className="py-3 px-4 text-right font-black text-[#FF4D00] text-sm">
                    {standing.totalPoints}
                  </td>
                </tr>
              ))}

              {filteredStandings.length === 0 && (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-white/40 font-sans">
                    No scores recorded yet. Select a match above to input placement & kills.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Match Result Score Modal */}
      {selectedMatchForResult && (
        <MatchResultModal
          match={selectedMatchForResult}
          teams={teams}
          onClose={() => setSelectedMatchForResult(null)}
          onSaveResults={saveMatchResult}
        />
      )}
    </div>
  );
};
