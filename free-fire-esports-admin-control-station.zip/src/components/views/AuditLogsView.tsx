import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import {
  History,
  Search,
  Shield,
  Clock,
  User,
  Activity,
} from 'lucide-react';

export const AuditLogsView: React.FC = () => {
  const { auditLogs } = useAuth();
  const [searchQuery, setSearchQuery] = useState('');

  const filteredLogs = auditLogs.filter((log) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase().trim();
    return (
      log.action?.toLowerCase().includes(q) ||
      log.category?.toLowerCase().includes(q) ||
      log.adminEmail?.toLowerCase().includes(q) ||
      log.targetId?.toLowerCase().includes(q)
    );
  });

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-7xl mx-auto">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <h1 className="text-xl font-bold font-serif italic text-white">
            Action Audit Log & Security Trail
          </h1>
          <span className="text-xs font-mono font-bold text-[#FF4D00]">({auditLogs.length} EVENTS)</span>
        </div>
        <p className="text-xs text-white/40 font-mono mt-0.5">
          Forensic audit trail of administrative actions, payment verifications, score entries, and room credential publish events.
        </p>
      </div>

      {/* Search Input */}
      <div className="relative max-w-md font-mono">
        <Search className="w-4 h-4 text-white/40 absolute left-3 top-1/2 -translate-y-1/2" />
        <input
          type="text"
          placeholder="Filter audit logs by action or target ID..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-9 pr-4 py-2 rounded-xs bg-[#18181B] border border-white/10 text-xs text-white placeholder-white/40 focus:outline-none focus:border-[#FF4D00]"
        />
      </div>

      {/* Logs Table */}
      <div className="rounded-xs bg-[#18181B] border border-white/5 overflow-hidden shadow-xl font-mono">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-white/5 border-b border-white/5 text-white/40 text-[10px] uppercase">
                <th className="py-2.5 px-4 font-medium">Timestamp</th>
                <th className="py-2.5 px-3 font-medium">Organizer</th>
                <th className="py-2.5 px-3 font-medium">Category</th>
                <th className="py-2.5 px-4 font-medium">Action Description</th>
                <th className="py-2.5 px-3 font-medium">Target ID</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-white/[0.04] transition-colors">
                  <td className="py-3 px-4 text-white/40 text-[10px]">
                    {new Date(log.timestamp).toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-white/80 font-mono text-xs">
                    <div className="flex items-center gap-1.5">
                      <Shield className="w-3 h-3 text-[#FF4D00]" />
                      <span>{log.adminEmail}</span>
                    </div>
                  </td>
                  <td className="py-3 px-3">
                    <span className="px-1.5 py-0.5 rounded-xs text-[9px] bg-[#0D0D0F] border border-white/10 text-[#FF4D00] font-black uppercase">
                      {log.category}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-sans text-white text-xs">{log.action}</td>
                  <td className="py-3 px-3 text-white/30 text-[10px]">{log.targetId || '-'}</td>
                </tr>
              ))}

              {filteredLogs.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-12 text-center text-white/40 font-sans">
                    No activity logs found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
