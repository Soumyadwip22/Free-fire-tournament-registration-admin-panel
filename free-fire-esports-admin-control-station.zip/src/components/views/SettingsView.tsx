import React, { useState } from 'react';
import { useTournament } from '../../context/TournamentContext';
import {
  Settings,
  QrCode,
  Smartphone,
  MessageSquare,
  Globe,
  Save,
  CheckCircle2,
  HelpCircle,
  Flame,
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const { selectedTournament, saveTournament } = useTournament();

  const [upiId, setUpiId] = useState('soumyadwip@upi');
  const [payeeName, setPayeeName] = useState('Soumyadwip Mondal');
  const [qrCodeUrl, setQrCodeUrl] = useState(
    'https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=upi://pay?pa=soumyadwip@upi&pn=Soumyadwip%20Mondal&am=150&cu=INR'
  );
  const [whatsappLink, setWhatsappLink] = useState('https://chat.whatsapp.com/sample-freefire-esports');
  const [discordLink, setDiscordLink] = useState('https://discord.gg/freefireesports');
  const [helplinePhone, setHelplinePhone] = useState('+91 98765 43210');
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  return (
    <div className="p-4 lg:p-6 space-y-4 max-w-5xl mx-auto">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2">
          <h1 className="text-xl font-bold font-serif italic text-white">
            Organizer Configuration & UPI Gateway
          </h1>
        </div>
        <p className="text-xs text-white/40 font-mono mt-0.5">
          Configure payment gateway parameters, UPI QR endpoints, WhatsApp captain lines, and tournament contact numbers.
        </p>
      </div>

      {savedSuccess && (
        <div className="p-3 bg-[#00FF66]/10 border border-[#00FF66]/30 rounded-xs text-[#00FF66] text-xs font-mono font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4" />
          <span>Organizer settings successfully updated in system cache.</span>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-4 font-mono">
        {/* UPI Gateway Card */}
        <div className="p-5 rounded-xs bg-[#18181B] border border-white/5 space-y-4">
          <div className="flex items-center gap-2 text-[10px] font-black text-white uppercase tracking-widest border-b border-white/5 pb-3">
            <QrCode className="w-3.5 h-3.5 text-[#FF4D00]" />
            UPI Payment & Scanner Gateway
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="md:col-span-2 space-y-3">
              <div>
                <label className="block text-[10px] font-bold text-white/40 uppercase mb-1">
                  Organizer UPI ID (VPA)
                </label>
                <input
                  type="text"
                  required
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xs bg-[#0D0D0F] border border-white/10 text-xs text-white font-mono focus:border-[#FF4D00] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-white/40 uppercase mb-1">
                  Official Payee Name (GPay / PhonePe / Paytm)
                </label>
                <input
                  type="text"
                  required
                  value={payeeName}
                  onChange={(e) => setPayeeName(e.target.value)}
                  className="w-full px-3 py-2 rounded-xs bg-[#0D0D0F] border border-white/10 text-xs text-white font-sans focus:border-[#FF4D00] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-white/40 uppercase mb-1">
                  Custom QR Code Image URL
                </label>
                <input
                  type="url"
                  value={qrCodeUrl}
                  onChange={(e) => setQrCodeUrl(e.target.value)}
                  className="w-full px-3 py-2 rounded-xs bg-[#0D0D0F] border border-white/10 text-xs text-white font-mono focus:border-[#FF4D00] focus:outline-none"
                />
              </div>
            </div>

            {/* QR Preview */}
            <div className="flex flex-col items-center justify-center p-4 bg-[#0D0D0F] rounded-xs border border-white/5 text-center space-y-2">
              <div className="p-2 bg-white rounded-xs shadow-md">
                <img
                  src={qrCodeUrl}
                  alt="UPI QR"
                  className="w-32 h-32 object-contain"
                />
              </div>
              <div className="text-[10px] font-mono text-white/40">
                Scan & Pay <span className="text-[#FF4D00] font-bold">₹{selectedTournament?.entryFee || 150}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Support Channels Card */}
        <div className="p-5 rounded-xs bg-[#18181B] border border-white/5 space-y-4">
          <div className="flex items-center gap-2 text-[10px] font-black text-white uppercase tracking-widest border-b border-white/5 pb-3">
            <MessageSquare className="w-3.5 h-3.5 text-[#00FF66]" />
            Official Community & Support Channels
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-[10px] font-bold text-white/40 uppercase mb-1">
                WhatsApp Captain Group Link
              </label>
              <input
                type="url"
                value={whatsappLink}
                onChange={(e) => setWhatsappLink(e.target.value)}
                className="w-full px-3 py-2 rounded-xs bg-[#0D0D0F] border border-white/10 text-xs text-white font-mono focus:border-[#FF4D00] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold text-white/40 uppercase mb-1">
                Discord Server Link
              </label>
              <input
                type="url"
                value={discordLink}
                onChange={(e) => setDiscordLink(e.target.value)}
                className="w-full px-3 py-2 rounded-xs bg-[#0D0D0F] border border-white/10 text-xs text-white font-mono focus:border-[#FF4D00] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold text-white/40 uppercase mb-1">
                Helpline Phone Number
              </label>
              <input
                type="text"
                value={helplinePhone}
                onChange={(e) => setHelplinePhone(e.target.value)}
                className="w-full px-3 py-2 rounded-xs bg-[#0D0D0F] border border-white/10 text-xs text-white font-mono focus:border-[#FF4D00] focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Save Button */}
        <div className="flex justify-end">
          <button
            type="submit"
            className="px-5 py-2.5 rounded-xs bg-[#FF4D00] hover:bg-[#E04400] text-black text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5 cursor-pointer shadow-md transition-colors"
          >
            <Save className="w-3.5 h-3.5" />
            <span>Save Configuration</span>
          </button>
        </div>
      </form>
    </div>
  );
};
