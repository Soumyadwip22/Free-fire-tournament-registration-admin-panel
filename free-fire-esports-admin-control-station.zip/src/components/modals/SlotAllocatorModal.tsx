import React, { useState } from 'react';
import { Team, GroupType } from '../../types';
import {
  X,
  Layers,
  Shield,
  CheckCircle2,
  AlertCircle,
  Shuffle,
  Save,
} from 'lucide-react';

interface SlotAllocatorModalProps {
  targetTeam?: Team | null;
  teams: Team[];
  onClose: () => void;
  onAllocateSlot: (teamId: string, group: GroupType, slotNumber: number | null) => Promise<void>;
}

export const SlotAllocatorModal: React.FC<SlotAllocatorModalProps> = ({
  targetTeam,
  teams,
  onClose,
  onAllocateSlot,
}) => {
  const [activeGroup, setActiveGroup] = useState<GroupType>(targetTeam?.group !== 'Unassigned' ? targetTeam?.group || 'Group A' : 'Group A');
  const [selectedTeamId, setSelectedTeamId] = useState<string>(targetTeam?.id || '');
  const [slotAssignments, setSlotAssignments] = useState<Record<number, string>>(() => {
    const map: Record<number, string> = {};
    teams
      .filter((t) => t.group === (targetTeam?.group !== 'Unassigned' ? targetTeam?.group || 'Group A' : 'Group A') && t.slotNumber)
      .forEach((t) => {
        if (t.slotNumber) {
          map[t.slotNumber] = t.id;
        }
      });
    return map;
  });

  const handleGroupChange = (group: GroupType) => {
    setActiveGroup(group);
    const map: Record<number, string> = {};
    teams
      .filter((t) => t.group === group && t.slotNumber)
      .forEach((t) => {
        if (t.slotNumber) {
          map[t.slotNumber] = t.id;
        }
      });
    setSlotAssignments(map);
  };

  const handleAssignToSlot = async (slotNumber: number) => {
    if (!selectedTeamId) return;

    // Check if slot is occupied
    const occupiedTeamId = slotAssignments[slotNumber];
    if (occupiedTeamId && occupiedTeamId !== selectedTeamId) {
      if (!window.confirm(`Slot #${slotNumber} is already taken by ${teams.find(t => t.id === occupiedTeamId)?.teamName}. Reassign?`)) {
        return;
      }
      // Unassign existing team
      await onAllocateSlot(occupiedTeamId, activeGroup, null);
    }

    // Assign selected team
    await onAllocateSlot(selectedTeamId, activeGroup, slotNumber);

    setSlotAssignments((prev) => {
      const next = { ...prev };
      // Remove team from previous slot in this group if any
      Object.keys(next).forEach((s) => {
        if (next[parseInt(s)] === selectedTeamId) {
          delete next[parseInt(s)];
        }
      });
      next[slotNumber] = selectedTeamId;
      return next;
    });
  };

  const handleUnassignSlot = async (slotNumber: number) => {
    const teamId = slotAssignments[slotNumber];
    if (!teamId) return;
    await onAllocateSlot(teamId, 'Unassigned', null);
    setSlotAssignments((prev) => {
      const next = { ...prev };
      delete next[slotNumber];
      return next;
    });
  };

  const groupTeams = teams.filter((t) => t.group === activeGroup);
  const unassignedTeams = teams.filter((t) => t.group === 'Unassigned' || !t.slotNumber);

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-4xl max-h-[92vh] bg-[#141417] border border-zinc-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="p-5 border-b border-zinc-800 flex items-center justify-between bg-[#18181B]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#FF4D00]/20 border border-[#FF4D00]/40 flex items-center justify-center text-[#FF4D00]">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold font-display text-white uppercase tracking-wider">
                12-Slot Custom Room Grid Allocator
              </h2>
              <p className="text-xs text-zinc-400">
                Assign qualified teams to standard 12 Free Fire lobby slots per match group.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-zinc-400 hover:text-white bg-zinc-800 rounded-lg cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Group Filter Tabs */}
        <div className="px-6 py-3 bg-zinc-900/90 border-b border-zinc-800 flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            {(['Group A', 'Group B', 'Group C', 'Grand Finals'] as GroupType[]).map((grp) => (
              <button
                key={grp}
                onClick={() => handleGroupChange(grp)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold font-display tracking-wider transition-all cursor-pointer ${
                  activeGroup === grp
                    ? 'bg-[#FF4D00] text-white shadow-md shadow-orange-950/40'
                    : 'bg-zinc-800 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {grp} ({teams.filter((t) => t.group === grp && t.slotNumber).length}/12)
              </button>
            ))}
          </div>

          <div className="text-xs text-zinc-400 font-mono">
            Occupied: <span className="text-[#00FF66] font-bold">{Object.keys(slotAssignments).length}/12 Slots</span>
          </div>
        </div>

        {/* Body Content */}
        <div className="p-6 grid grid-cols-1 lg:grid-cols-3 gap-6 overflow-y-auto flex-1">
          {/* Left Column: Team Selection Pool */}
          <div className="space-y-3">
            <div className="text-xs font-mono font-bold text-zinc-300 uppercase tracking-wider flex items-center justify-between">
              <span>Select Team to Place</span>
              <span className="text-zinc-500">{unassignedTeams.length} available</span>
            </div>

            <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
              {teams.map((team) => {
                const isSelected = selectedTeamId === team.id;
                const isPlaced = team.group === activeGroup && team.slotNumber;

                return (
                  <div
                    key={team.id}
                    onClick={() => setSelectedTeamId(team.id)}
                    className={`p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                      isSelected
                        ? 'bg-[#1F1C18] border-[#FF4D00] shadow-md'
                        : isPlaced
                        ? 'bg-zinc-900/60 border-zinc-800 hover:border-zinc-700'
                        : 'bg-[#18181B] border-zinc-800/80 hover:border-zinc-700'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      <div className="w-7 h-7 rounded bg-zinc-800 flex items-center justify-center text-[10px] font-bold text-zinc-300">
                        {team.teamTag || team.teamName.slice(0, 2).toUpperCase()}
                      </div>
                      <div className="truncate">
                        <div className="text-xs font-semibold text-white truncate">{team.teamName}</div>
                        <div className="text-[10px] text-zinc-400 font-mono">
                          {team.group !== 'Unassigned' && team.slotNumber
                            ? `${team.group} • Slot #${team.slotNumber}`
                            : 'Unassigned'}
                        </div>
                      </div>
                    </div>

                    <span
                      className={`text-[10px] font-mono px-1.5 py-0.2 rounded ${
                        team.status === 'QUALIFIED'
                          ? 'bg-emerald-500/20 text-emerald-400'
                          : 'bg-zinc-800 text-zinc-400'
                      }`}
                    >
                      {team.status === 'QUALIFIED' ? 'OK' : team.status.slice(0, 4)}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right 2 Columns: Visual 12-Slot Free Fire Room Grid */}
          <div className="lg:col-span-2 space-y-3">
            <div className="text-xs font-mono font-bold text-zinc-300 uppercase tracking-wider flex items-center justify-between">
              <span>{activeGroup} Custom Room (Slots 1 to 12)</span>
              {selectedTeamId && (
                <span className="text-[#FF6B2B] text-xs">
                  Click any slot below to place: {teams.find((t) => t.id === selectedTeamId)?.teamName}
                </span>
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {Array.from({ length: 12 }, (_, i) => i + 1).map((slotNum) => {
                const assignedId = slotAssignments[slotNum];
                const assignedTeam = teams.find((t) => t.id === assignedId);

                return (
                  <div
                    key={slotNum}
                    className={`p-3.5 rounded-xl border flex flex-col justify-between min-h-[110px] transition-all relative group ${
                      assignedTeam
                        ? 'bg-gradient-to-b from-[#18181B] to-[#121215] border-zinc-700 shadow-md'
                        : 'bg-zinc-950/70 border-dashed border-zinc-800 hover:border-[#FF4D00]/60 hover:bg-zinc-900/40 cursor-pointer'
                    }`}
                    onClick={() => {
                      if (selectedTeamId) {
                        handleAssignToSlot(slotNum);
                      }
                    }}
                  >
                    {/* Slot Badge */}
                    <div className="flex items-center justify-between">
                      <span
                        className={`w-6 h-6 rounded-md flex items-center justify-center font-mono font-bold text-xs ${
                          assignedTeam
                            ? 'bg-[#FF4D00] text-white shadow-sm'
                            : 'bg-zinc-800 text-zinc-400'
                        }`}
                      >
                        {slotNum}
                      </span>

                      {assignedTeam && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleUnassignSlot(slotNum);
                          }}
                          className="text-[10px] text-zinc-500 hover:text-rose-400 p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                          title="Remove from slot"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>

                    {/* Team Info */}
                    {assignedTeam ? (
                      <div className="mt-2">
                        <div className="text-xs font-bold text-white line-clamp-1">
                          {assignedTeam.teamName}
                        </div>
                        <div className="text-[10px] text-zinc-400 font-mono mt-0.5 flex items-center justify-between">
                          <span>[{assignedTeam.teamTag}]</span>
                          <span className="text-emerald-400 font-medium">Captain: {assignedTeam.captainName.split(' ')[0]}</span>
                        </div>
                      </div>
                    ) : (
                      <div className="mt-2 text-center py-2 text-zinc-600 group-hover:text-zinc-400 text-xs font-mono">
                        + Empty Slot
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-zinc-800 bg-[#18181B] flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-lg bg-[#FF4D00] hover:bg-[#E04400] text-white text-xs font-semibold font-display tracking-wider uppercase cursor-pointer"
          >
            Done Allocating
          </button>
        </div>
      </div>
    </div>
  );
};
