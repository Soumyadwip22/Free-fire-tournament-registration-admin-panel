import React, { useState } from 'react';
import { Team, TeamStatus, GroupType, Player } from '../../types';
import {
  X,
  Shield,
  Phone,
  Mail,
  User,
  CheckCircle2,
  XCircle,
  Clock,
  Ban,
  Layers,
  Save,
  Plus,
  Trash2,
} from 'lucide-react';

interface TeamDetailModalProps {
  team: Team | null;
  onClose: () => void;
  onSave: (team: Team) => Promise<void>;
  onUpdateStatus: (teamId: string, status: TeamStatus, reason?: string) => Promise<void>;
  onAllocateSlot: (team: Team) => void;
}

export const TeamDetailModal: React.FC<TeamDetailModalProps> = ({
  team,
  onClose,
  onSave,
  onUpdateStatus,
  onAllocateSlot,
}) => {
  if (!team) return null;

  const [formData, setFormData] = useState<Team>({ ...team });
  const [isSaving, setIsSaving] = useState(false);

  const handlePlayerChange = (index: number, field: keyof Player, value: string) => {
    const updatedPlayers = [...formData.players];
    updatedPlayers[index] = {
      ...updatedPlayers[index],
      [field]: value,
    };
    setFormData({ ...formData, players: updatedPlayers });
  };

  const handleAddPlayer = () => {
    if (formData.players.length >= 6) return;
    setFormData({
      ...formData,
      players: [
        ...formData.players,
        {
          name: 'New Player',
          ign: 'IGN-' + Math.floor(1000 + Math.random() * 9000),
          uid: Math.floor(1000000000 + Math.random() * 9000000000).toString(),
          role: 'Fragger',
        },
      ],
    });
  };

  const handleRemovePlayer = (index: number) => {
    if (formData.players.length <= 1) return;
    setFormData({
      ...formData,
      players: formData.players.filter((_, i) => i !== index),
    });
  };

  const handleSaveTeam = async () => {
    setIsSaving(true);
    await onSave(formData);
    setIsSaving(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-3xl max-h-[90vh] bg-[#141417] border border-zinc-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95">
        {/* Modal Header */}
        <div className="p-5 border-b border-zinc-800 flex items-center justify-between bg-[#18181B]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-zinc-800 border border-zinc-700 flex items-center justify-center overflow-hidden">
              {formData.logoUrl ? (
                <img src={formData.logoUrl} alt="Logo" className="w-full h-full object-cover" />
              ) : (
                <Shield className="w-5 h-5 text-[#FF4D00]" />
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold font-display text-white">{formData.teamName}</h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#FF4D00]/20 text-[#FF6B2B]">
                  [{formData.teamTag || 'TAG'}]
                </span>
              </div>
              <div className="text-[11px] text-zinc-400 font-mono">ID: {formData.id}</div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onAllocateSlot(formData)}
              className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-xs font-semibold text-zinc-200 flex items-center gap-1.5 cursor-pointer"
            >
              <Layers className="w-3.5 h-3.5 text-[#FF4D00]" />
              <span>
                {formData.group !== 'Unassigned' ? `${formData.group} - Slot #${formData.slotNumber}` : 'Assign Slot'}
              </span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-zinc-400 hover:text-white bg-zinc-800 rounded-lg cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6 overflow-y-auto flex-1">
          {/* Quick Status Control Buttons */}
          <div className="p-4 bg-zinc-900/90 rounded-xl border border-zinc-800 space-y-2">
            <div className="text-xs font-mono font-bold text-zinc-400 uppercase tracking-wider">
              Esports Qualification Actions
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => onUpdateStatus(formData.id, 'QUALIFIED')}
                className={`py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                  formData.status === 'QUALIFIED'
                    ? 'bg-emerald-500 text-black font-bold shadow-md shadow-emerald-950/40'
                    : 'bg-zinc-800 hover:bg-zinc-700 text-emerald-400 border border-emerald-500/30'
                }`}
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Qualify</span>
              </button>

              <button
                type="button"
                onClick={() => onUpdateStatus(formData.id, 'WAITLIST')}
                className={`py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                  formData.status === 'WAITLIST'
                    ? 'bg-amber-500 text-black font-bold shadow-md shadow-amber-950/40'
                    : 'bg-zinc-800 hover:bg-zinc-700 text-amber-400 border border-amber-500/30'
                }`}
              >
                <Clock className="w-3.5 h-3.5" />
                <span>Waitlist</span>
              </button>

              <button
                type="button"
                onClick={() => onUpdateStatus(formData.id, 'REJECTED', 'Registration details or payment rejected')}
                className={`py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                  formData.status === 'REJECTED'
                    ? 'bg-rose-600 text-white font-bold shadow-md'
                    : 'bg-zinc-800 hover:bg-zinc-700 text-rose-400 border border-rose-500/30'
                }`}
              >
                <XCircle className="w-3.5 h-3.5" />
                <span>Reject</span>
              </button>

              <button
                type="button"
                onClick={() => onUpdateStatus(formData.id, 'DISQUALIFIED', 'Rule violation or emulator detected')}
                className={`py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-all ${
                  formData.status === 'DISQUALIFIED'
                    ? 'bg-red-700 text-white font-bold shadow-md'
                    : 'bg-zinc-800 hover:bg-zinc-700 text-red-500 border border-red-500/30'
                }`}
              >
                <Ban className="w-3.5 h-3.5" />
                <span>Disqualify</span>
              </button>
            </div>
          </div>

          {/* Captain & Contact Details */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 bg-zinc-900/60 rounded-xl border border-zinc-800">
            <div>
              <label className="block text-[11px] text-zinc-400 mb-1">Captain Name</label>
              <input
                type="text"
                value={formData.captainName}
                onChange={(e) => setFormData({ ...formData, captainName: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-xs text-white"
              />
            </div>

            <div>
              <label className="block text-[11px] text-zinc-400 mb-1">Captain Phone (WhatsApp)</label>
              <input
                type="text"
                value={formData.captainPhone}
                onChange={(e) => setFormData({ ...formData, captainPhone: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-xs text-white font-mono"
              />
            </div>

            <div>
              <label className="block text-[11px] text-zinc-400 mb-1">Captain UID (Free Fire)</label>
              <input
                type="text"
                value={formData.captainUid}
                onChange={(e) => setFormData({ ...formData, captainUid: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-zinc-950 border border-zinc-700 text-xs text-white font-mono"
              />
            </div>
          </div>

          {/* Roster Players (5 Max) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="text-xs font-mono font-bold text-zinc-300 uppercase tracking-wider">
                Active Squad Roster ({formData.players?.length || 0}/5)
              </div>
              {formData.players?.length < 5 && (
                <button
                  type="button"
                  onClick={handleAddPlayer}
                  className="px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-[11px] font-medium text-zinc-300 flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3 h-3" />
                  <span>Add Player</span>
                </button>
              )}
            </div>

            <div className="space-y-2">
              {formData.players?.map((player, idx) => (
                <div
                  key={idx}
                  className="p-3 bg-zinc-900 rounded-xl border border-zinc-800 grid grid-cols-1 sm:grid-cols-4 gap-2 items-center"
                >
                  <div>
                    <span className="text-[10px] text-zinc-500 font-mono block">Player #{idx + 1} Name</span>
                    <input
                      type="text"
                      value={player.name}
                      onChange={(e) => handlePlayerChange(idx, 'name', e.target.value)}
                      className="w-full px-2.5 py-1.5 rounded bg-zinc-950 border border-zinc-700 text-xs text-white"
                    />
                  </div>

                  <div>
                    <span className="text-[10px] text-zinc-500 font-mono block">In-Game Name (IGN)</span>
                    <input
                      type="text"
                      value={player.ign}
                      onChange={(e) => handlePlayerChange(idx, 'ign', e.target.value)}
                      className="w-full px-2.5 py-1.5 rounded bg-zinc-950 border border-zinc-700 text-xs text-[#FF6B2B] font-mono font-bold"
                    />
                  </div>

                  <div>
                    <span className="text-[10px] text-zinc-500 font-mono block">Free Fire UID</span>
                    <input
                      type="text"
                      value={player.uid}
                      onChange={(e) => handlePlayerChange(idx, 'uid', e.target.value)}
                      className="w-full px-2.5 py-1.5 rounded bg-zinc-950 border border-zinc-700 text-xs text-zinc-200 font-mono"
                    />
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="flex-1">
                      <span className="text-[10px] text-zinc-500 font-mono block">Role</span>
                      <select
                        value={player.role || 'Fragger'}
                        onChange={(e) => handlePlayerChange(idx, 'role', e.target.value)}
                        className="w-full px-2.5 py-1.5 rounded bg-zinc-950 border border-zinc-700 text-xs text-zinc-300"
                      >
                        <option value="Captain">Captain</option>
                        <option value="IGL">IGL</option>
                        <option value="Fragger">Fragger</option>
                        <option value="Sniper">Sniper</option>
                        <option value="Support">Support</option>
                        <option value="Substitute">Substitute</option>
                      </select>
                    </div>
                    {formData.players.length > 1 && (
                      <button
                        type="button"
                        onClick={() => handleRemovePlayer(idx)}
                        className="p-1.5 mt-4 text-zinc-500 hover:text-rose-400 rounded cursor-pointer"
                        title="Remove Player"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-zinc-800 bg-[#18181B] flex items-center justify-between">
          <div className="text-xs text-zinc-400 font-mono">
            Payment Status: <span className="font-bold text-white">{formData.paymentStatus}</span>
            {formData.utrNumber && <span className="ml-2">({formData.utrNumber})</span>}
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSaveTeam}
              disabled={isSaving}
              className="px-4 py-2 rounded-lg bg-[#FF4D00] hover:bg-[#E04400] text-white text-xs font-semibold font-display tracking-wider uppercase flex items-center gap-1.5 cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{isSaving ? 'Saving...' : 'Save Roster'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
