import React, { useState } from 'react';
import { useTournament } from '../../context/TournamentContext';
import {
  X,
  Flame,
  Trophy,
  Swords,
  Megaphone,
  Key,
  Copy,
  Check,
  Clock,
  Shield,
  Layers,
  Award,
  BookOpen,
} from 'lucide-react';

interface PublicPlayerPreviewModalProps {
  onClose: () => void;
}

export const PublicPlayerPreviewModal: React.FC<PublicPlayerPreviewModalProps> = ({ onClose }) => {
  const {
    selectedTournament,
    teams,
    matches,
    overallStandings,
    announcements,
  } = useTournament();

  const [activeTab, setActiveTab] = useState<'standings' | 'fixtures' | 'rules' | 'notices'>('standings');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(id);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-2 sm:p-4">
      <div className="w-full max-w-5xl max-h-[94vh] bg-[#0E0E12] border border-zinc-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95">
        {/* Preview Top Ribbon */}
        <div className="bg-gradient-to-r from-emerald-950/80 via-zinc-900 to-emerald-950/80 px-4 py-2 border-b border-emerald-500/30 flex items-center justify-between text-xs font-mono">
          <div className="flex items-center gap-2 text-emerald-400 font-bold">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            <span>PLAYER & SPECTATOR LIVE APP VIEW (PUBLIC HUB)</span>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-zinc-400 hover:text-white rounded cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Hero Banner */}
        <div className="relative overflow-hidden bg-gradient-to-r from-[#18181B] to-[#121215] border-b border-zinc-800 p-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#FF4D00]/20 text-[#FF6B2B]">
                  FREE FIRE ESPORTS
                </span>
                <span className="text-zinc-500 text-xs">•</span>
                <span className="text-xs text-zinc-400 font-mono">
                  {selectedTournament?.gameMode || 'Squad'} Mode
                </span>
              </div>
              <h1 className="text-xl sm:text-2xl font-bold font-display text-white">
                {selectedTournament?.title || 'Free Fire Championship'}
              </h1>
              <p className="text-xs text-zinc-400">
                Prize Pool: <span className="text-amber-400 font-bold">₹{selectedTournament?.prizePool?.toLocaleString('en-IN')}</span> | Registered Teams: {teams.length}
              </p>
            </div>

            {/* Navigation Tabs for Player Hub */}
            <div className="flex items-center gap-1.5 bg-zinc-900 p-1.5 rounded-xl border border-zinc-800 self-start sm:self-auto">
              <button
                onClick={() => setActiveTab('standings')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                  activeTab === 'standings' ? 'bg-[#FF4D00] text-white' : 'text-zinc-400 hover:text-white'
                }`}
              >
                <Trophy className="w-3.5 h-3.5" />
                <span>Leaderboard</span>
              </button>

              <button
                onClick={() => setActiveTab('fixtures')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                  activeTab === 'fixtures' ? 'bg-[#FF4D00] text-white' : 'text-zinc-400 hover:text-white'
                }`}
              >
                <Swords className="w-3.5 h-3.5" />
                <span>Room Fixtures</span>
              </button>

              <button
                onClick={() => setActiveTab('rules')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                  activeTab === 'rules' ? 'bg-[#FF4D00] text-white' : 'text-zinc-400 hover:text-white'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>Rules</span>
              </button>

              <button
                onClick={() => setActiveTab('notices')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                  activeTab === 'notices' ? 'bg-[#FF4D00] text-white' : 'text-zinc-400 hover:text-white'
                }`}
              >
                <Megaphone className="w-3.5 h-3.5" />
                <span>Notice Board</span>
              </button>
            </div>
          </div>
        </div>

        {/* Modal Body View */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* TAB 1: STANDINGS */}
          {activeTab === 'standings' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold font-display text-white uppercase tracking-wider flex items-center gap-2">
                  <Trophy className="w-4 h-4 text-amber-400" />
                  Official Live Standings
                </h3>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
                  REAL-TIME SYNC ACTIVE
                </span>
              </div>

              <div className="rounded-xl border border-zinc-800 bg-[#141417] overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="bg-zinc-900 border-b border-zinc-800 text-zinc-400 font-mono text-[11px]">
                      <th className="py-2.5 px-3 font-medium w-12 text-center">#</th>
                      <th className="py-2.5 px-3 font-medium">Squad Name</th>
                      <th className="py-2.5 px-3 font-medium text-center">Matches</th>
                      <th className="py-2.5 px-3 font-medium text-center">Booyahs 👑</th>
                      <th className="py-2.5 px-3 font-medium text-center">Kill PTS</th>
                      <th className="py-2.5 px-4 font-medium text-right text-white">Total PTS</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/60 font-mono">
                    {overallStandings.map((s, idx) => (
                      <tr
                        key={s.teamId}
                        className={`hover:bg-zinc-800/30 ${
                          idx === 0 ? 'bg-amber-500/10' : idx === 1 ? 'bg-zinc-800/20' : ''
                        }`}
                      >
                        <td className="py-2.5 px-3 text-center">
                          <span
                            className={`w-6 h-6 rounded flex items-center justify-center font-bold text-xs ${
                              idx === 0
                                ? 'bg-amber-400 text-black'
                                : idx === 1
                                ? 'bg-zinc-300 text-black'
                                : idx === 2
                                ? 'bg-amber-700 text-white'
                                : 'bg-zinc-800 text-zinc-400'
                            }`}
                          >
                            {idx + 1}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 font-sans font-bold text-white">
                          {s.teamName}
                          {s.teamTag && <span className="ml-1.5 text-zinc-500 font-mono text-[10px]">[{s.teamTag}]</span>}
                        </td>
                        <td className="py-2.5 px-3 text-center text-zinc-300">{s.matchesPlayed}</td>
                        <td className="py-2.5 px-3 text-center font-bold text-amber-400">
                          {s.booyahs > 0 ? `👑 ${s.booyahs}` : '0'}
                        </td>
                        <td className="py-2.5 px-3 text-center text-[#00E5FF] font-bold">{s.killPoints}</td>
                        <td className="py-2.5 px-4 text-right font-bold text-[#FF6B2B] text-sm">
                          {s.totalPoints}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 2: FIXTURES & 15-MIN ROOM UNLOCK */}
          {activeTab === 'fixtures' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold font-display text-white uppercase tracking-wider flex items-center gap-2">
                  <Swords className="w-4 h-4 text-[#FF4D00]" />
                  Tournament Fixtures & Room Unlocks
                </h3>
                <span className="text-xs text-zinc-400 font-mono">
                  Room credentials unlock 15m prior to kickoff
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {matches.map((m) => (
                  <div
                    key={m.id}
                    className="p-5 rounded-2xl bg-[#141417] border border-zinc-800 space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-zinc-900 border border-zinc-700 text-[#FF6B2B] font-bold">
                        MAP: {m.map} • {m.stage}
                      </span>
                      <span className="text-xs text-zinc-400 font-mono">
                        {new Date(m.scheduledTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>

                    <h4 className="text-sm font-bold font-display text-white">{m.title}</h4>

                    {/* Room Credentials (if published) */}
                    {m.isCredentialsPublished ? (
                      <div className="p-3 bg-emerald-950/30 rounded-xl border border-emerald-500/40 space-y-2">
                        <div className="text-[10px] font-mono font-bold text-emerald-400 uppercase">
                          ⚡ ROOM CREDENTIALS UNLOCKED
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                          <div className="p-2 bg-zinc-900 rounded border border-zinc-800 flex items-center justify-between">
                            <div>
                              <div className="text-[9px] text-zinc-500">ROOM ID</div>
                              <div className="font-bold text-white">{m.roomId}</div>
                            </div>
                            <button
                              onClick={() => handleCopy(m.roomId!, `prev-room-${m.id}`)}
                              className="p-1 text-zinc-400 hover:text-white"
                            >
                              {copiedKey === `prev-room-${m.id}` ? (
                                <Check className="w-3.5 h-3.5 text-emerald-400" />
                              ) : (
                                <Copy className="w-3.5 h-3.5" />
                              )}
                            </button>
                          </div>

                          <div className="p-2 bg-zinc-900 rounded border border-zinc-800 flex items-center justify-between">
                            <div>
                              <div className="text-[9px] text-zinc-500">PASSWORD</div>
                              <div className="font-bold text-[#FF6B2B]">{m.roomPassword}</div>
                            </div>
                            <button
                              onClick={() => handleCopy(m.roomPassword!, `prev-pass-${m.id}`)}
                              className="p-1 text-zinc-400 hover:text-white"
                            >
                              {copiedKey === `prev-pass-${m.id}` ? (
                                <Check className="w-3.5 h-3.5 text-emerald-400" />
                              ) : (
                                <Copy className="w-3.5 h-3.5" />
                              )}
                            </button>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="p-3 bg-zinc-900/80 rounded-xl border border-zinc-800 text-center text-xs text-zinc-500 font-mono">
                        🔒 Room ID & Password will unlock automatically 15 minutes before match start.
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: RULES & PRIZE POOL */}
          {activeTab === 'rules' && (
            <div className="space-y-4">
              <div className="p-5 rounded-2xl bg-[#141417] border border-zinc-800 space-y-3">
                <h3 className="text-sm font-bold font-display text-white uppercase tracking-wider flex items-center gap-2">
                  <Award className="w-4 h-4 text-amber-400" />
                  Prize Pool Breakdown
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                  <div className="p-3 bg-zinc-900 rounded-xl border border-zinc-800">
                    <div className="text-xs text-zinc-400">1st Place (Booyah)</div>
                    <div className="text-lg font-bold font-display text-amber-400">
                      ₹{selectedTournament?.prizeBreakdown?.first?.toLocaleString('en-IN')}
                    </div>
                  </div>
                  <div className="p-3 bg-zinc-900 rounded-xl border border-zinc-800">
                    <div className="text-xs text-zinc-400">2nd Place</div>
                    <div className="text-lg font-bold font-display text-zinc-200">
                      ₹{selectedTournament?.prizeBreakdown?.second?.toLocaleString('en-IN')}
                    </div>
                  </div>
                  <div className="p-3 bg-zinc-900 rounded-xl border border-zinc-800">
                    <div className="text-xs text-zinc-400">3rd Place</div>
                    <div className="text-lg font-bold font-display text-amber-700">
                      ₹{selectedTournament?.prizeBreakdown?.third?.toLocaleString('en-IN')}
                    </div>
                  </div>
                  <div className="p-3 bg-zinc-900 rounded-xl border border-zinc-800">
                    <div className="text-xs text-zinc-400">Tournament MVP</div>
                    <div className="text-lg font-bold font-display text-[#FF4D00]">
                      ₹{selectedTournament?.prizeBreakdown?.mvp?.toLocaleString('en-IN')}
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-5 rounded-2xl bg-[#141417] border border-zinc-800 space-y-2">
                <h3 className="text-sm font-bold font-display text-white uppercase tracking-wider">
                  Official Esports Rules & Guidelines
                </h3>
                <div className="text-xs text-zinc-300 whitespace-pre-line font-mono leading-relaxed bg-zinc-900 p-4 rounded-xl border border-zinc-800">
                  {selectedTournament?.rules}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: NOTICES */}
          {activeTab === 'notices' && (
            <div className="space-y-3">
              {announcements.map((ann) => (
                <div key={ann.id} className="p-4 rounded-xl bg-[#141417] border border-zinc-800 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-orange-500/20 text-[#FF6B2B] font-bold">
                      {ann.category}
                    </span>
                    <span className="text-[10px] text-zinc-500 font-mono">
                      {new Date(ann.createdAt).toLocaleDateString()}
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-white">{ann.title}</h4>
                  <p className="text-xs text-zinc-300 leading-relaxed">{ann.message}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
