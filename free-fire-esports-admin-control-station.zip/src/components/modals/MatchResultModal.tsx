import React, { useState } from 'react';
import { MatchFixture, Team, MatchResult, TeamScore } from '../../types';
import {
  X,
  Trophy,
  Save,
  Flame,
  Award,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';

interface MatchResultModalProps {
  match: MatchFixture;
  teams: Team[];
  onClose: () => void;
  onSaveResults: (result: MatchResult) => Promise<void>;
}

// Standard Free Fire Esports Point Matrix
const PLACEMENT_POINTS: Record<number, number> = {
  1: 12,
  2: 9,
  3: 8,
  4: 7,
  5: 6,
  6: 5,
  7: 4,
  8: 3,
  9: 2,
  10: 1,
  11: 0,
  12: 0,
};

export const MatchResultModal: React.FC<MatchResultModalProps> = ({
  match,
  teams,
  onClose,
  onSaveResults,
}) => {
  // Pre-populate with teams in the match's group or top teams
  const groupTeams = teams.filter((t) => t.group === match.stage && t.slotNumber);
  const candidateTeams = groupTeams.length >= 6 ? groupTeams : teams.slice(0, 12);

  const [scores, setScores] = useState<TeamScore[]>(() => {
    return candidateTeams.map((team, idx) => {
      const place = idx + 1;
      const placePts = PLACEMENT_POINTS[place] || 0;
      const kills = 0;
      return {
        teamId: team.id,
        teamName: team.teamName,
        placement: place,
        kills: kills,
        placementPoints: placePts,
        totalPoints: placePts + kills,
        isBooyah: place === 1,
      };
    });
  });

  const [mvpName, setMvpName] = useState('');
  const [mvpIgn, setMvpIgn] = useState('');
  const [mvpKills, setMvpKills] = useState<number>(5);
  const [mvpDamage, setMvpDamage] = useState<number>(2450);

  const handleRankChange = (index: number, newRank: number) => {
    const updated = [...scores];
    const placePts = PLACEMENT_POINTS[newRank] || 0;
    updated[index] = {
      ...updated[index],
      placement: newRank,
      placementPoints: placePts,
      totalPoints: placePts + updated[index].kills,
      isBooyah: newRank === 1,
    };
    setScores(updated);
  };

  const handleKillsChange = (index: number, newKills: number) => {
    const updated = [...scores];
    const k = Math.max(0, newKills);
    updated[index] = {
      ...updated[index],
      kills: k,
      totalPoints: updated[index].placementPoints + k,
    };
    setScores(updated);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const resultToSave: MatchResult = {
      id: 'res-' + match.id,
      matchId: match.id,
      tournamentId: match.tournamentId,
      scores: [...scores].sort((a, b) => b.totalPoints - a.totalPoints),
      recordedBy: 'mondalsoumyadwip1110@gmail.com',
      recordedAt: new Date().toISOString(),
      isFinalized: true,
      mvpPlayer: mvpName
        ? {
            name: mvpName,
            ign: mvpIgn || mvpName,
            teamName: scores[0]?.teamName || 'Champions',
            kills: mvpKills,
            damage: mvpDamage,
          }
        : undefined,
    };

    await onSaveResults(resultToSave);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-4xl max-h-[92vh] bg-[#141417] border border-zinc-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden animate-in fade-in zoom-in-95">
        {/* Header */}
        <div className="p-5 border-b border-zinc-800 flex items-center justify-between bg-[#18181B]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#FF4D00]/20 border border-[#FF4D00]/40 flex items-center justify-center text-[#FF4D00]">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold font-display text-white uppercase">
                  Live Score Entry: {match.title}
                </h2>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-zinc-800 text-zinc-300">
                  MAP: {match.map}
                </span>
              </div>
              <p className="text-xs text-zinc-400">
                Official scoring rule: 1st=12, 2nd=9, 3rd=8, 4th=7, 5th=6, 6th=5, 7th=4, 8th=3, 9th=2, 10th=1 + 1 pt/kill.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-zinc-400 hover:text-white bg-zinc-800 rounded-lg cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSave} className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* MVP Spotlight Form */}
          <div className="p-4 bg-gradient-to-r from-amber-950/30 to-zinc-900 rounded-xl border border-amber-500/30 space-y-3">
            <div className="text-xs font-mono font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
              <Award className="w-4 h-4" />
              Match MVP Spotlight (Optional)
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">MVP Player Name</label>
                <input
                  type="text"
                  placeholder="e.g. Rahul Sen"
                  value={mvpName}
                  onChange={(e) => setMvpName(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded bg-zinc-950 border border-zinc-700 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">MVP IGN</label>
                <input
                  type="text"
                  placeholder="e.g. TG-FoXy7"
                  value={mvpIgn}
                  onChange={(e) => setMvpIgn(e.target.value)}
                  className="w-full px-2.5 py-1.5 rounded bg-zinc-950 border border-zinc-700 text-xs text-amber-400 font-mono font-bold"
                />
              </div>

              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">Kills</label>
                <input
                  type="number"
                  min={0}
                  value={mvpKills}
                  onChange={(e) => setMvpKills(parseInt(e.target.value) || 0)}
                  className="w-full px-2.5 py-1.5 rounded bg-zinc-950 border border-zinc-700 text-xs text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">Total Damage</label>
                <input
                  type="number"
                  min={0}
                  value={mvpDamage}
                  onChange={(e) => setMvpDamage(parseInt(e.target.value) || 0)}
                  className="w-full px-2.5 py-1.5 rounded bg-zinc-950 border border-zinc-700 text-xs text-white font-mono"
                />
              </div>
            </div>
          </div>

          {/* Squad Placement Table */}
          <div className="space-y-2">
            <div className="text-xs font-mono font-bold text-zinc-300 uppercase tracking-wider">
              Match Placement & Kill Counts
            </div>

            <div className="rounded-xl border border-zinc-800 overflow-hidden">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-zinc-900 text-zinc-400 font-mono text-[11px] border-b border-zinc-800">
                    <th className="py-2.5 px-3 font-medium">Team</th>
                    <th className="py-2.5 px-3 font-medium w-28 text-center">Rank (1-12)</th>
                    <th className="py-2.5 px-3 font-medium w-24 text-center">Place PTS</th>
                    <th className="py-2.5 px-3 font-medium w-28 text-center">Kills</th>
                    <th className="py-2.5 px-3 font-medium w-24 text-right">Total PTS</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800 font-mono">
                  {scores.map((score, idx) => (
                    <tr
                      key={score.teamId}
                      className={`hover:bg-zinc-800/40 transition-colors ${
                        score.placement === 1 ? 'bg-amber-500/10' : ''
                      }`}
                    >
                      <td className="py-2.5 px-3 font-sans font-semibold text-white">
                        <div className="flex items-center gap-2">
                          {score.placement === 1 && <Flame className="w-4 h-4 text-amber-400" />}
                          <span>{score.teamName}</span>
                        </div>
                      </td>

                      <td className="py-2.5 px-3 text-center">
                        <select
                          value={score.placement}
                          onChange={(e) => handleRankChange(idx, parseInt(e.target.value))}
                          className="px-2 py-1 rounded bg-zinc-950 border border-zinc-700 text-xs text-white font-mono font-bold cursor-pointer"
                        >
                          {Array.from({ length: 12 }, (_, i) => i + 1).map((r) => (
                            <option key={r} value={r}>
                              #{r} {r === 1 ? '👑 Booyah' : ''}
                            </option>
                          ))}
                        </select>
                      </td>

                      <td className="py-2.5 px-3 text-center text-zinc-300 font-bold">
                        {score.placementPoints} pts
                      </td>

                      <td className="py-2.5 px-3 text-center">
                        <input
                          type="number"
                          min={0}
                          max={48}
                          value={score.kills}
                          onChange={(e) => handleKillsChange(idx, parseInt(e.target.value) || 0)}
                          className="w-16 px-2 py-1 rounded bg-zinc-950 border border-zinc-700 text-center text-xs text-[#00E5FF] font-mono font-bold"
                        />
                      </td>

                      <td className="py-2.5 px-3 text-right font-bold text-sm text-[#FF6B2B]">
                        {score.totalPoints} pts
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </form>

        {/* Footer */}
        <div className="p-4 border-t border-zinc-800 bg-[#18181B] flex items-center justify-between">
          <div className="text-xs text-zinc-400 font-mono">
            Scores will automatically calculate into tournament leaderboard
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-zinc-800 text-zinc-400 hover:text-white text-xs cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="px-5 py-2 rounded-lg bg-[#FF4D00] hover:bg-[#E04400] text-white text-xs font-semibold uppercase font-display tracking-wider flex items-center gap-1.5 cursor-pointer shadow-md"
            >
              <Save className="w-4 h-4" />
              <span>Save & Update Standings</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
