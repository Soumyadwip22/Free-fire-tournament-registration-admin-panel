import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useTournament } from '../context/TournamentContext';
import {
  Flame,
  Radio,
  Database,
  Eye,
  Sparkles,
  LogOut,
  ShieldCheck,
  ChevronDown,
  RefreshCw,
  Trophy,
} from 'lucide-react';

interface HeaderProps {
  onOpenPlayerPreview: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenPlayerPreview }) => {
  const { adminUser, logout } = useAuth();
  const {
    tournaments,
    selectedTournament,
    selectTournament,
    isLiveSyncActive,
    lastSyncTime,
    seedDemoData,
    isLoadingData,
  } = useTournament();

  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isSeeding, setIsSeeding] = useState(false);

  const handleSeed = async () => {
    if (window.confirm('Initialize or reset sample tournament data (24 teams, fixtures, payments, and points)?')) {
      setIsSeeding(true);
      await seedDemoData(true);
      setIsSeeding(false);
    }
  };

  return (
    <header className="h-20 bg-[#0D0D0F] border-b border-white/5 px-4 lg:px-8 flex items-center justify-between sticky top-0 z-40 backdrop-blur-md">
      {/* Brand & Live Indicator */}
      <div className="flex items-center gap-4 lg:gap-6">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 bg-[#FF4D00] rounded-lg flex items-center justify-center font-bold text-xl italic font-serif text-black shadow-lg shadow-orange-950/40">
            FF
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xs font-black tracking-widest text-[#FF4D00] uppercase">
                Command Station v2.4
              </h1>
              <span className="hidden sm:inline-block px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-white/5 text-white/60 border border-white/10 uppercase tracking-wider">
                PRO ADMIN
              </span>
            </div>
            <div className="flex items-center gap-2">
              <p className="text-lg lg:text-xl font-bold font-serif italic text-white tracking-tight">
                {selectedTournament?.title || 'Titan League Season 4'}
              </p>
              <span className="hidden xl:inline text-xs not-italic font-mono text-white/40">
                ID: {selectedTournament?.id || 'encoded-constant-8lcf1'}
              </span>
            </div>
          </div>
        </div>

        {/* Tournament Selector Dropdown */}
        <div className="relative hidden md:block">
          <button
            onClick={() => setIsDropdownOpen(!isDropdownOpen)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-sm bg-[#18181B] hover:bg-zinc-800 border border-white/10 text-xs font-mono text-zinc-200 transition-colors cursor-pointer"
          >
            <Trophy className="w-3.5 h-3.5 text-[#FF4D00]" />
            <span className="max-w-[140px] lg:max-w-[200px] truncate text-[11px] uppercase tracking-wider font-semibold">
              Switch Event
            </span>
            <ChevronDown className="w-3.5 h-3.5 text-zinc-400" />
          </button>

          {isDropdownOpen && (
            <div className="absolute left-0 mt-2 w-72 bg-[#18181B] border border-white/10 rounded-sm shadow-2xl py-1 z-50">
              <div className="px-3 py-1.5 text-[10px] font-mono text-white/40 uppercase tracking-widest border-b border-white/5">
                Switch Tournament
              </div>
              {tournaments.map((t) => (
                <button
                  key={t.id}
                  onClick={() => {
                    selectTournament(t.id);
                    setIsDropdownOpen(false);
                  }}
                  className={`w-full text-left px-3 py-2 text-xs hover:bg-white/5 flex items-center justify-between ${
                    t.id === selectedTournament?.id ? 'text-[#FF4D00] font-bold bg-white/5' : 'text-zinc-300'
                  }`}
                >
                  <span className="truncate font-serif italic">{t.title}</span>
                  <span className="text-[10px] font-mono text-white/40 uppercase">{t.status}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Action Controls & Admin Profile */}
      <div className="flex items-center gap-4 sm:gap-6">
        {/* Database Status Indicator */}
        <div className="hidden sm:block text-right">
          <p className="text-[10px] uppercase tracking-tighter text-white/40">Database Status</p>
          <div className="flex items-center justify-end gap-1.5">
            <span className={`w-1.5 h-1.5 rounded-full ${isLiveSyncActive ? 'bg-[#00FF66] animate-pulse' : 'bg-amber-400'}`} />
            <p className="text-xs font-mono font-bold text-[#00FF66]">
              {isLiveSyncActive ? 'FIRESTORE SYNCED' : 'OFFLINE'}
            </p>
          </div>
        </div>

        {/* Seed Demo Data Button */}
        <button
          onClick={handleSeed}
          disabled={isSeeding || isLoadingData}
          title="Seed realistic Free Fire tournament squads, matches, payments & standings"
          className="hidden lg:flex items-center gap-1.5 px-3 py-1.5 rounded-sm bg-white/5 hover:bg-white/10 border border-white/10 text-[10px] font-bold uppercase tracking-widest text-zinc-300 hover:text-white transition-colors cursor-pointer"
        >
          <Sparkles className={`w-3.5 h-3.5 text-amber-400 ${isSeeding ? 'animate-spin' : ''}`} />
          <span>Seed Data</span>
        </button>

        {/* Public Player View Button */}
        <button
          onClick={onOpenPlayerPreview}
          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-sm bg-[#FF4D00] hover:bg-[#E04400] text-black font-black uppercase text-[10px] tracking-widest transition-all shadow-md cursor-pointer"
        >
          <Eye className="w-3.5 h-3.5 text-black" />
          <span>Player View</span>
        </button>

        {/* Admin Card */}
        <div className="flex items-center gap-3 pl-3 border-l border-white/10">
          <div className="h-10 w-10 rounded-full bg-[#18181B] border border-white/10 flex items-center justify-center text-xs font-bold font-mono text-white">
            {adminUser?.name ? adminUser.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() : 'SM'}
          </div>
          <button
            onClick={logout}
            title="Sign out of Organizer Station"
            className="p-1.5 text-white/40 hover:text-rose-400 hover:bg-white/5 rounded-sm transition-colors cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
